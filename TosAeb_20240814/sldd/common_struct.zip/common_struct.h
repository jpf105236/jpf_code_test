#pragma once

typedef signed long int int64_t;
typedef unsigned long int uint64_t;
typedef signed char int8_t;
typedef unsigned char uint8_t;
typedef signed short int int16_t;
typedef unsigned short int uint16_t;
typedef signed int int32_t;
typedef unsigned int uint32_t;
typedef char bool;

#define MAX_LANE_NUM 3
#define MAX_LINE_NUM 4
#define MAX_EDGE_NUM 2
#define MAX_LANE_SEG_NUM 3
#define MAX_LINE_SEG_NUM 3
#define MAX_EDGE_SEG_NUM 3

typedef struct{
    uint64_t    laneSegId;
    bool        laneSegValid;
    float       laneSegWidth;
    float       laneSegStart;
    float       laneSegEnd;
    uint8_t     laneSegIdx;
    uint8_t     centerLineType;
    uint16_t    sensorType;
    float       laneC0;
    float       laneC0Std;
    float       laneC1;
    float       laneC1Std;
    float       laneC2;
    float       laneC2Std;
    float       laneC3;
    float       laneC3Std;    

}LaneSeg_Struct;

typedef struct{
    float       laneSegStart;
    float       laneSegEnd;
    bool        laneAttrSegValid;
    uint8_t     laneSegType;
    uint8_t     laneSegSource;
    float       maxLaneSpeed;
    float       minLaneSpeed;
    float       recLaneSpeed;
    uint8_t     laneSegTransitType;

}LaneAttrSeg_Struct;


typedef struct{
    uint8_t     laneId;
    uint8_t     laneDirection;
    uint8_t     lanePosition;
    float       laneStart;
    float       laneEnd;
    bool        laneStartOutRange;
    bool        laneEndOutRange;
    float       laneTTLC;
    uint8_t     laneTurn;
    uint8_t     laneLeftLineNum;
    /*
        laneLeftLineIDs[0]: left
        laneLeftLineIDs[1]: leftleft
    */
    uint32_t    laneLeftLineIDs[2];
    uint8_t     laneRightLineNum;
    /*
        laneRightLineIDs[0]: right
        laneRightLineIDs[1]: rightright
    */
    uint32_t    laneRightLineIDs[2];
    uint8_t     laneSegNum;
    /*
        laneSegs[0]: minus seg
        laneSegs[1]: first seg
        laneSegs[2]: second_seg
    */
    LaneSeg_Struct laneSegs[MAX_LANE_SEG_NUM];
    uint8_t     laneAttrSegNum;
    /*
        laneAttrSegs[0]: minus seg
        laneAttrSegs[1]: first seg
        laneAttrSegs[2]: second_seg
    */
    LaneAttrSeg_Struct laneAttrSegs[MAX_LANE_SEG_NUM];
    
}LaneData_Struct;

typedef struct{
    uint32_t    lineSegId;
    bool        lineSegValid;
    uint16_t    sensorType;
    float       lineSegWidth;
    float       lineSegStart;
    float       lineSegEnd;
    float       lineC0;
    float       lineC0Std;
    float       lineC1;
    float       lineC1Std;
    float       lineC2;
    float       lineC2Std;
    float       lineC3;
    float       lineC3Std;  

}LineSeg_Struct;

typedef struct{
    bool        lineSegAttrValid;
    float       lineSegStart;
    float       lineSegEnd;
    uint8_t     lineSegType;
    uint8_t     lineSegColor;

}LineAttrSeg_Struct;

typedef struct{
    uint32_t    lineId;
    uint8_t     linePosition;
    float       lineStart;
    float       lineEnd;
    bool        lineStartOutRange;
    bool        lineEndOutRangee;
    uint8_t     lineSegNum;
    /*
        lineSegs[0]: minus seg
        lineSegs[1]: first seg
        lineSegs[2]: second_seg
    */
    LineSeg_Struct lineSegs[MAX_LINE_SEG_NUM];
    uint8_t     lineAttrSegNum;
    /*
        lineAttrSegs[0]: minus seg
        lineAttrSegs[1]: first seg
        lineAttrSegs[2]: second_seg
    */
    LineAttrSeg_Struct lineAttrSegs[MAX_LINE_SEG_NUM];

}LineData_Struct;

typedef struct{
    uint32_t    edgeSegId;
    bool        edgeSegValid;
    uint16_t    sensorType;
    uint8_t     edgeType;
    float       edgeSegStart;
    float       edgeSegEnd;
    float       lineC0;
    float       lineC0Std;
    float       lineC1;
    float       lineC1Std;
    float       lineC2;
    float       lineC2Std;
    float       lineC3;
    float       lineC3Std;
    float       edgeHeight;

}EdgeSeg_Struct;

typedef struct{
    uint32_t    edgeId;
    uint8_t     edgePosition;
    float       edgeStart;
    float       edgeEnd;
    bool        edgeEndOutRange;
    bool        edgeStartOutRange;
    uint8_t     edgeSegNum;
    /*
        edgeSegs[0]: minus seg
        edgeSegs[1]: first seg
        edgeSegs[2]: second_seg
    */
    EdgeSeg_Struct edgeSegs[MAX_EDGE_SEG_NUM];

}EdgeData_Struct;


typedef struct
{
    int64_t     timeStamp;
    uint8_t     roadStatus;
    uint8_t     roadType;
    uint8_t     laneNum;
    /*
        Road.laneData[0]: Ego_Lane
        Road.laneData[1]: Left_Lane
        Road.laneData[2]: Right_Lane
    */
    LaneData_Struct laneData[MAX_LANE_NUM];
    uint8_t     lineNum;
    /*
        Road..lineData[0]: Left_Line
        Road..lineData[1]: Right_Line
        Road..lineData[2]: LeftLeft_Line
        Road..lineData[3]: RightRight_Line    
    */
    LineData_Struct lineData[MAX_LINE_NUM];
    uint8_t     edgeNum;
    /*
        Road.edgeData[0]:Left boundary
        Road.edgeData[1]:Right boundary
    */
    EdgeData_Struct edgeData[MAX_EDGE_NUM];

} Road_struct;


typedef struct{
    int64_t     objTimeStamp;
    uint16_t    objID;
    bool        objValid;
    float       objExitProb;
    float       objIsobsProb;
    float       objLifeCycle;
    int64_t     fusionType;
    uint8_t     objType;
    float       objTypeProb;
    float       dxCenter;
    float       dxCenterStd;
    float       dyCenter;
    float       dyCenterStd;
    float       dxRef;
    float       dyRef;
    uint8_t     refPosition;
    float       dxRefSurface;
    float       dyRefSurface;
    uint8_t     surfacePos;
    float       vxRel;
    float       vyRel;
    float       axRel;
    float       ayRel;
    float       vxRelStd;
    float       vyRelStd;
    float       axRelStd;
    float       ayRelStd;
    float       vxAbs;
    float       vyAbs;
    float       axAbs;
    float       ayAbs;
    float       vxAbsStd;
    float       vyAbsStd;
    float       axAbsStd;
    float       ayAbsStd;
    float       yawAngle;
    float       yawAngleStd;
    float       azimuthAngle;
    float       azimuthAngleStd;
    float       yawRate;
    float       yawRateStd;
    float       objLength;
    float       objWidth;
    float       objHeight;
    float       objLengthStd;
    float       objWidthStd;
    float       objHeightStd;
    uint8_t     movingStatus;
    uint8_t     movingDirection;
    uint16_t    lightStatus;
    uint16_t    doorStatus;
    bool        trailerStatus;
    uint8_t     laneAssign;
    float       laneAssociateConf;
    float       laneLeftPortion;
    float       laneRightPortion;
    float       laneLeftConf;
    float       laneRightConf;
    uint8_t     objIntention;
    float       objIntentionProb;
    float       objTTC;
    uint8_t     objPosition;

}Object_Struct;

typedef struct{
    int64_t     timeStamp;
    uint8_t     objNum;
    Object_Struct objData[32];

}Objects_Struct;

typedef struct{
    float       longDist;
    float       latDist;
    float       yaw;
    float       vx;
    float       vy;
    float       yawRate;
    float       ax;
    float       ay;
    float       predTime;
    float       predProb;

}TrajectoryPoint_Struct;

typedef struct{
    uint16_t    objID;
    bool        objValid;
    int64_t     predTimeStamp;
    float       predPeriod;
    float       predProb;
    bool        isInteractive;
    float       predPiority;
    TrajectoryPoint_Struct  trajectoryPoints[30];

}ObjTraj_Struct;

typedef struct{
    int64_t     timeStamp;
    uint8_t     objTrajNum;
    ObjTraj_Struct objTrajData[32];

}ObjectsTraj_Struct;
