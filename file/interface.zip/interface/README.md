# interface

本仓是基于NEX开发的智驾各模块的message，包含base_msgs、sensors、vehicle_msgs、fusion_msgs等模块

## 下载代码

```
# 新建目录
mkdir -p ~/code/src
cd ~/code/src

# clone 代码仓
git clone git@scm-gitlab:ida/ad_alg/codes/platform/middleware/interface.git

# 切换到开发分支（如develop）
cd interface
git checkout develop
```

## 编译interface

```
# 在src目录下打开terminal编译interface
cd ~/code
colcon build
```

## 业务代码编译建议

可以将业务代码也放在src目录下，使用 colcon build --package-select xxx 编译
