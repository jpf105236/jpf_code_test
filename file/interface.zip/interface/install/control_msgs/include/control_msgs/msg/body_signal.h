// generated from nexidl_generator_c/resource/idl.h.em
// with input from control_msgs:msg/BodySignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__BODY_SIGNAL_H_
#define CONTROL_MSGS__MSG__BODY_SIGNAL_H_

#include "control_msgs/msg/detail/body_signal__struct.h"
#include "control_msgs/msg/detail/body_signal__functions.h"
#include "control_msgs/msg/detail/body_signal__type_support.h"

#endif  // CONTROL_MSGS__MSG__BODY_SIGNAL_H_
