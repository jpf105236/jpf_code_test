// generated from nexidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__BODY_SIGNAL_HPP_
#define CONTROL_MSGS__MSG__BODY_SIGNAL_HPP_

#include "control_msgs/msg/detail/body_signal__struct.hpp"
#include "control_msgs/msg/detail/body_signal__builder.hpp"
#include "control_msgs/msg/detail/body_signal__traits.hpp"

#endif  // CONTROL_MSGS__MSG__BODY_SIGNAL_HPP_
