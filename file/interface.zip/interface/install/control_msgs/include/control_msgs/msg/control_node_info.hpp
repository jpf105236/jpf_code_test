// generated from nexidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__CONTROL_NODE_INFO_HPP_
#define CONTROL_MSGS__MSG__CONTROL_NODE_INFO_HPP_

#include "control_msgs/msg/detail/control_node_info__struct.hpp"
#include "control_msgs/msg/detail/control_node_info__builder.hpp"
#include "control_msgs/msg/detail/control_node_info__traits.hpp"

#endif  // CONTROL_MSGS__MSG__CONTROL_NODE_INFO_HPP_
