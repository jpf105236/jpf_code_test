// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from control_msgs:msg/BodySignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__BUILDER_HPP_
#define CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__BUILDER_HPP_

#include "control_msgs/msg/detail/body_signal__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace control_msgs
{

namespace msg
{

namespace builder
{

class Init_BodySignal_windshield_brush_req_enum
{
public:
  explicit Init_BodySignal_windshield_brush_req_enum(::control_msgs::msg::BodySignal & msg)
  : msg_(msg)
  {}
  ::control_msgs::msg::BodySignal windshield_brush_req_enum(::control_msgs::msg::BodySignal::_windshield_brush_req_enum_type arg)
  {
    msg_.windshield_brush_req_enum = std::move(arg);
    return std::move(msg_);
  }

private:
  ::control_msgs::msg::BodySignal msg_;
};

class Init_BodySignal_right_back_window_req_enmu
{
public:
  explicit Init_BodySignal_right_back_window_req_enmu(::control_msgs::msg::BodySignal & msg)
  : msg_(msg)
  {}
  Init_BodySignal_windshield_brush_req_enum right_back_window_req_enmu(::control_msgs::msg::BodySignal::_right_back_window_req_enmu_type arg)
  {
    msg_.right_back_window_req_enmu = std::move(arg);
    return Init_BodySignal_windshield_brush_req_enum(msg_);
  }

private:
  ::control_msgs::msg::BodySignal msg_;
};

class Init_BodySignal_right_front_window_req_enmu
{
public:
  explicit Init_BodySignal_right_front_window_req_enmu(::control_msgs::msg::BodySignal & msg)
  : msg_(msg)
  {}
  Init_BodySignal_right_back_window_req_enmu right_front_window_req_enmu(::control_msgs::msg::BodySignal::_right_front_window_req_enmu_type arg)
  {
    msg_.right_front_window_req_enmu = std::move(arg);
    return Init_BodySignal_right_back_window_req_enmu(msg_);
  }

private:
  ::control_msgs::msg::BodySignal msg_;
};

class Init_BodySignal_left_back_window_req_enmu
{
public:
  explicit Init_BodySignal_left_back_window_req_enmu(::control_msgs::msg::BodySignal & msg)
  : msg_(msg)
  {}
  Init_BodySignal_right_front_window_req_enmu left_back_window_req_enmu(::control_msgs::msg::BodySignal::_left_back_window_req_enmu_type arg)
  {
    msg_.left_back_window_req_enmu = std::move(arg);
    return Init_BodySignal_right_front_window_req_enmu(msg_);
  }

private:
  ::control_msgs::msg::BodySignal msg_;
};

class Init_BodySignal_left_front_window_req_enmu
{
public:
  explicit Init_BodySignal_left_front_window_req_enmu(::control_msgs::msg::BodySignal & msg)
  : msg_(msg)
  {}
  Init_BodySignal_left_back_window_req_enmu left_front_window_req_enmu(::control_msgs::msg::BodySignal::_left_front_window_req_enmu_type arg)
  {
    msg_.left_front_window_req_enmu = std::move(arg);
    return Init_BodySignal_left_back_window_req_enmu(msg_);
  }

private:
  ::control_msgs::msg::BodySignal msg_;
};

class Init_BodySignal_right_dircn_ind_lamp_req_enum
{
public:
  explicit Init_BodySignal_right_dircn_ind_lamp_req_enum(::control_msgs::msg::BodySignal & msg)
  : msg_(msg)
  {}
  Init_BodySignal_left_front_window_req_enmu right_dircn_ind_lamp_req_enum(::control_msgs::msg::BodySignal::_right_dircn_ind_lamp_req_enum_type arg)
  {
    msg_.right_dircn_ind_lamp_req_enum = std::move(arg);
    return Init_BodySignal_left_front_window_req_enmu(msg_);
  }

private:
  ::control_msgs::msg::BodySignal msg_;
};

class Init_BodySignal_left_dircn_ind_lamp_req_enum
{
public:
  explicit Init_BodySignal_left_dircn_ind_lamp_req_enum(::control_msgs::msg::BodySignal & msg)
  : msg_(msg)
  {}
  Init_BodySignal_right_dircn_ind_lamp_req_enum left_dircn_ind_lamp_req_enum(::control_msgs::msg::BodySignal::_left_dircn_ind_lamp_req_enum_type arg)
  {
    msg_.left_dircn_ind_lamp_req_enum = std::move(arg);
    return Init_BodySignal_right_dircn_ind_lamp_req_enum(msg_);
  }

private:
  ::control_msgs::msg::BodySignal msg_;
};

class Init_BodySignal_side_mirror_mode_req_enum
{
public:
  Init_BodySignal_side_mirror_mode_req_enum()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BodySignal_left_dircn_ind_lamp_req_enum side_mirror_mode_req_enum(::control_msgs::msg::BodySignal::_side_mirror_mode_req_enum_type arg)
  {
    msg_.side_mirror_mode_req_enum = std::move(arg);
    return Init_BodySignal_left_dircn_ind_lamp_req_enum(msg_);
  }

private:
  ::control_msgs::msg::BodySignal msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::control_msgs::msg::BodySignal>()
{
  return control_msgs::msg::builder::Init_BodySignal_side_mirror_mode_req_enum();
}

}  // namespace control_msgs

#endif  // CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__BUILDER_HPP_
