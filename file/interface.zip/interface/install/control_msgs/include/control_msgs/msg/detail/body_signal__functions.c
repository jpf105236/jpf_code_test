// generated from nexidl_generator_c/resource/idl__functions.c.em
// with input from control_msgs:msg/BodySignal.idl
// generated code does not contain a copyright notice
#include "control_msgs/msg/detail/body_signal__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
control_msgs__msg__BodySignal__init(control_msgs__msg__BodySignal * msg)
{
  if (!msg) {
    return false;
  }
  // side_mirror_mode_req_enum
  // left_dircn_ind_lamp_req_enum
  // right_dircn_ind_lamp_req_enum
  // left_front_window_req_enmu
  // left_back_window_req_enmu
  // right_front_window_req_enmu
  // right_back_window_req_enmu
  // windshield_brush_req_enum
  return true;
}

void
control_msgs__msg__BodySignal__fini(control_msgs__msg__BodySignal * msg)
{
  if (!msg) {
    return;
  }
  // side_mirror_mode_req_enum
  // left_dircn_ind_lamp_req_enum
  // right_dircn_ind_lamp_req_enum
  // left_front_window_req_enmu
  // left_back_window_req_enmu
  // right_front_window_req_enmu
  // right_back_window_req_enmu
  // windshield_brush_req_enum
}

bool
control_msgs__msg__BodySignal__are_equal(const control_msgs__msg__BodySignal * lhs, const control_msgs__msg__BodySignal * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // side_mirror_mode_req_enum
  if (lhs->side_mirror_mode_req_enum != rhs->side_mirror_mode_req_enum) {
    return false;
  }
  // left_dircn_ind_lamp_req_enum
  if (lhs->left_dircn_ind_lamp_req_enum != rhs->left_dircn_ind_lamp_req_enum) {
    return false;
  }
  // right_dircn_ind_lamp_req_enum
  if (lhs->right_dircn_ind_lamp_req_enum != rhs->right_dircn_ind_lamp_req_enum) {
    return false;
  }
  // left_front_window_req_enmu
  if (lhs->left_front_window_req_enmu != rhs->left_front_window_req_enmu) {
    return false;
  }
  // left_back_window_req_enmu
  if (lhs->left_back_window_req_enmu != rhs->left_back_window_req_enmu) {
    return false;
  }
  // right_front_window_req_enmu
  if (lhs->right_front_window_req_enmu != rhs->right_front_window_req_enmu) {
    return false;
  }
  // right_back_window_req_enmu
  if (lhs->right_back_window_req_enmu != rhs->right_back_window_req_enmu) {
    return false;
  }
  // windshield_brush_req_enum
  if (lhs->windshield_brush_req_enum != rhs->windshield_brush_req_enum) {
    return false;
  }
  return true;
}

bool
control_msgs__msg__BodySignal__copy(
  const control_msgs__msg__BodySignal * input,
  control_msgs__msg__BodySignal * output)
{
  if (!input || !output) {
    return false;
  }
  // side_mirror_mode_req_enum
  output->side_mirror_mode_req_enum = input->side_mirror_mode_req_enum;
  // left_dircn_ind_lamp_req_enum
  output->left_dircn_ind_lamp_req_enum = input->left_dircn_ind_lamp_req_enum;
  // right_dircn_ind_lamp_req_enum
  output->right_dircn_ind_lamp_req_enum = input->right_dircn_ind_lamp_req_enum;
  // left_front_window_req_enmu
  output->left_front_window_req_enmu = input->left_front_window_req_enmu;
  // left_back_window_req_enmu
  output->left_back_window_req_enmu = input->left_back_window_req_enmu;
  // right_front_window_req_enmu
  output->right_front_window_req_enmu = input->right_front_window_req_enmu;
  // right_back_window_req_enmu
  output->right_back_window_req_enmu = input->right_back_window_req_enmu;
  // windshield_brush_req_enum
  output->windshield_brush_req_enum = input->windshield_brush_req_enum;
  return true;
}

control_msgs__msg__BodySignal *
control_msgs__msg__BodySignal__create()
{
  control_msgs__msg__BodySignal * msg = (control_msgs__msg__BodySignal *)malloc(sizeof(control_msgs__msg__BodySignal));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(control_msgs__msg__BodySignal));
  bool success = control_msgs__msg__BodySignal__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
control_msgs__msg__BodySignal__destroy(control_msgs__msg__BodySignal * msg)
{
  if (msg) {
    control_msgs__msg__BodySignal__fini(msg);
  }
  free(msg);
}


bool
control_msgs__msg__BodySignal__Sequence__init(control_msgs__msg__BodySignal__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  control_msgs__msg__BodySignal * data = NULL;
  if (size) {
    data = (control_msgs__msg__BodySignal *)calloc(size, sizeof(control_msgs__msg__BodySignal));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = control_msgs__msg__BodySignal__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        control_msgs__msg__BodySignal__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
control_msgs__msg__BodySignal__Sequence__fini(control_msgs__msg__BodySignal__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      control_msgs__msg__BodySignal__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

control_msgs__msg__BodySignal__Sequence *
control_msgs__msg__BodySignal__Sequence__create(size_t size)
{
  control_msgs__msg__BodySignal__Sequence * array = (control_msgs__msg__BodySignal__Sequence *)malloc(sizeof(control_msgs__msg__BodySignal__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = control_msgs__msg__BodySignal__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
control_msgs__msg__BodySignal__Sequence__destroy(control_msgs__msg__BodySignal__Sequence * array)
{
  if (array) {
    control_msgs__msg__BodySignal__Sequence__fini(array);
  }
  free(array);
}

bool
control_msgs__msg__BodySignal__Sequence__are_equal(const control_msgs__msg__BodySignal__Sequence * lhs, const control_msgs__msg__BodySignal__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!control_msgs__msg__BodySignal__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
control_msgs__msg__BodySignal__Sequence__copy(
  const control_msgs__msg__BodySignal__Sequence * input,
  control_msgs__msg__BodySignal__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(control_msgs__msg__BodySignal);
    control_msgs__msg__BodySignal * data =
      (control_msgs__msg__BodySignal *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!control_msgs__msg__BodySignal__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          control_msgs__msg__BodySignal__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!control_msgs__msg__BodySignal__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
