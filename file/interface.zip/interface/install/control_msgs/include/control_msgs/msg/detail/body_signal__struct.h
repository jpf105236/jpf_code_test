// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from control_msgs:msg/BodySignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__STRUCT_H_
#define CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/BodySignal in the package control_msgs.
typedef struct control_msgs__msg__BodySignal
{
  uint8_t side_mirror_mode_req_enum;
  uint8_t left_dircn_ind_lamp_req_enum;
  uint8_t right_dircn_ind_lamp_req_enum;
  uint8_t left_front_window_req_enmu;
  uint8_t left_back_window_req_enmu;
  uint8_t right_front_window_req_enmu;
  uint8_t right_back_window_req_enmu;
  uint8_t windshield_brush_req_enum;
} control_msgs__msg__BodySignal;

// Struct for a sequence of control_msgs__msg__BodySignal.
typedef struct control_msgs__msg__BodySignal__Sequence
{
  control_msgs__msg__BodySignal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} control_msgs__msg__BodySignal__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__STRUCT_H_
