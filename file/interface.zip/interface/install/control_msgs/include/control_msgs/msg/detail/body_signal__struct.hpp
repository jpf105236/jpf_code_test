// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from control_msgs:msg/BodySignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__STRUCT_HPP_
#define CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__control_msgs__msg__BodySignal __attribute__((deprecated))
#else
# define DEPRECATED__control_msgs__msg__BodySignal __declspec(deprecated)
#endif

namespace control_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BodySignal_
{
  using Type = BodySignal_<ContainerAllocator>;

  explicit BodySignal_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->side_mirror_mode_req_enum = 0;
      this->left_dircn_ind_lamp_req_enum = 0;
      this->right_dircn_ind_lamp_req_enum = 0;
      this->left_front_window_req_enmu = 0;
      this->left_back_window_req_enmu = 0;
      this->right_front_window_req_enmu = 0;
      this->right_back_window_req_enmu = 0;
      this->windshield_brush_req_enum = 0;
    }
  }

  explicit BodySignal_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->side_mirror_mode_req_enum = 0;
      this->left_dircn_ind_lamp_req_enum = 0;
      this->right_dircn_ind_lamp_req_enum = 0;
      this->left_front_window_req_enmu = 0;
      this->left_back_window_req_enmu = 0;
      this->right_front_window_req_enmu = 0;
      this->right_back_window_req_enmu = 0;
      this->windshield_brush_req_enum = 0;
    }
  }

  // field types and members
  using _side_mirror_mode_req_enum_type =
    uint8_t;
  _side_mirror_mode_req_enum_type side_mirror_mode_req_enum;
  using _left_dircn_ind_lamp_req_enum_type =
    uint8_t;
  _left_dircn_ind_lamp_req_enum_type left_dircn_ind_lamp_req_enum;
  using _right_dircn_ind_lamp_req_enum_type =
    uint8_t;
  _right_dircn_ind_lamp_req_enum_type right_dircn_ind_lamp_req_enum;
  using _left_front_window_req_enmu_type =
    uint8_t;
  _left_front_window_req_enmu_type left_front_window_req_enmu;
  using _left_back_window_req_enmu_type =
    uint8_t;
  _left_back_window_req_enmu_type left_back_window_req_enmu;
  using _right_front_window_req_enmu_type =
    uint8_t;
  _right_front_window_req_enmu_type right_front_window_req_enmu;
  using _right_back_window_req_enmu_type =
    uint8_t;
  _right_back_window_req_enmu_type right_back_window_req_enmu;
  using _windshield_brush_req_enum_type =
    uint8_t;
  _windshield_brush_req_enum_type windshield_brush_req_enum;

  // setters for named parameter idiom
  Type & set__side_mirror_mode_req_enum(
    const uint8_t & _arg)
  {
    this->side_mirror_mode_req_enum = _arg;
    return *this;
  }
  Type & set__left_dircn_ind_lamp_req_enum(
    const uint8_t & _arg)
  {
    this->left_dircn_ind_lamp_req_enum = _arg;
    return *this;
  }
  Type & set__right_dircn_ind_lamp_req_enum(
    const uint8_t & _arg)
  {
    this->right_dircn_ind_lamp_req_enum = _arg;
    return *this;
  }
  Type & set__left_front_window_req_enmu(
    const uint8_t & _arg)
  {
    this->left_front_window_req_enmu = _arg;
    return *this;
  }
  Type & set__left_back_window_req_enmu(
    const uint8_t & _arg)
  {
    this->left_back_window_req_enmu = _arg;
    return *this;
  }
  Type & set__right_front_window_req_enmu(
    const uint8_t & _arg)
  {
    this->right_front_window_req_enmu = _arg;
    return *this;
  }
  Type & set__right_back_window_req_enmu(
    const uint8_t & _arg)
  {
    this->right_back_window_req_enmu = _arg;
    return *this;
  }
  Type & set__windshield_brush_req_enum(
    const uint8_t & _arg)
  {
    this->windshield_brush_req_enum = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    control_msgs::msg::BodySignal_<ContainerAllocator> *;
  using ConstRawPtr =
    const control_msgs::msg::BodySignal_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<control_msgs::msg::BodySignal_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<control_msgs::msg::BodySignal_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      control_msgs::msg::BodySignal_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<control_msgs::msg::BodySignal_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      control_msgs::msg::BodySignal_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<control_msgs::msg::BodySignal_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<control_msgs::msg::BodySignal_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<control_msgs::msg::BodySignal_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__control_msgs__msg__BodySignal
    std::shared_ptr<control_msgs::msg::BodySignal_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__control_msgs__msg__BodySignal
    std::shared_ptr<control_msgs::msg::BodySignal_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BodySignal_ & other) const
  {
    if (this->side_mirror_mode_req_enum != other.side_mirror_mode_req_enum) {
      return false;
    }
    if (this->left_dircn_ind_lamp_req_enum != other.left_dircn_ind_lamp_req_enum) {
      return false;
    }
    if (this->right_dircn_ind_lamp_req_enum != other.right_dircn_ind_lamp_req_enum) {
      return false;
    }
    if (this->left_front_window_req_enmu != other.left_front_window_req_enmu) {
      return false;
    }
    if (this->left_back_window_req_enmu != other.left_back_window_req_enmu) {
      return false;
    }
    if (this->right_front_window_req_enmu != other.right_front_window_req_enmu) {
      return false;
    }
    if (this->right_back_window_req_enmu != other.right_back_window_req_enmu) {
      return false;
    }
    if (this->windshield_brush_req_enum != other.windshield_brush_req_enum) {
      return false;
    }
    return true;
  }
  bool operator!=(const BodySignal_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BodySignal_

// alias to use template instance with default allocator
using BodySignal =
  control_msgs::msg::BodySignal_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace control_msgs

#endif  // CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__STRUCT_HPP_
