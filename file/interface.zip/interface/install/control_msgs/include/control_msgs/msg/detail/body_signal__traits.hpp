// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from control_msgs:msg/BodySignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__TRAITS_HPP_
#define CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__TRAITS_HPP_

#include "control_msgs/msg/detail/body_signal__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace nexidl_generator_traits
{

inline void to_yaml(
  const control_msgs::msg::BodySignal & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: side_mirror_mode_req_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "side_mirror_mode_req_enum: ";
    value_to_yaml(msg.side_mirror_mode_req_enum, out);
    out << "\n";
  }

  // member: left_dircn_ind_lamp_req_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left_dircn_ind_lamp_req_enum: ";
    value_to_yaml(msg.left_dircn_ind_lamp_req_enum, out);
    out << "\n";
  }

  // member: right_dircn_ind_lamp_req_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "right_dircn_ind_lamp_req_enum: ";
    value_to_yaml(msg.right_dircn_ind_lamp_req_enum, out);
    out << "\n";
  }

  // member: left_front_window_req_enmu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left_front_window_req_enmu: ";
    value_to_yaml(msg.left_front_window_req_enmu, out);
    out << "\n";
  }

  // member: left_back_window_req_enmu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left_back_window_req_enmu: ";
    value_to_yaml(msg.left_back_window_req_enmu, out);
    out << "\n";
  }

  // member: right_front_window_req_enmu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "right_front_window_req_enmu: ";
    value_to_yaml(msg.right_front_window_req_enmu, out);
    out << "\n";
  }

  // member: right_back_window_req_enmu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "right_back_window_req_enmu: ";
    value_to_yaml(msg.right_back_window_req_enmu, out);
    out << "\n";
  }

  // member: windshield_brush_req_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "windshield_brush_req_enum: ";
    value_to_yaml(msg.windshield_brush_req_enum, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const control_msgs::msg::BodySignal & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<control_msgs::msg::BodySignal>()
{
  return "control_msgs::msg::BodySignal";
}

template<>
inline const char * name<control_msgs::msg::BodySignal>()
{
  return "control_msgs/msg/BodySignal";
}

template<>
struct has_fixed_size<control_msgs::msg::BodySignal>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<control_msgs::msg::BodySignal>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<control_msgs::msg::BodySignal>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // CONTROL_MSGS__MSG__DETAIL__BODY_SIGNAL__TRAITS_HPP_
