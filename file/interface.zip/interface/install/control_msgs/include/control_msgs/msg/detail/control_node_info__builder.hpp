// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from control_msgs:msg/ControlNodeInfo.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__BUILDER_HPP_
#define CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__BUILDER_HPP_

#include "control_msgs/msg/detail/control_node_info__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace control_msgs
{

namespace msg
{

namespace builder
{

class Init_ControlNodeInfo_control_abort_reason_bit
{
public:
  explicit Init_ControlNodeInfo_control_abort_reason_bit(::control_msgs::msg::ControlNodeInfo & msg)
  : msg_(msg)
  {}
  ::control_msgs::msg::ControlNodeInfo control_abort_reason_bit(::control_msgs::msg::ControlNodeInfo::_control_abort_reason_bit_type arg)
  {
    msg_.control_abort_reason_bit = std::move(arg);
    return std::move(msg_);
  }

private:
  ::control_msgs::msg::ControlNodeInfo msg_;
};

class Init_ControlNodeInfo_control_mode
{
public:
  explicit Init_ControlNodeInfo_control_mode(::control_msgs::msg::ControlNodeInfo & msg)
  : msg_(msg)
  {}
  Init_ControlNodeInfo_control_abort_reason_bit control_mode(::control_msgs::msg::ControlNodeInfo::_control_mode_type arg)
  {
    msg_.control_mode = std::move(arg);
    return Init_ControlNodeInfo_control_abort_reason_bit(msg_);
  }

private:
  ::control_msgs::msg::ControlNodeInfo msg_;
};

class Init_ControlNodeInfo_control_status
{
public:
  Init_ControlNodeInfo_control_status()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ControlNodeInfo_control_mode control_status(::control_msgs::msg::ControlNodeInfo::_control_status_type arg)
  {
    msg_.control_status = std::move(arg);
    return Init_ControlNodeInfo_control_mode(msg_);
  }

private:
  ::control_msgs::msg::ControlNodeInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::control_msgs::msg::ControlNodeInfo>()
{
  return control_msgs::msg::builder::Init_ControlNodeInfo_control_status();
}

}  // namespace control_msgs

#endif  // CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__BUILDER_HPP_
