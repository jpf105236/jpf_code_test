// generated from nexidl_typesupport_introspection_c/resource/idl__nexidl_typesupport_introspection_c.h.em
// with input from control_msgs:msg/ControlNodeInfo.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__NEXIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__NEXIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "nexidl_runtime_c/message_type_support_struct.h"
#include "nexidl_typesupport_interface/macros.h"
#include "control_msgs/msg/nexidl_typesupport_introspection_c__visibility_control.h"

NEXIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_control_msgs
const nexidl_message_type_support_t *
NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, control_msgs, msg, ControlNodeInfo)();

#ifdef __cplusplus
}
#endif

#endif  // CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__NEXIDL_TYPESUPPORT_INTROSPECTION_C_H_
