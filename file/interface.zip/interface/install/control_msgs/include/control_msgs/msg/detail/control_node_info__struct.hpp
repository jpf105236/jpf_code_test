// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from control_msgs:msg/ControlNodeInfo.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__STRUCT_HPP_
#define CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__control_msgs__msg__ControlNodeInfo __attribute__((deprecated))
#else
# define DEPRECATED__control_msgs__msg__ControlNodeInfo __declspec(deprecated)
#endif

namespace control_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ControlNodeInfo_
{
  using Type = ControlNodeInfo_<ContainerAllocator>;

  explicit ControlNodeInfo_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->control_status = 0;
      this->control_mode = 0;
      this->control_abort_reason_bit = 0ull;
    }
  }

  explicit ControlNodeInfo_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->control_status = 0;
      this->control_mode = 0;
      this->control_abort_reason_bit = 0ull;
    }
  }

  // field types and members
  using _control_status_type =
    uint16_t;
  _control_status_type control_status;
  using _control_mode_type =
    uint16_t;
  _control_mode_type control_mode;
  using _control_abort_reason_bit_type =
    uint64_t;
  _control_abort_reason_bit_type control_abort_reason_bit;

  // setters for named parameter idiom
  Type & set__control_status(
    const uint16_t & _arg)
  {
    this->control_status = _arg;
    return *this;
  }
  Type & set__control_mode(
    const uint16_t & _arg)
  {
    this->control_mode = _arg;
    return *this;
  }
  Type & set__control_abort_reason_bit(
    const uint64_t & _arg)
  {
    this->control_abort_reason_bit = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    control_msgs::msg::ControlNodeInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const control_msgs::msg::ControlNodeInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<control_msgs::msg::ControlNodeInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<control_msgs::msg::ControlNodeInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      control_msgs::msg::ControlNodeInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<control_msgs::msg::ControlNodeInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      control_msgs::msg::ControlNodeInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<control_msgs::msg::ControlNodeInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<control_msgs::msg::ControlNodeInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<control_msgs::msg::ControlNodeInfo_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__control_msgs__msg__ControlNodeInfo
    std::shared_ptr<control_msgs::msg::ControlNodeInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__control_msgs__msg__ControlNodeInfo
    std::shared_ptr<control_msgs::msg::ControlNodeInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ControlNodeInfo_ & other) const
  {
    if (this->control_status != other.control_status) {
      return false;
    }
    if (this->control_mode != other.control_mode) {
      return false;
    }
    if (this->control_abort_reason_bit != other.control_abort_reason_bit) {
      return false;
    }
    return true;
  }
  bool operator!=(const ControlNodeInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ControlNodeInfo_

// alias to use template instance with default allocator
using ControlNodeInfo =
  control_msgs::msg::ControlNodeInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace control_msgs

#endif  // CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__STRUCT_HPP_
