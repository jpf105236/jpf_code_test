// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from control_msgs:msg/ControlNodeInfo.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__TRAITS_HPP_
#define CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__TRAITS_HPP_

#include "control_msgs/msg/detail/control_node_info__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace nexidl_generator_traits
{

inline void to_yaml(
  const control_msgs::msg::ControlNodeInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: control_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_status: ";
    value_to_yaml(msg.control_status, out);
    out << "\n";
  }

  // member: control_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_mode: ";
    value_to_yaml(msg.control_mode, out);
    out << "\n";
  }

  // member: control_abort_reason_bit
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_abort_reason_bit: ";
    value_to_yaml(msg.control_abort_reason_bit, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const control_msgs::msg::ControlNodeInfo & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<control_msgs::msg::ControlNodeInfo>()
{
  return "control_msgs::msg::ControlNodeInfo";
}

template<>
inline const char * name<control_msgs::msg::ControlNodeInfo>()
{
  return "control_msgs/msg/ControlNodeInfo";
}

template<>
struct has_fixed_size<control_msgs::msg::ControlNodeInfo>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<control_msgs::msg::ControlNodeInfo>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<control_msgs::msg::ControlNodeInfo>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // CONTROL_MSGS__MSG__DETAIL__CONTROL_NODE_INFO__TRAITS_HPP_
