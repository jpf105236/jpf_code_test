// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from control_msgs:msg/ControlOut.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__BUILDER_HPP_
#define CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__BUILDER_HPP_

#include "control_msgs/msg/detail/control_out__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace control_msgs
{

namespace msg
{

namespace builder
{

class Init_ControlOut_body_signal
{
public:
  explicit Init_ControlOut_body_signal(::control_msgs::msg::ControlOut & msg)
  : msg_(msg)
  {}
  ::control_msgs::msg::ControlOut body_signal(::control_msgs::msg::ControlOut::_body_signal_type arg)
  {
    msg_.body_signal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::control_msgs::msg::ControlOut msg_;
};

class Init_ControlOut_long_signal
{
public:
  explicit Init_ControlOut_long_signal(::control_msgs::msg::ControlOut & msg)
  : msg_(msg)
  {}
  Init_ControlOut_body_signal long_signal(::control_msgs::msg::ControlOut::_long_signal_type arg)
  {
    msg_.long_signal = std::move(arg);
    return Init_ControlOut_body_signal(msg_);
  }

private:
  ::control_msgs::msg::ControlOut msg_;
};

class Init_ControlOut_lat_signal
{
public:
  explicit Init_ControlOut_lat_signal(::control_msgs::msg::ControlOut & msg)
  : msg_(msg)
  {}
  Init_ControlOut_long_signal lat_signal(::control_msgs::msg::ControlOut::_lat_signal_type arg)
  {
    msg_.lat_signal = std::move(arg);
    return Init_ControlOut_long_signal(msg_);
  }

private:
  ::control_msgs::msg::ControlOut msg_;
};

class Init_ControlOut_control_node_info
{
public:
  explicit Init_ControlOut_control_node_info(::control_msgs::msg::ControlOut & msg)
  : msg_(msg)
  {}
  Init_ControlOut_lat_signal control_node_info(::control_msgs::msg::ControlOut::_control_node_info_type arg)
  {
    msg_.control_node_info = std::move(arg);
    return Init_ControlOut_lat_signal(msg_);
  }

private:
  ::control_msgs::msg::ControlOut msg_;
};

class Init_ControlOut_std_header
{
public:
  Init_ControlOut_std_header()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ControlOut_control_node_info std_header(::control_msgs::msg::ControlOut::_std_header_type arg)
  {
    msg_.std_header = std::move(arg);
    return Init_ControlOut_control_node_info(msg_);
  }

private:
  ::control_msgs::msg::ControlOut msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::control_msgs::msg::ControlOut>()
{
  return control_msgs::msg::builder::Init_ControlOut_std_header();
}

}  // namespace control_msgs

#endif  // CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__BUILDER_HPP_
