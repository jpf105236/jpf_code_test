// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from control_msgs:msg/ControlOut.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__STRUCT_H_
#define CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'std_header'
#include "base_msgs/msg/detail/header__struct.h"
// Member 'control_node_info'
#include "control_msgs/msg/detail/control_node_info__struct.h"
// Member 'lat_signal'
#include "control_msgs/msg/detail/lateral_signal__struct.h"
// Member 'long_signal'
#include "control_msgs/msg/detail/longitudinal_signal__struct.h"
// Member 'body_signal'
#include "control_msgs/msg/detail/body_signal__struct.h"

// Struct defined in msg/ControlOut in the package control_msgs.
typedef struct control_msgs__msg__ControlOut
{
  base_msgs__msg__Header std_header;
  control_msgs__msg__ControlNodeInfo control_node_info;
  control_msgs__msg__LateralSignal lat_signal;
  control_msgs__msg__LongitudinalSignal long_signal;
  control_msgs__msg__BodySignal body_signal;
} control_msgs__msg__ControlOut;

// Struct for a sequence of control_msgs__msg__ControlOut.
typedef struct control_msgs__msg__ControlOut__Sequence
{
  control_msgs__msg__ControlOut * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} control_msgs__msg__ControlOut__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__STRUCT_H_
