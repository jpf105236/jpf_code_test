// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from control_msgs:msg/ControlOut.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__STRUCT_HPP_
#define CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'std_header'
#include "base_msgs/msg/detail/header__struct.hpp"
// Member 'control_node_info'
#include "control_msgs/msg/detail/control_node_info__struct.hpp"
// Member 'lat_signal'
#include "control_msgs/msg/detail/lateral_signal__struct.hpp"
// Member 'long_signal'
#include "control_msgs/msg/detail/longitudinal_signal__struct.hpp"
// Member 'body_signal'
#include "control_msgs/msg/detail/body_signal__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__control_msgs__msg__ControlOut __attribute__((deprecated))
#else
# define DEPRECATED__control_msgs__msg__ControlOut __declspec(deprecated)
#endif

namespace control_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ControlOut_
{
  using Type = ControlOut_<ContainerAllocator>;

  explicit ControlOut_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : std_header(_init),
    control_node_info(_init),
    lat_signal(_init),
    long_signal(_init),
    body_signal(_init)
  {
    (void)_init;
  }

  explicit ControlOut_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : std_header(_alloc, _init),
    control_node_info(_alloc, _init),
    lat_signal(_alloc, _init),
    long_signal(_alloc, _init),
    body_signal(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _std_header_type =
    base_msgs::msg::Header_<ContainerAllocator>;
  _std_header_type std_header;
  using _control_node_info_type =
    control_msgs::msg::ControlNodeInfo_<ContainerAllocator>;
  _control_node_info_type control_node_info;
  using _lat_signal_type =
    control_msgs::msg::LateralSignal_<ContainerAllocator>;
  _lat_signal_type lat_signal;
  using _long_signal_type =
    control_msgs::msg::LongitudinalSignal_<ContainerAllocator>;
  _long_signal_type long_signal;
  using _body_signal_type =
    control_msgs::msg::BodySignal_<ContainerAllocator>;
  _body_signal_type body_signal;

  // setters for named parameter idiom
  Type & set__std_header(
    const base_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->std_header = _arg;
    return *this;
  }
  Type & set__control_node_info(
    const control_msgs::msg::ControlNodeInfo_<ContainerAllocator> & _arg)
  {
    this->control_node_info = _arg;
    return *this;
  }
  Type & set__lat_signal(
    const control_msgs::msg::LateralSignal_<ContainerAllocator> & _arg)
  {
    this->lat_signal = _arg;
    return *this;
  }
  Type & set__long_signal(
    const control_msgs::msg::LongitudinalSignal_<ContainerAllocator> & _arg)
  {
    this->long_signal = _arg;
    return *this;
  }
  Type & set__body_signal(
    const control_msgs::msg::BodySignal_<ContainerAllocator> & _arg)
  {
    this->body_signal = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    control_msgs::msg::ControlOut_<ContainerAllocator> *;
  using ConstRawPtr =
    const control_msgs::msg::ControlOut_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<control_msgs::msg::ControlOut_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<control_msgs::msg::ControlOut_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      control_msgs::msg::ControlOut_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<control_msgs::msg::ControlOut_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      control_msgs::msg::ControlOut_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<control_msgs::msg::ControlOut_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<control_msgs::msg::ControlOut_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<control_msgs::msg::ControlOut_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__control_msgs__msg__ControlOut
    std::shared_ptr<control_msgs::msg::ControlOut_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__control_msgs__msg__ControlOut
    std::shared_ptr<control_msgs::msg::ControlOut_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ControlOut_ & other) const
  {
    if (this->std_header != other.std_header) {
      return false;
    }
    if (this->control_node_info != other.control_node_info) {
      return false;
    }
    if (this->lat_signal != other.lat_signal) {
      return false;
    }
    if (this->long_signal != other.long_signal) {
      return false;
    }
    if (this->body_signal != other.body_signal) {
      return false;
    }
    return true;
  }
  bool operator!=(const ControlOut_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ControlOut_

// alias to use template instance with default allocator
using ControlOut =
  control_msgs::msg::ControlOut_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace control_msgs

#endif  // CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__STRUCT_HPP_
