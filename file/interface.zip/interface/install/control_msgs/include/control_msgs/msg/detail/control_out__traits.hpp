// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from control_msgs:msg/ControlOut.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__TRAITS_HPP_
#define CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__TRAITS_HPP_

#include "control_msgs/msg/detail/control_out__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'std_header'
#include "base_msgs/msg/detail/header__traits.hpp"
// Member 'control_node_info'
#include "control_msgs/msg/detail/control_node_info__traits.hpp"
// Member 'lat_signal'
#include "control_msgs/msg/detail/lateral_signal__traits.hpp"
// Member 'long_signal'
#include "control_msgs/msg/detail/longitudinal_signal__traits.hpp"
// Member 'body_signal'
#include "control_msgs/msg/detail/body_signal__traits.hpp"

namespace nexidl_generator_traits
{

inline void to_yaml(
  const control_msgs::msg::ControlOut & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: std_header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "std_header:\n";
    to_yaml(msg.std_header, out, indentation + 2);
  }

  // member: control_node_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_node_info:\n";
    to_yaml(msg.control_node_info, out, indentation + 2);
  }

  // member: lat_signal
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lat_signal:\n";
    to_yaml(msg.lat_signal, out, indentation + 2);
  }

  // member: long_signal
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "long_signal:\n";
    to_yaml(msg.long_signal, out, indentation + 2);
  }

  // member: body_signal
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "body_signal:\n";
    to_yaml(msg.body_signal, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const control_msgs::msg::ControlOut & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<control_msgs::msg::ControlOut>()
{
  return "control_msgs::msg::ControlOut";
}

template<>
inline const char * name<control_msgs::msg::ControlOut>()
{
  return "control_msgs/msg/ControlOut";
}

template<>
struct has_fixed_size<control_msgs::msg::ControlOut>
  : std::integral_constant<bool, has_fixed_size<base_msgs::msg::Header>::value && has_fixed_size<control_msgs::msg::BodySignal>::value && has_fixed_size<control_msgs::msg::ControlNodeInfo>::value && has_fixed_size<control_msgs::msg::LateralSignal>::value && has_fixed_size<control_msgs::msg::LongitudinalSignal>::value> {};

template<>
struct has_bounded_size<control_msgs::msg::ControlOut>
  : std::integral_constant<bool, has_bounded_size<base_msgs::msg::Header>::value && has_bounded_size<control_msgs::msg::BodySignal>::value && has_bounded_size<control_msgs::msg::ControlNodeInfo>::value && has_bounded_size<control_msgs::msg::LateralSignal>::value && has_bounded_size<control_msgs::msg::LongitudinalSignal>::value> {};

template<>
struct is_message<control_msgs::msg::ControlOut>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // CONTROL_MSGS__MSG__DETAIL__CONTROL_OUT__TRAITS_HPP_
