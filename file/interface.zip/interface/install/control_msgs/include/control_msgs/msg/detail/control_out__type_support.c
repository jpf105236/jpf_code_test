// generated from nexidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from control_msgs:msg/ControlOut.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "control_msgs/msg/detail/control_out__nexidl_typesupport_introspection_c.h"
#include "control_msgs/msg/nexidl_typesupport_introspection_c__visibility_control.h"
#include "nexidl_typesupport_introspection_c/field_types.h"
#include "nexidl_typesupport_introspection_c/identifier.h"
#include "nexidl_typesupport_introspection_c/message_introspection.h"
#include "control_msgs/msg/detail/control_out__functions.h"
#include "control_msgs/msg/detail/control_out__struct.h"


// Include directives for member types
// Member `std_header`
#include "base_msgs/msg/header.h"
// Member `std_header`
#include "base_msgs/msg/detail/header__nexidl_typesupport_introspection_c.h"
// Member `control_node_info`
#include "control_msgs/msg/control_node_info.h"
// Member `control_node_info`
#include "control_msgs/msg/detail/control_node_info__nexidl_typesupport_introspection_c.h"
// Member `lat_signal`
#include "control_msgs/msg/lateral_signal.h"
// Member `lat_signal`
#include "control_msgs/msg/detail/lateral_signal__nexidl_typesupport_introspection_c.h"
// Member `long_signal`
#include "control_msgs/msg/longitudinal_signal.h"
// Member `long_signal`
#include "control_msgs/msg/detail/longitudinal_signal__nexidl_typesupport_introspection_c.h"
// Member `body_signal`
#include "control_msgs/msg/body_signal.h"
// Member `body_signal`
#include "control_msgs/msg/detail/body_signal__nexidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void ControlOut__nexidl_typesupport_introspection_c__ControlOut_init_function(
  void * message_memory, enum nexidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/nex/nex/issues/397
  (void) _init;
  control_msgs__msg__ControlOut__init(message_memory);
}

void ControlOut__nexidl_typesupport_introspection_c__ControlOut_fini_function(void * message_memory)
{
  control_msgs__msg__ControlOut__fini(message_memory);
}

static nexidl_typesupport_introspection_c__MessageMember ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_member_array[5] = {
  {
    "std_header",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__ControlOut, std_header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "control_node_info",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__ControlOut, control_node_info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "lat_signal",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__ControlOut, lat_signal),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "long_signal",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__ControlOut, long_signal),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "body_signal",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__ControlOut, body_signal),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const nexidl_typesupport_introspection_c__MessageMembers ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_members = {
  "control_msgs__msg",  // message namespace
  "ControlOut",  // message name
  5,  // number of fields
  sizeof(control_msgs__msg__ControlOut),
  ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_member_array,  // message members
  ControlOut__nexidl_typesupport_introspection_c__ControlOut_init_function,  // function to initialize message memory (memory has to be allocated)
  ControlOut__nexidl_typesupport_introspection_c__ControlOut_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static nexidl_message_type_support_t ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_type_support_handle = {
  0,
  &ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_members,
  get_message_typesupport_handle_function,
};

NEXIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_control_msgs
const nexidl_message_type_support_t *
NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, control_msgs, msg, ControlOut)() {
  ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_member_array[0].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, base_msgs, msg, Header)();
  ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_member_array[1].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, control_msgs, msg, ControlNodeInfo)();
  ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_member_array[2].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, control_msgs, msg, LateralSignal)();
  ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_member_array[3].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, control_msgs, msg, LongitudinalSignal)();
  ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_member_array[4].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, control_msgs, msg, BodySignal)();
  if (!ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_type_support_handle.typesupport_identifier) {
    ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_type_support_handle.typesupport_identifier =
      nexidl_typesupport_introspection_c__identifier;
  }
  return &ControlOut__nexidl_typesupport_introspection_c__ControlOut_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
