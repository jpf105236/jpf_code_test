// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from control_msgs:msg/LateralSignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__LATERAL_SIGNAL__BUILDER_HPP_
#define CONTROL_MSGS__MSG__DETAIL__LATERAL_SIGNAL__BUILDER_HPP_

#include "control_msgs/msg/detail/lateral_signal__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace control_msgs
{

namespace msg
{

namespace builder
{

class Init_LateralSignal_is_tgt_pnn_ang_fl_eps_pnn_ang
{
public:
  explicit Init_LateralSignal_is_tgt_pnn_ang_fl_eps_pnn_ang(::control_msgs::msg::LateralSignal & msg)
  : msg_(msg)
  {}
  ::control_msgs::msg::LateralSignal is_tgt_pnn_ang_fl_eps_pnn_ang(::control_msgs::msg::LateralSignal::_is_tgt_pnn_ang_fl_eps_pnn_ang_type arg)
  {
    msg_.is_tgt_pnn_ang_fl_eps_pnn_ang = std::move(arg);
    return std::move(msg_);
  }

private:
  ::control_msgs::msg::LateralSignal msg_;
};

class Init_LateralSignal_tgt_pnn_ang_req_deg
{
public:
  Init_LateralSignal_tgt_pnn_ang_req_deg()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LateralSignal_is_tgt_pnn_ang_fl_eps_pnn_ang tgt_pnn_ang_req_deg(::control_msgs::msg::LateralSignal::_tgt_pnn_ang_req_deg_type arg)
  {
    msg_.tgt_pnn_ang_req_deg = std::move(arg);
    return Init_LateralSignal_is_tgt_pnn_ang_fl_eps_pnn_ang(msg_);
  }

private:
  ::control_msgs::msg::LateralSignal msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::control_msgs::msg::LateralSignal>()
{
  return control_msgs::msg::builder::Init_LateralSignal_tgt_pnn_ang_req_deg();
}

}  // namespace control_msgs

#endif  // CONTROL_MSGS__MSG__DETAIL__LATERAL_SIGNAL__BUILDER_HPP_
