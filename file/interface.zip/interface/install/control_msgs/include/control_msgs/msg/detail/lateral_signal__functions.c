// generated from nexidl_generator_c/resource/idl__functions.c.em
// with input from control_msgs:msg/LateralSignal.idl
// generated code does not contain a copyright notice
#include "control_msgs/msg/detail/lateral_signal__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
control_msgs__msg__LateralSignal__init(control_msgs__msg__LateralSignal * msg)
{
  if (!msg) {
    return false;
  }
  // tgt_pnn_ang_req_deg
  // is_tgt_pnn_ang_fl_eps_pnn_ang
  return true;
}

void
control_msgs__msg__LateralSignal__fini(control_msgs__msg__LateralSignal * msg)
{
  if (!msg) {
    return;
  }
  // tgt_pnn_ang_req_deg
  // is_tgt_pnn_ang_fl_eps_pnn_ang
}

bool
control_msgs__msg__LateralSignal__are_equal(const control_msgs__msg__LateralSignal * lhs, const control_msgs__msg__LateralSignal * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // tgt_pnn_ang_req_deg
  if (lhs->tgt_pnn_ang_req_deg != rhs->tgt_pnn_ang_req_deg) {
    return false;
  }
  // is_tgt_pnn_ang_fl_eps_pnn_ang
  if (lhs->is_tgt_pnn_ang_fl_eps_pnn_ang != rhs->is_tgt_pnn_ang_fl_eps_pnn_ang) {
    return false;
  }
  return true;
}

bool
control_msgs__msg__LateralSignal__copy(
  const control_msgs__msg__LateralSignal * input,
  control_msgs__msg__LateralSignal * output)
{
  if (!input || !output) {
    return false;
  }
  // tgt_pnn_ang_req_deg
  output->tgt_pnn_ang_req_deg = input->tgt_pnn_ang_req_deg;
  // is_tgt_pnn_ang_fl_eps_pnn_ang
  output->is_tgt_pnn_ang_fl_eps_pnn_ang = input->is_tgt_pnn_ang_fl_eps_pnn_ang;
  return true;
}

control_msgs__msg__LateralSignal *
control_msgs__msg__LateralSignal__create()
{
  control_msgs__msg__LateralSignal * msg = (control_msgs__msg__LateralSignal *)malloc(sizeof(control_msgs__msg__LateralSignal));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(control_msgs__msg__LateralSignal));
  bool success = control_msgs__msg__LateralSignal__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
control_msgs__msg__LateralSignal__destroy(control_msgs__msg__LateralSignal * msg)
{
  if (msg) {
    control_msgs__msg__LateralSignal__fini(msg);
  }
  free(msg);
}


bool
control_msgs__msg__LateralSignal__Sequence__init(control_msgs__msg__LateralSignal__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  control_msgs__msg__LateralSignal * data = NULL;
  if (size) {
    data = (control_msgs__msg__LateralSignal *)calloc(size, sizeof(control_msgs__msg__LateralSignal));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = control_msgs__msg__LateralSignal__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        control_msgs__msg__LateralSignal__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
control_msgs__msg__LateralSignal__Sequence__fini(control_msgs__msg__LateralSignal__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      control_msgs__msg__LateralSignal__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

control_msgs__msg__LateralSignal__Sequence *
control_msgs__msg__LateralSignal__Sequence__create(size_t size)
{
  control_msgs__msg__LateralSignal__Sequence * array = (control_msgs__msg__LateralSignal__Sequence *)malloc(sizeof(control_msgs__msg__LateralSignal__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = control_msgs__msg__LateralSignal__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
control_msgs__msg__LateralSignal__Sequence__destroy(control_msgs__msg__LateralSignal__Sequence * array)
{
  if (array) {
    control_msgs__msg__LateralSignal__Sequence__fini(array);
  }
  free(array);
}

bool
control_msgs__msg__LateralSignal__Sequence__are_equal(const control_msgs__msg__LateralSignal__Sequence * lhs, const control_msgs__msg__LateralSignal__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!control_msgs__msg__LateralSignal__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
control_msgs__msg__LateralSignal__Sequence__copy(
  const control_msgs__msg__LateralSignal__Sequence * input,
  control_msgs__msg__LateralSignal__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(control_msgs__msg__LateralSignal);
    control_msgs__msg__LateralSignal * data =
      (control_msgs__msg__LateralSignal *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!control_msgs__msg__LateralSignal__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          control_msgs__msg__LateralSignal__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!control_msgs__msg__LateralSignal__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
