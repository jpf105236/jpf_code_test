// generated from nexidl_typesupport_introspection_cpp/resource/idl__nexidl_typesupport_introspection_cpp.h.em
// with input from control_msgs:msg/LateralSignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__LATERAL_SIGNAL__NEXIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
#define CONTROL_MSGS__MSG__DETAIL__LATERAL_SIGNAL__NEXIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_


#include "nexidl_runtime_c/message_type_support_struct.h"
#include "nexidl_typesupport_interface/macros.h"
#include "nexidl_typesupport_introspection_cpp/visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

// TODO(dirk-thomas) these visibility macros should be message package specific
NEXIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const nexidl_message_type_support_t *
  NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_cpp, control_msgs, msg, LateralSignal)();

#ifdef __cplusplus
}
#endif

#endif  // CONTROL_MSGS__MSG__DETAIL__LATERAL_SIGNAL__NEXIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
