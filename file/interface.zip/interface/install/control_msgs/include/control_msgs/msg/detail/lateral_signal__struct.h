// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from control_msgs:msg/LateralSignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__LATERAL_SIGNAL__STRUCT_H_
#define CONTROL_MSGS__MSG__DETAIL__LATERAL_SIGNAL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/LateralSignal in the package control_msgs.
typedef struct control_msgs__msg__LateralSignal
{
  int32_t tgt_pnn_ang_req_deg;
  bool is_tgt_pnn_ang_fl_eps_pnn_ang;
} control_msgs__msg__LateralSignal;

// Struct for a sequence of control_msgs__msg__LateralSignal.
typedef struct control_msgs__msg__LateralSignal__Sequence
{
  control_msgs__msg__LateralSignal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} control_msgs__msg__LateralSignal__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CONTROL_MSGS__MSG__DETAIL__LATERAL_SIGNAL__STRUCT_H_
