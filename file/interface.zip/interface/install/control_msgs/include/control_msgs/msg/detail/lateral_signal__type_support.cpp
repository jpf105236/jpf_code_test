// generated from nexidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from control_msgs:msg/LateralSignal.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "nexidl_runtime_c/message_type_support_struct.h"
#include "nexidl_typesupport_cpp/message_type_support.hpp"
#include "nexidl_typesupport_interface/macros.h"
#include "control_msgs/msg/detail/lateral_signal__struct.hpp"
#include "nexidl_typesupport_introspection_cpp/field_types.hpp"
#include "nexidl_typesupport_introspection_cpp/identifier.hpp"
#include "nexidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "nexidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "nexidl_typesupport_introspection_cpp/visibility_control.h"

namespace control_msgs
{

namespace msg
{

namespace nexidl_typesupport_introspection_cpp
{

void LateralSignal_init_function(
  void * message_memory, nexidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) control_msgs::msg::LateralSignal(_init);
}

void LateralSignal_fini_function(void * message_memory)
{
  auto typed_message = static_cast<control_msgs::msg::LateralSignal *>(message_memory);
  typed_message->~LateralSignal();
}

static const ::nexidl_typesupport_introspection_cpp::MessageMember LateralSignal_message_member_array[2] = {
  {
    "tgt_pnn_ang_req_deg",  // name
    ::nexidl_typesupport_introspection_cpp::NEX_TYPE_INT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs::msg::LateralSignal, tgt_pnn_ang_req_deg),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "is_tgt_pnn_ang_fl_eps_pnn_ang",  // name
    ::nexidl_typesupport_introspection_cpp::NEX_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs::msg::LateralSignal, is_tgt_pnn_ang_fl_eps_pnn_ang),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::nexidl_typesupport_introspection_cpp::MessageMembers LateralSignal_message_members = {
  "control_msgs::msg",  // message namespace
  "LateralSignal",  // message name
  2,  // number of fields
  sizeof(control_msgs::msg::LateralSignal),
  LateralSignal_message_member_array,  // message members
  LateralSignal_init_function,  // function to initialize message memory (memory has to be allocated)
  LateralSignal_fini_function  // function to terminate message instance (will not free memory)
};

static const nexidl_message_type_support_t LateralSignal_message_type_support_handle = {
  ::nexidl_typesupport_introspection_cpp::typesupport_identifier,
  &LateralSignal_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace nexidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace control_msgs


namespace nexidl_typesupport_introspection_cpp
{

template<>
NEXIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const nexidl_message_type_support_t *
get_message_type_support_handle<control_msgs::msg::LateralSignal>()
{
  return &::control_msgs::msg::nexidl_typesupport_introspection_cpp::LateralSignal_message_type_support_handle;
}

}  // namespace nexidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

NEXIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const nexidl_message_type_support_t *
NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_cpp, control_msgs, msg, LateralSignal)() {
  return &::control_msgs::msg::nexidl_typesupport_introspection_cpp::LateralSignal_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
