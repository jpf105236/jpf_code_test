// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from control_msgs:msg/LongitudinalSignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__BUILDER_HPP_
#define CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__BUILDER_HPP_

#include "control_msgs/msg/detail/longitudinal_signal__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace control_msgs
{

namespace msg
{

namespace builder
{

class Init_LongitudinalSignal_tgt_spd_req_m_s
{
public:
  explicit Init_LongitudinalSignal_tgt_spd_req_m_s(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  ::control_msgs::msg::LongitudinalSignal tgt_spd_req_m_s(::control_msgs::msg::LongitudinalSignal::_tgt_spd_req_m_s_type arg)
  {
    msg_.tgt_spd_req_m_s = std::move(arg);
    return std::move(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_dist_to_stop_req_m
{
public:
  explicit Init_LongitudinalSignal_dist_to_stop_req_m(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_tgt_spd_req_m_s dist_to_stop_req_m(::control_msgs::msg::LongitudinalSignal::_dist_to_stop_req_m_type arg)
  {
    msg_.dist_to_stop_req_m = std::move(arg);
    return Init_LongitudinalSignal_tgt_spd_req_m_s(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_is_stst_req
{
public:
  explicit Init_LongitudinalSignal_is_stst_req(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_dist_to_stop_req_m is_stst_req(::control_msgs::msg::LongitudinalSignal::_is_stst_req_type arg)
  {
    msg_.is_stst_req = std::move(arg);
    return Init_LongitudinalSignal_dist_to_stop_req_m(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_drive_off_tgt_toq_nm
{
public:
  explicit Init_LongitudinalSignal_drive_off_tgt_toq_nm(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_is_stst_req drive_off_tgt_toq_nm(::control_msgs::msg::LongitudinalSignal::_drive_off_tgt_toq_nm_type arg)
  {
    msg_.drive_off_tgt_toq_nm = std::move(arg);
    return Init_LongitudinalSignal_is_stst_req(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_is_drive_off_req
{
public:
  explicit Init_LongitudinalSignal_is_drive_off_req(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_drive_off_tgt_toq_nm is_drive_off_req(::control_msgs::msg::LongitudinalSignal::_is_drive_off_req_type arg)
  {
    msg_.is_drive_off_req = std::move(arg);
    return Init_LongitudinalSignal_drive_off_tgt_toq_nm(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_dccl_req_val_m_s2
{
public:
  explicit Init_LongitudinalSignal_dccl_req_val_m_s2(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_is_drive_off_req dccl_req_val_m_s2(::control_msgs::msg::LongitudinalSignal::_dccl_req_val_m_s2_type arg)
  {
    msg_.dccl_req_val_m_s2 = std::move(arg);
    return Init_LongitudinalSignal_is_drive_off_req(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_dccl_mode_req_enum
{
public:
  explicit Init_LongitudinalSignal_dccl_mode_req_enum(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_dccl_req_val_m_s2 dccl_mode_req_enum(::control_msgs::msg::LongitudinalSignal::_dccl_mode_req_enum_type arg)
  {
    msg_.dccl_mode_req_enum = std::move(arg);
    return Init_LongitudinalSignal_dccl_req_val_m_s2(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_brk_req_val_m_s2
{
public:
  explicit Init_LongitudinalSignal_brk_req_val_m_s2(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_dccl_mode_req_enum brk_req_val_m_s2(::control_msgs::msg::LongitudinalSignal::_brk_req_val_m_s2_type arg)
  {
    msg_.brk_req_val_m_s2 = std::move(arg);
    return Init_LongitudinalSignal_dccl_mode_req_enum(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_brk_mode_req_enum
{
public:
  explicit Init_LongitudinalSignal_brk_mode_req_enum(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_brk_req_val_m_s2 brk_mode_req_enum(::control_msgs::msg::LongitudinalSignal::_brk_mode_req_enum_type arg)
  {
    msg_.brk_mode_req_enum = std::move(arg);
    return Init_LongitudinalSignal_brk_req_val_m_s2(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_hyd_brk_req_enum
{
public:
  explicit Init_LongitudinalSignal_hyd_brk_req_enum(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_brk_mode_req_enum hyd_brk_req_enum(::control_msgs::msg::LongitudinalSignal::_hyd_brk_req_enum_type arg)
  {
    msg_.hyd_brk_req_enum = std::move(arg);
    return Init_LongitudinalSignal_brk_mode_req_enum(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_target_gear_req_enum
{
public:
  explicit Init_LongitudinalSignal_target_gear_req_enum(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_hyd_brk_req_enum target_gear_req_enum(::control_msgs::msg::LongitudinalSignal::_target_gear_req_enum_type arg)
  {
    msg_.target_gear_req_enum = std::move(arg);
    return Init_LongitudinalSignal_hyd_brk_req_enum(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_is_gear_shift_req_enabled
{
public:
  explicit Init_LongitudinalSignal_is_gear_shift_req_enabled(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_target_gear_req_enum is_gear_shift_req_enabled(::control_msgs::msg::LongitudinalSignal::_is_gear_shift_req_enabled_type arg)
  {
    msg_.is_gear_shift_req_enabled = std::move(arg);
    return Init_LongitudinalSignal_target_gear_req_enum(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_vcu_act_toq_req_nm
{
public:
  explicit Init_LongitudinalSignal_vcu_act_toq_req_nm(::control_msgs::msg::LongitudinalSignal & msg)
  : msg_(msg)
  {}
  Init_LongitudinalSignal_is_gear_shift_req_enabled vcu_act_toq_req_nm(::control_msgs::msg::LongitudinalSignal::_vcu_act_toq_req_nm_type arg)
  {
    msg_.vcu_act_toq_req_nm = std::move(arg);
    return Init_LongitudinalSignal_is_gear_shift_req_enabled(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

class Init_LongitudinalSignal_is_vcu_toq_req_enabled
{
public:
  Init_LongitudinalSignal_is_vcu_toq_req_enabled()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LongitudinalSignal_vcu_act_toq_req_nm is_vcu_toq_req_enabled(::control_msgs::msg::LongitudinalSignal::_is_vcu_toq_req_enabled_type arg)
  {
    msg_.is_vcu_toq_req_enabled = std::move(arg);
    return Init_LongitudinalSignal_vcu_act_toq_req_nm(msg_);
  }

private:
  ::control_msgs::msg::LongitudinalSignal msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::control_msgs::msg::LongitudinalSignal>()
{
  return control_msgs::msg::builder::Init_LongitudinalSignal_is_vcu_toq_req_enabled();
}

}  // namespace control_msgs

#endif  // CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__BUILDER_HPP_
