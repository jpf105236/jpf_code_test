// generated from nexidl_generator_c/resource/idl__functions.c.em
// with input from control_msgs:msg/LongitudinalSignal.idl
// generated code does not contain a copyright notice
#include "control_msgs/msg/detail/longitudinal_signal__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
control_msgs__msg__LongitudinalSignal__init(control_msgs__msg__LongitudinalSignal * msg)
{
  if (!msg) {
    return false;
  }
  // is_vcu_toq_req_enabled
  // vcu_act_toq_req_nm
  // is_gear_shift_req_enabled
  // target_gear_req_enum
  // hyd_brk_req_enum
  // brk_mode_req_enum
  // brk_req_val_m_s2
  // dccl_mode_req_enum
  // dccl_req_val_m_s2
  // is_drive_off_req
  // drive_off_tgt_toq_nm
  // is_stst_req
  // dist_to_stop_req_m
  // tgt_spd_req_m_s
  return true;
}

void
control_msgs__msg__LongitudinalSignal__fini(control_msgs__msg__LongitudinalSignal * msg)
{
  if (!msg) {
    return;
  }
  // is_vcu_toq_req_enabled
  // vcu_act_toq_req_nm
  // is_gear_shift_req_enabled
  // target_gear_req_enum
  // hyd_brk_req_enum
  // brk_mode_req_enum
  // brk_req_val_m_s2
  // dccl_mode_req_enum
  // dccl_req_val_m_s2
  // is_drive_off_req
  // drive_off_tgt_toq_nm
  // is_stst_req
  // dist_to_stop_req_m
  // tgt_spd_req_m_s
}

bool
control_msgs__msg__LongitudinalSignal__are_equal(const control_msgs__msg__LongitudinalSignal * lhs, const control_msgs__msg__LongitudinalSignal * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // is_vcu_toq_req_enabled
  if (lhs->is_vcu_toq_req_enabled != rhs->is_vcu_toq_req_enabled) {
    return false;
  }
  // vcu_act_toq_req_nm
  if (lhs->vcu_act_toq_req_nm != rhs->vcu_act_toq_req_nm) {
    return false;
  }
  // is_gear_shift_req_enabled
  if (lhs->is_gear_shift_req_enabled != rhs->is_gear_shift_req_enabled) {
    return false;
  }
  // target_gear_req_enum
  if (lhs->target_gear_req_enum != rhs->target_gear_req_enum) {
    return false;
  }
  // hyd_brk_req_enum
  if (lhs->hyd_brk_req_enum != rhs->hyd_brk_req_enum) {
    return false;
  }
  // brk_mode_req_enum
  if (lhs->brk_mode_req_enum != rhs->brk_mode_req_enum) {
    return false;
  }
  // brk_req_val_m_s2
  if (lhs->brk_req_val_m_s2 != rhs->brk_req_val_m_s2) {
    return false;
  }
  // dccl_mode_req_enum
  if (lhs->dccl_mode_req_enum != rhs->dccl_mode_req_enum) {
    return false;
  }
  // dccl_req_val_m_s2
  if (lhs->dccl_req_val_m_s2 != rhs->dccl_req_val_m_s2) {
    return false;
  }
  // is_drive_off_req
  if (lhs->is_drive_off_req != rhs->is_drive_off_req) {
    return false;
  }
  // drive_off_tgt_toq_nm
  if (lhs->drive_off_tgt_toq_nm != rhs->drive_off_tgt_toq_nm) {
    return false;
  }
  // is_stst_req
  if (lhs->is_stst_req != rhs->is_stst_req) {
    return false;
  }
  // dist_to_stop_req_m
  if (lhs->dist_to_stop_req_m != rhs->dist_to_stop_req_m) {
    return false;
  }
  // tgt_spd_req_m_s
  if (lhs->tgt_spd_req_m_s != rhs->tgt_spd_req_m_s) {
    return false;
  }
  return true;
}

bool
control_msgs__msg__LongitudinalSignal__copy(
  const control_msgs__msg__LongitudinalSignal * input,
  control_msgs__msg__LongitudinalSignal * output)
{
  if (!input || !output) {
    return false;
  }
  // is_vcu_toq_req_enabled
  output->is_vcu_toq_req_enabled = input->is_vcu_toq_req_enabled;
  // vcu_act_toq_req_nm
  output->vcu_act_toq_req_nm = input->vcu_act_toq_req_nm;
  // is_gear_shift_req_enabled
  output->is_gear_shift_req_enabled = input->is_gear_shift_req_enabled;
  // target_gear_req_enum
  output->target_gear_req_enum = input->target_gear_req_enum;
  // hyd_brk_req_enum
  output->hyd_brk_req_enum = input->hyd_brk_req_enum;
  // brk_mode_req_enum
  output->brk_mode_req_enum = input->brk_mode_req_enum;
  // brk_req_val_m_s2
  output->brk_req_val_m_s2 = input->brk_req_val_m_s2;
  // dccl_mode_req_enum
  output->dccl_mode_req_enum = input->dccl_mode_req_enum;
  // dccl_req_val_m_s2
  output->dccl_req_val_m_s2 = input->dccl_req_val_m_s2;
  // is_drive_off_req
  output->is_drive_off_req = input->is_drive_off_req;
  // drive_off_tgt_toq_nm
  output->drive_off_tgt_toq_nm = input->drive_off_tgt_toq_nm;
  // is_stst_req
  output->is_stst_req = input->is_stst_req;
  // dist_to_stop_req_m
  output->dist_to_stop_req_m = input->dist_to_stop_req_m;
  // tgt_spd_req_m_s
  output->tgt_spd_req_m_s = input->tgt_spd_req_m_s;
  return true;
}

control_msgs__msg__LongitudinalSignal *
control_msgs__msg__LongitudinalSignal__create()
{
  control_msgs__msg__LongitudinalSignal * msg = (control_msgs__msg__LongitudinalSignal *)malloc(sizeof(control_msgs__msg__LongitudinalSignal));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(control_msgs__msg__LongitudinalSignal));
  bool success = control_msgs__msg__LongitudinalSignal__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
control_msgs__msg__LongitudinalSignal__destroy(control_msgs__msg__LongitudinalSignal * msg)
{
  if (msg) {
    control_msgs__msg__LongitudinalSignal__fini(msg);
  }
  free(msg);
}


bool
control_msgs__msg__LongitudinalSignal__Sequence__init(control_msgs__msg__LongitudinalSignal__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  control_msgs__msg__LongitudinalSignal * data = NULL;
  if (size) {
    data = (control_msgs__msg__LongitudinalSignal *)calloc(size, sizeof(control_msgs__msg__LongitudinalSignal));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = control_msgs__msg__LongitudinalSignal__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        control_msgs__msg__LongitudinalSignal__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
control_msgs__msg__LongitudinalSignal__Sequence__fini(control_msgs__msg__LongitudinalSignal__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      control_msgs__msg__LongitudinalSignal__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

control_msgs__msg__LongitudinalSignal__Sequence *
control_msgs__msg__LongitudinalSignal__Sequence__create(size_t size)
{
  control_msgs__msg__LongitudinalSignal__Sequence * array = (control_msgs__msg__LongitudinalSignal__Sequence *)malloc(sizeof(control_msgs__msg__LongitudinalSignal__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = control_msgs__msg__LongitudinalSignal__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
control_msgs__msg__LongitudinalSignal__Sequence__destroy(control_msgs__msg__LongitudinalSignal__Sequence * array)
{
  if (array) {
    control_msgs__msg__LongitudinalSignal__Sequence__fini(array);
  }
  free(array);
}

bool
control_msgs__msg__LongitudinalSignal__Sequence__are_equal(const control_msgs__msg__LongitudinalSignal__Sequence * lhs, const control_msgs__msg__LongitudinalSignal__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!control_msgs__msg__LongitudinalSignal__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
control_msgs__msg__LongitudinalSignal__Sequence__copy(
  const control_msgs__msg__LongitudinalSignal__Sequence * input,
  control_msgs__msg__LongitudinalSignal__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(control_msgs__msg__LongitudinalSignal);
    control_msgs__msg__LongitudinalSignal * data =
      (control_msgs__msg__LongitudinalSignal *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!control_msgs__msg__LongitudinalSignal__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          control_msgs__msg__LongitudinalSignal__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!control_msgs__msg__LongitudinalSignal__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
