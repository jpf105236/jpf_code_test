// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from control_msgs:msg/LongitudinalSignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__STRUCT_H_
#define CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/LongitudinalSignal in the package control_msgs.
typedef struct control_msgs__msg__LongitudinalSignal
{
  bool is_vcu_toq_req_enabled;
  float vcu_act_toq_req_nm;
  bool is_gear_shift_req_enabled;
  uint16_t target_gear_req_enum;
  uint16_t hyd_brk_req_enum;
  uint8_t brk_mode_req_enum;
  float brk_req_val_m_s2;
  uint16_t dccl_mode_req_enum;
  float dccl_req_val_m_s2;
  bool is_drive_off_req;
  uint16_t drive_off_tgt_toq_nm;
  bool is_stst_req;
  float dist_to_stop_req_m;
  float tgt_spd_req_m_s;
} control_msgs__msg__LongitudinalSignal;

// Struct for a sequence of control_msgs__msg__LongitudinalSignal.
typedef struct control_msgs__msg__LongitudinalSignal__Sequence
{
  control_msgs__msg__LongitudinalSignal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} control_msgs__msg__LongitudinalSignal__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__STRUCT_H_
