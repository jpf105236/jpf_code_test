// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from control_msgs:msg/LongitudinalSignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__STRUCT_HPP_
#define CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__control_msgs__msg__LongitudinalSignal __attribute__((deprecated))
#else
# define DEPRECATED__control_msgs__msg__LongitudinalSignal __declspec(deprecated)
#endif

namespace control_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LongitudinalSignal_
{
  using Type = LongitudinalSignal_<ContainerAllocator>;

  explicit LongitudinalSignal_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->is_vcu_toq_req_enabled = false;
      this->vcu_act_toq_req_nm = 0.0f;
      this->is_gear_shift_req_enabled = false;
      this->target_gear_req_enum = 0;
      this->hyd_brk_req_enum = 0;
      this->brk_mode_req_enum = 0;
      this->brk_req_val_m_s2 = 0.0f;
      this->dccl_mode_req_enum = 0;
      this->dccl_req_val_m_s2 = 0.0f;
      this->is_drive_off_req = false;
      this->drive_off_tgt_toq_nm = 0;
      this->is_stst_req = false;
      this->dist_to_stop_req_m = 0.0f;
      this->tgt_spd_req_m_s = 0.0f;
    }
  }

  explicit LongitudinalSignal_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->is_vcu_toq_req_enabled = false;
      this->vcu_act_toq_req_nm = 0.0f;
      this->is_gear_shift_req_enabled = false;
      this->target_gear_req_enum = 0;
      this->hyd_brk_req_enum = 0;
      this->brk_mode_req_enum = 0;
      this->brk_req_val_m_s2 = 0.0f;
      this->dccl_mode_req_enum = 0;
      this->dccl_req_val_m_s2 = 0.0f;
      this->is_drive_off_req = false;
      this->drive_off_tgt_toq_nm = 0;
      this->is_stst_req = false;
      this->dist_to_stop_req_m = 0.0f;
      this->tgt_spd_req_m_s = 0.0f;
    }
  }

  // field types and members
  using _is_vcu_toq_req_enabled_type =
    bool;
  _is_vcu_toq_req_enabled_type is_vcu_toq_req_enabled;
  using _vcu_act_toq_req_nm_type =
    float;
  _vcu_act_toq_req_nm_type vcu_act_toq_req_nm;
  using _is_gear_shift_req_enabled_type =
    bool;
  _is_gear_shift_req_enabled_type is_gear_shift_req_enabled;
  using _target_gear_req_enum_type =
    uint16_t;
  _target_gear_req_enum_type target_gear_req_enum;
  using _hyd_brk_req_enum_type =
    uint16_t;
  _hyd_brk_req_enum_type hyd_brk_req_enum;
  using _brk_mode_req_enum_type =
    uint8_t;
  _brk_mode_req_enum_type brk_mode_req_enum;
  using _brk_req_val_m_s2_type =
    float;
  _brk_req_val_m_s2_type brk_req_val_m_s2;
  using _dccl_mode_req_enum_type =
    uint16_t;
  _dccl_mode_req_enum_type dccl_mode_req_enum;
  using _dccl_req_val_m_s2_type =
    float;
  _dccl_req_val_m_s2_type dccl_req_val_m_s2;
  using _is_drive_off_req_type =
    bool;
  _is_drive_off_req_type is_drive_off_req;
  using _drive_off_tgt_toq_nm_type =
    uint16_t;
  _drive_off_tgt_toq_nm_type drive_off_tgt_toq_nm;
  using _is_stst_req_type =
    bool;
  _is_stst_req_type is_stst_req;
  using _dist_to_stop_req_m_type =
    float;
  _dist_to_stop_req_m_type dist_to_stop_req_m;
  using _tgt_spd_req_m_s_type =
    float;
  _tgt_spd_req_m_s_type tgt_spd_req_m_s;

  // setters for named parameter idiom
  Type & set__is_vcu_toq_req_enabled(
    const bool & _arg)
  {
    this->is_vcu_toq_req_enabled = _arg;
    return *this;
  }
  Type & set__vcu_act_toq_req_nm(
    const float & _arg)
  {
    this->vcu_act_toq_req_nm = _arg;
    return *this;
  }
  Type & set__is_gear_shift_req_enabled(
    const bool & _arg)
  {
    this->is_gear_shift_req_enabled = _arg;
    return *this;
  }
  Type & set__target_gear_req_enum(
    const uint16_t & _arg)
  {
    this->target_gear_req_enum = _arg;
    return *this;
  }
  Type & set__hyd_brk_req_enum(
    const uint16_t & _arg)
  {
    this->hyd_brk_req_enum = _arg;
    return *this;
  }
  Type & set__brk_mode_req_enum(
    const uint8_t & _arg)
  {
    this->brk_mode_req_enum = _arg;
    return *this;
  }
  Type & set__brk_req_val_m_s2(
    const float & _arg)
  {
    this->brk_req_val_m_s2 = _arg;
    return *this;
  }
  Type & set__dccl_mode_req_enum(
    const uint16_t & _arg)
  {
    this->dccl_mode_req_enum = _arg;
    return *this;
  }
  Type & set__dccl_req_val_m_s2(
    const float & _arg)
  {
    this->dccl_req_val_m_s2 = _arg;
    return *this;
  }
  Type & set__is_drive_off_req(
    const bool & _arg)
  {
    this->is_drive_off_req = _arg;
    return *this;
  }
  Type & set__drive_off_tgt_toq_nm(
    const uint16_t & _arg)
  {
    this->drive_off_tgt_toq_nm = _arg;
    return *this;
  }
  Type & set__is_stst_req(
    const bool & _arg)
  {
    this->is_stst_req = _arg;
    return *this;
  }
  Type & set__dist_to_stop_req_m(
    const float & _arg)
  {
    this->dist_to_stop_req_m = _arg;
    return *this;
  }
  Type & set__tgt_spd_req_m_s(
    const float & _arg)
  {
    this->tgt_spd_req_m_s = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    control_msgs::msg::LongitudinalSignal_<ContainerAllocator> *;
  using ConstRawPtr =
    const control_msgs::msg::LongitudinalSignal_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<control_msgs::msg::LongitudinalSignal_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<control_msgs::msg::LongitudinalSignal_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      control_msgs::msg::LongitudinalSignal_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<control_msgs::msg::LongitudinalSignal_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      control_msgs::msg::LongitudinalSignal_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<control_msgs::msg::LongitudinalSignal_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<control_msgs::msg::LongitudinalSignal_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<control_msgs::msg::LongitudinalSignal_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__control_msgs__msg__LongitudinalSignal
    std::shared_ptr<control_msgs::msg::LongitudinalSignal_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__control_msgs__msg__LongitudinalSignal
    std::shared_ptr<control_msgs::msg::LongitudinalSignal_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LongitudinalSignal_ & other) const
  {
    if (this->is_vcu_toq_req_enabled != other.is_vcu_toq_req_enabled) {
      return false;
    }
    if (this->vcu_act_toq_req_nm != other.vcu_act_toq_req_nm) {
      return false;
    }
    if (this->is_gear_shift_req_enabled != other.is_gear_shift_req_enabled) {
      return false;
    }
    if (this->target_gear_req_enum != other.target_gear_req_enum) {
      return false;
    }
    if (this->hyd_brk_req_enum != other.hyd_brk_req_enum) {
      return false;
    }
    if (this->brk_mode_req_enum != other.brk_mode_req_enum) {
      return false;
    }
    if (this->brk_req_val_m_s2 != other.brk_req_val_m_s2) {
      return false;
    }
    if (this->dccl_mode_req_enum != other.dccl_mode_req_enum) {
      return false;
    }
    if (this->dccl_req_val_m_s2 != other.dccl_req_val_m_s2) {
      return false;
    }
    if (this->is_drive_off_req != other.is_drive_off_req) {
      return false;
    }
    if (this->drive_off_tgt_toq_nm != other.drive_off_tgt_toq_nm) {
      return false;
    }
    if (this->is_stst_req != other.is_stst_req) {
      return false;
    }
    if (this->dist_to_stop_req_m != other.dist_to_stop_req_m) {
      return false;
    }
    if (this->tgt_spd_req_m_s != other.tgt_spd_req_m_s) {
      return false;
    }
    return true;
  }
  bool operator!=(const LongitudinalSignal_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LongitudinalSignal_

// alias to use template instance with default allocator
using LongitudinalSignal =
  control_msgs::msg::LongitudinalSignal_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace control_msgs

#endif  // CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__STRUCT_HPP_
