// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from control_msgs:msg/LongitudinalSignal.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__TRAITS_HPP_
#define CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__TRAITS_HPP_

#include "control_msgs/msg/detail/longitudinal_signal__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace nexidl_generator_traits
{

inline void to_yaml(
  const control_msgs::msg::LongitudinalSignal & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: is_vcu_toq_req_enabled
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_vcu_toq_req_enabled: ";
    value_to_yaml(msg.is_vcu_toq_req_enabled, out);
    out << "\n";
  }

  // member: vcu_act_toq_req_nm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vcu_act_toq_req_nm: ";
    value_to_yaml(msg.vcu_act_toq_req_nm, out);
    out << "\n";
  }

  // member: is_gear_shift_req_enabled
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_gear_shift_req_enabled: ";
    value_to_yaml(msg.is_gear_shift_req_enabled, out);
    out << "\n";
  }

  // member: target_gear_req_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_gear_req_enum: ";
    value_to_yaml(msg.target_gear_req_enum, out);
    out << "\n";
  }

  // member: hyd_brk_req_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "hyd_brk_req_enum: ";
    value_to_yaml(msg.hyd_brk_req_enum, out);
    out << "\n";
  }

  // member: brk_mode_req_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "brk_mode_req_enum: ";
    value_to_yaml(msg.brk_mode_req_enum, out);
    out << "\n";
  }

  // member: brk_req_val_m_s2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "brk_req_val_m_s2: ";
    value_to_yaml(msg.brk_req_val_m_s2, out);
    out << "\n";
  }

  // member: dccl_mode_req_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dccl_mode_req_enum: ";
    value_to_yaml(msg.dccl_mode_req_enum, out);
    out << "\n";
  }

  // member: dccl_req_val_m_s2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dccl_req_val_m_s2: ";
    value_to_yaml(msg.dccl_req_val_m_s2, out);
    out << "\n";
  }

  // member: is_drive_off_req
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_drive_off_req: ";
    value_to_yaml(msg.is_drive_off_req, out);
    out << "\n";
  }

  // member: drive_off_tgt_toq_nm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "drive_off_tgt_toq_nm: ";
    value_to_yaml(msg.drive_off_tgt_toq_nm, out);
    out << "\n";
  }

  // member: is_stst_req
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_stst_req: ";
    value_to_yaml(msg.is_stst_req, out);
    out << "\n";
  }

  // member: dist_to_stop_req_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dist_to_stop_req_m: ";
    value_to_yaml(msg.dist_to_stop_req_m, out);
    out << "\n";
  }

  // member: tgt_spd_req_m_s
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "tgt_spd_req_m_s: ";
    value_to_yaml(msg.tgt_spd_req_m_s, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const control_msgs::msg::LongitudinalSignal & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<control_msgs::msg::LongitudinalSignal>()
{
  return "control_msgs::msg::LongitudinalSignal";
}

template<>
inline const char * name<control_msgs::msg::LongitudinalSignal>()
{
  return "control_msgs/msg/LongitudinalSignal";
}

template<>
struct has_fixed_size<control_msgs::msg::LongitudinalSignal>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<control_msgs::msg::LongitudinalSignal>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<control_msgs::msg::LongitudinalSignal>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // CONTROL_MSGS__MSG__DETAIL__LONGITUDINAL_SIGNAL__TRAITS_HPP_
