// generated from nexidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from control_msgs:msg/LongitudinalSignal.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "control_msgs/msg/detail/longitudinal_signal__nexidl_typesupport_introspection_c.h"
#include "control_msgs/msg/nexidl_typesupport_introspection_c__visibility_control.h"
#include "nexidl_typesupport_introspection_c/field_types.h"
#include "nexidl_typesupport_introspection_c/identifier.h"
#include "nexidl_typesupport_introspection_c/message_introspection.h"
#include "control_msgs/msg/detail/longitudinal_signal__functions.h"
#include "control_msgs/msg/detail/longitudinal_signal__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_init_function(
  void * message_memory, enum nexidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/nex/nex/issues/397
  (void) _init;
  control_msgs__msg__LongitudinalSignal__init(message_memory);
}

void LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_fini_function(void * message_memory)
{
  control_msgs__msg__LongitudinalSignal__fini(message_memory);
}

static nexidl_typesupport_introspection_c__MessageMember LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_message_member_array[14] = {
  {
    "is_vcu_toq_req_enabled",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, is_vcu_toq_req_enabled),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "vcu_act_toq_req_nm",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, vcu_act_toq_req_nm),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "is_gear_shift_req_enabled",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, is_gear_shift_req_enabled),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "target_gear_req_enum",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, target_gear_req_enum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "hyd_brk_req_enum",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, hyd_brk_req_enum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "brk_mode_req_enum",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, brk_mode_req_enum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "brk_req_val_m_s2",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, brk_req_val_m_s2),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "dccl_mode_req_enum",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, dccl_mode_req_enum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "dccl_req_val_m_s2",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, dccl_req_val_m_s2),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "is_drive_off_req",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, is_drive_off_req),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "drive_off_tgt_toq_nm",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, drive_off_tgt_toq_nm),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "is_stst_req",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, is_stst_req),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "dist_to_stop_req_m",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, dist_to_stop_req_m),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "tgt_spd_req_m_s",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(control_msgs__msg__LongitudinalSignal, tgt_spd_req_m_s),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const nexidl_typesupport_introspection_c__MessageMembers LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_message_members = {
  "control_msgs__msg",  // message namespace
  "LongitudinalSignal",  // message name
  14,  // number of fields
  sizeof(control_msgs__msg__LongitudinalSignal),
  LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_message_member_array,  // message members
  LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_init_function,  // function to initialize message memory (memory has to be allocated)
  LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static nexidl_message_type_support_t LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_message_type_support_handle = {
  0,
  &LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_message_members,
  get_message_typesupport_handle_function,
};

NEXIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_control_msgs
const nexidl_message_type_support_t *
NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, control_msgs, msg, LongitudinalSignal)() {
  if (!LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_message_type_support_handle.typesupport_identifier) {
    LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_message_type_support_handle.typesupport_identifier =
      nexidl_typesupport_introspection_c__identifier;
  }
  return &LongitudinalSignal__nexidl_typesupport_introspection_c__LongitudinalSignal_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
