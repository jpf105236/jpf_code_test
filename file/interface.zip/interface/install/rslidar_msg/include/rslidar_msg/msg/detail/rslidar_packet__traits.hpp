// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from rslidar_msg:msg/RslidarPacket.idl
// generated code does not contain a copyright notice

#ifndef RSLIDAR_MSG__MSG__DETAIL__RSLIDAR_PACKET__TRAITS_HPP_
#define RSLIDAR_MSG__MSG__DETAIL__RSLIDAR_PACKET__TRAITS_HPP_

#include "rslidar_msg/msg/detail/rslidar_packet__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace nexidl_generator_traits
{

inline void to_yaml(
  const rslidar_msg::msg::RslidarPacket & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_yaml(msg.header, out, indentation + 2);
  }

  // member: is_difop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_difop: ";
    value_to_yaml(msg.is_difop, out);
    out << "\n";
  }

  // member: is_frame_begin
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_frame_begin: ";
    value_to_yaml(msg.is_frame_begin, out);
    out << "\n";
  }

  // member: data
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.data.size() == 0) {
      out << "data: []\n";
    } else {
      out << "data:\n";
      for (auto item : msg.data) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const rslidar_msg::msg::RslidarPacket & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<rslidar_msg::msg::RslidarPacket>()
{
  return "rslidar_msg::msg::RslidarPacket";
}

template<>
inline const char * name<rslidar_msg::msg::RslidarPacket>()
{
  return "rslidar_msg/msg/RslidarPacket";
}

template<>
struct has_fixed_size<rslidar_msg::msg::RslidarPacket>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<rslidar_msg::msg::RslidarPacket>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<rslidar_msg::msg::RslidarPacket>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // RSLIDAR_MSG__MSG__DETAIL__RSLIDAR_PACKET__TRAITS_HPP_
