// generated from nexidl_generator_c/resource/idl.h.em
// with input from rslidar_msg:msg/RslidarPacket.idl
// generated code does not contain a copyright notice

#ifndef RSLIDAR_MSG__MSG__RSLIDAR_PACKET_H_
#define RSLIDAR_MSG__MSG__RSLIDAR_PACKET_H_

#include "rslidar_msg/msg/detail/rslidar_packet__struct.h"
#include "rslidar_msg/msg/detail/rslidar_packet__functions.h"
#include "rslidar_msg/msg/detail/rslidar_packet__type_support.h"

#endif  // RSLIDAR_MSG__MSG__RSLIDAR_PACKET_H_
