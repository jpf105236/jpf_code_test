// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/AutoDriveInfo.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__AUTO_DRIVE_INFO_H_
#define SR_MSGS__MSG__AUTO_DRIVE_INFO_H_

#include "sr_msgs/msg/detail/auto_drive_info__struct.h"
#include "sr_msgs/msg/detail/auto_drive_info__functions.h"
#include "sr_msgs/msg/detail/auto_drive_info__type_support.h"

#endif  // SR_MSGS__MSG__AUTO_DRIVE_INFO_H_
