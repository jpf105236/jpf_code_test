// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sr_msgs:msg/AutoDriveInfo.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__BUILDER_HPP_
#define SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__BUILDER_HPP_

#include "sr_msgs/msg/detail/auto_drive_info__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sr_msgs
{

namespace msg
{

namespace builder
{

class Init_AutoDriveInfo_road_attributes
{
public:
  explicit Init_AutoDriveInfo_road_attributes(::sr_msgs::msg::AutoDriveInfo & msg)
  : msg_(msg)
  {}
  ::sr_msgs::msg::AutoDriveInfo road_attributes(::sr_msgs::msg::AutoDriveInfo::_road_attributes_type arg)
  {
    msg_.road_attributes = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sr_msgs::msg::AutoDriveInfo msg_;
};

class Init_AutoDriveInfo_road_markers
{
public:
  explicit Init_AutoDriveInfo_road_markers(::sr_msgs::msg::AutoDriveInfo & msg)
  : msg_(msg)
  {}
  Init_AutoDriveInfo_road_attributes road_markers(::sr_msgs::msg::AutoDriveInfo::_road_markers_type arg)
  {
    msg_.road_markers = std::move(arg);
    return Init_AutoDriveInfo_road_attributes(msg_);
  }

private:
  ::sr_msgs::msg::AutoDriveInfo msg_;
};

class Init_AutoDriveInfo_traffic_light
{
public:
  explicit Init_AutoDriveInfo_traffic_light(::sr_msgs::msg::AutoDriveInfo & msg)
  : msg_(msg)
  {}
  Init_AutoDriveInfo_road_markers traffic_light(::sr_msgs::msg::AutoDriveInfo::_traffic_light_type arg)
  {
    msg_.traffic_light = std::move(arg);
    return Init_AutoDriveInfo_road_markers(msg_);
  }

private:
  ::sr_msgs::msg::AutoDriveInfo msg_;
};

class Init_AutoDriveInfo_trajectory
{
public:
  explicit Init_AutoDriveInfo_trajectory(::sr_msgs::msg::AutoDriveInfo & msg)
  : msg_(msg)
  {}
  Init_AutoDriveInfo_traffic_light trajectory(::sr_msgs::msg::AutoDriveInfo::_trajectory_type arg)
  {
    msg_.trajectory = std::move(arg);
    return Init_AutoDriveInfo_traffic_light(msg_);
  }

private:
  ::sr_msgs::msg::AutoDriveInfo msg_;
};

class Init_AutoDriveInfo_localization_info
{
public:
  explicit Init_AutoDriveInfo_localization_info(::sr_msgs::msg::AutoDriveInfo & msg)
  : msg_(msg)
  {}
  Init_AutoDriveInfo_trajectory localization_info(::sr_msgs::msg::AutoDriveInfo::_localization_info_type arg)
  {
    msg_.localization_info = std::move(arg);
    return Init_AutoDriveInfo_trajectory(msg_);
  }

private:
  ::sr_msgs::msg::AutoDriveInfo msg_;
};

class Init_AutoDriveInfo_perception_info
{
public:
  explicit Init_AutoDriveInfo_perception_info(::sr_msgs::msg::AutoDriveInfo & msg)
  : msg_(msg)
  {}
  Init_AutoDriveInfo_localization_info perception_info(::sr_msgs::msg::AutoDriveInfo::_perception_info_type arg)
  {
    msg_.perception_info = std::move(arg);
    return Init_AutoDriveInfo_localization_info(msg_);
  }

private:
  ::sr_msgs::msg::AutoDriveInfo msg_;
};

class Init_AutoDriveInfo_param
{
public:
  explicit Init_AutoDriveInfo_param(::sr_msgs::msg::AutoDriveInfo & msg)
  : msg_(msg)
  {}
  Init_AutoDriveInfo_perception_info param(::sr_msgs::msg::AutoDriveInfo::_param_type arg)
  {
    msg_.param = std::move(arg);
    return Init_AutoDriveInfo_perception_info(msg_);
  }

private:
  ::sr_msgs::msg::AutoDriveInfo msg_;
};

class Init_AutoDriveInfo_status_enum
{
public:
  Init_AutoDriveInfo_status_enum()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AutoDriveInfo_param status_enum(::sr_msgs::msg::AutoDriveInfo::_status_enum_type arg)
  {
    msg_.status_enum = std::move(arg);
    return Init_AutoDriveInfo_param(msg_);
  }

private:
  ::sr_msgs::msg::AutoDriveInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sr_msgs::msg::AutoDriveInfo>()
{
  return sr_msgs::msg::builder::Init_AutoDriveInfo_status_enum();
}

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__BUILDER_HPP_
