// generated from nexidl_generator_c/resource/idl__functions.c.em
// with input from sr_msgs:msg/AutoDriveInfo.idl
// generated code does not contain a copyright notice
#include "sr_msgs/msg/detail/auto_drive_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `status_enum`
#include "sr_msgs/msg/detail/auto_drive_status__functions.h"
// Member `perception_info`
#include "sr_msgs/msg/detail/perception_info__functions.h"
// Member `localization_info`
#include "sr_msgs/msg/detail/location_info__functions.h"
// Member `trajectory`
#include "sr_msgs/msg/detail/vehicle_trajectory__functions.h"
// Member `traffic_light`
#include "sr_msgs/msg/detail/traffic_light__functions.h"
// Member `road_markers`
#include "sr_msgs/msg/detail/road_markers__functions.h"
// Member `road_attributes`
#include "sr_msgs/msg/detail/road_attribute__functions.h"

bool
sr_msgs__msg__AutoDriveInfo__init(sr_msgs__msg__AutoDriveInfo * msg)
{
  if (!msg) {
    return false;
  }
  // status_enum
  if (!sr_msgs__msg__AutoDriveStatus__init(&msg->status_enum)) {
    sr_msgs__msg__AutoDriveInfo__fini(msg);
    return false;
  }
  // param
  // perception_info
  if (!sr_msgs__msg__PerceptionInfo__init(&msg->perception_info)) {
    sr_msgs__msg__AutoDriveInfo__fini(msg);
    return false;
  }
  // localization_info
  if (!sr_msgs__msg__LocationInfo__init(&msg->localization_info)) {
    sr_msgs__msg__AutoDriveInfo__fini(msg);
    return false;
  }
  // trajectory
  if (!sr_msgs__msg__VehicleTrajectory__init(&msg->trajectory)) {
    sr_msgs__msg__AutoDriveInfo__fini(msg);
    return false;
  }
  // traffic_light
  if (!sr_msgs__msg__TrafficLight__init(&msg->traffic_light)) {
    sr_msgs__msg__AutoDriveInfo__fini(msg);
    return false;
  }
  // road_markers
  if (!sr_msgs__msg__RoadMarkers__init(&msg->road_markers)) {
    sr_msgs__msg__AutoDriveInfo__fini(msg);
    return false;
  }
  // road_attributes
  if (!sr_msgs__msg__RoadAttribute__init(&msg->road_attributes)) {
    sr_msgs__msg__AutoDriveInfo__fini(msg);
    return false;
  }
  return true;
}

void
sr_msgs__msg__AutoDriveInfo__fini(sr_msgs__msg__AutoDriveInfo * msg)
{
  if (!msg) {
    return;
  }
  // status_enum
  sr_msgs__msg__AutoDriveStatus__fini(&msg->status_enum);
  // param
  // perception_info
  sr_msgs__msg__PerceptionInfo__fini(&msg->perception_info);
  // localization_info
  sr_msgs__msg__LocationInfo__fini(&msg->localization_info);
  // trajectory
  sr_msgs__msg__VehicleTrajectory__fini(&msg->trajectory);
  // traffic_light
  sr_msgs__msg__TrafficLight__fini(&msg->traffic_light);
  // road_markers
  sr_msgs__msg__RoadMarkers__fini(&msg->road_markers);
  // road_attributes
  sr_msgs__msg__RoadAttribute__fini(&msg->road_attributes);
}

bool
sr_msgs__msg__AutoDriveInfo__are_equal(const sr_msgs__msg__AutoDriveInfo * lhs, const sr_msgs__msg__AutoDriveInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // status_enum
  if (!sr_msgs__msg__AutoDriveStatus__are_equal(
      &(lhs->status_enum), &(rhs->status_enum)))
  {
    return false;
  }
  // param
  if (lhs->param != rhs->param) {
    return false;
  }
  // perception_info
  if (!sr_msgs__msg__PerceptionInfo__are_equal(
      &(lhs->perception_info), &(rhs->perception_info)))
  {
    return false;
  }
  // localization_info
  if (!sr_msgs__msg__LocationInfo__are_equal(
      &(lhs->localization_info), &(rhs->localization_info)))
  {
    return false;
  }
  // trajectory
  if (!sr_msgs__msg__VehicleTrajectory__are_equal(
      &(lhs->trajectory), &(rhs->trajectory)))
  {
    return false;
  }
  // traffic_light
  if (!sr_msgs__msg__TrafficLight__are_equal(
      &(lhs->traffic_light), &(rhs->traffic_light)))
  {
    return false;
  }
  // road_markers
  if (!sr_msgs__msg__RoadMarkers__are_equal(
      &(lhs->road_markers), &(rhs->road_markers)))
  {
    return false;
  }
  // road_attributes
  if (!sr_msgs__msg__RoadAttribute__are_equal(
      &(lhs->road_attributes), &(rhs->road_attributes)))
  {
    return false;
  }
  return true;
}

bool
sr_msgs__msg__AutoDriveInfo__copy(
  const sr_msgs__msg__AutoDriveInfo * input,
  sr_msgs__msg__AutoDriveInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // status_enum
  if (!sr_msgs__msg__AutoDriveStatus__copy(
      &(input->status_enum), &(output->status_enum)))
  {
    return false;
  }
  // param
  output->param = input->param;
  // perception_info
  if (!sr_msgs__msg__PerceptionInfo__copy(
      &(input->perception_info), &(output->perception_info)))
  {
    return false;
  }
  // localization_info
  if (!sr_msgs__msg__LocationInfo__copy(
      &(input->localization_info), &(output->localization_info)))
  {
    return false;
  }
  // trajectory
  if (!sr_msgs__msg__VehicleTrajectory__copy(
      &(input->trajectory), &(output->trajectory)))
  {
    return false;
  }
  // traffic_light
  if (!sr_msgs__msg__TrafficLight__copy(
      &(input->traffic_light), &(output->traffic_light)))
  {
    return false;
  }
  // road_markers
  if (!sr_msgs__msg__RoadMarkers__copy(
      &(input->road_markers), &(output->road_markers)))
  {
    return false;
  }
  // road_attributes
  if (!sr_msgs__msg__RoadAttribute__copy(
      &(input->road_attributes), &(output->road_attributes)))
  {
    return false;
  }
  return true;
}

sr_msgs__msg__AutoDriveInfo *
sr_msgs__msg__AutoDriveInfo__create()
{
  sr_msgs__msg__AutoDriveInfo * msg = (sr_msgs__msg__AutoDriveInfo *)malloc(sizeof(sr_msgs__msg__AutoDriveInfo));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sr_msgs__msg__AutoDriveInfo));
  bool success = sr_msgs__msg__AutoDriveInfo__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
sr_msgs__msg__AutoDriveInfo__destroy(sr_msgs__msg__AutoDriveInfo * msg)
{
  if (msg) {
    sr_msgs__msg__AutoDriveInfo__fini(msg);
  }
  free(msg);
}


bool
sr_msgs__msg__AutoDriveInfo__Sequence__init(sr_msgs__msg__AutoDriveInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  sr_msgs__msg__AutoDriveInfo * data = NULL;
  if (size) {
    data = (sr_msgs__msg__AutoDriveInfo *)calloc(size, sizeof(sr_msgs__msg__AutoDriveInfo));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sr_msgs__msg__AutoDriveInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sr_msgs__msg__AutoDriveInfo__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sr_msgs__msg__AutoDriveInfo__Sequence__fini(sr_msgs__msg__AutoDriveInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sr_msgs__msg__AutoDriveInfo__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sr_msgs__msg__AutoDriveInfo__Sequence *
sr_msgs__msg__AutoDriveInfo__Sequence__create(size_t size)
{
  sr_msgs__msg__AutoDriveInfo__Sequence * array = (sr_msgs__msg__AutoDriveInfo__Sequence *)malloc(sizeof(sr_msgs__msg__AutoDriveInfo__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = sr_msgs__msg__AutoDriveInfo__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
sr_msgs__msg__AutoDriveInfo__Sequence__destroy(sr_msgs__msg__AutoDriveInfo__Sequence * array)
{
  if (array) {
    sr_msgs__msg__AutoDriveInfo__Sequence__fini(array);
  }
  free(array);
}

bool
sr_msgs__msg__AutoDriveInfo__Sequence__are_equal(const sr_msgs__msg__AutoDriveInfo__Sequence * lhs, const sr_msgs__msg__AutoDriveInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sr_msgs__msg__AutoDriveInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__AutoDriveInfo__Sequence__copy(
  const sr_msgs__msg__AutoDriveInfo__Sequence * input,
  sr_msgs__msg__AutoDriveInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sr_msgs__msg__AutoDriveInfo);
    sr_msgs__msg__AutoDriveInfo * data =
      (sr_msgs__msg__AutoDriveInfo *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sr_msgs__msg__AutoDriveInfo__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sr_msgs__msg__AutoDriveInfo__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sr_msgs__msg__AutoDriveInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
