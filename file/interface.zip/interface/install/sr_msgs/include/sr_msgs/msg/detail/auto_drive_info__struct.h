// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/AutoDriveInfo.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'status_enum'
#include "sr_msgs/msg/detail/auto_drive_status__struct.h"
// Member 'perception_info'
#include "sr_msgs/msg/detail/perception_info__struct.h"
// Member 'localization_info'
#include "sr_msgs/msg/detail/location_info__struct.h"
// Member 'trajectory'
#include "sr_msgs/msg/detail/vehicle_trajectory__struct.h"
// Member 'traffic_light'
#include "sr_msgs/msg/detail/traffic_light__struct.h"
// Member 'road_markers'
#include "sr_msgs/msg/detail/road_markers__struct.h"
// Member 'road_attributes'
#include "sr_msgs/msg/detail/road_attribute__struct.h"

// Struct defined in msg/AutoDriveInfo in the package sr_msgs.
typedef struct sr_msgs__msg__AutoDriveInfo
{
  sr_msgs__msg__AutoDriveStatus status_enum;
  int16_t param;
  sr_msgs__msg__PerceptionInfo perception_info;
  sr_msgs__msg__LocationInfo localization_info;
  sr_msgs__msg__VehicleTrajectory trajectory;
  sr_msgs__msg__TrafficLight traffic_light;
  sr_msgs__msg__RoadMarkers road_markers;
  sr_msgs__msg__RoadAttribute road_attributes;
} sr_msgs__msg__AutoDriveInfo;

// Struct for a sequence of sr_msgs__msg__AutoDriveInfo.
typedef struct sr_msgs__msg__AutoDriveInfo__Sequence
{
  sr_msgs__msg__AutoDriveInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__AutoDriveInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__STRUCT_H_
