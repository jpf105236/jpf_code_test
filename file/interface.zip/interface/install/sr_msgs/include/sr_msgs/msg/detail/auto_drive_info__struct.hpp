// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/AutoDriveInfo.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'status_enum'
#include "sr_msgs/msg/detail/auto_drive_status__struct.hpp"
// Member 'perception_info'
#include "sr_msgs/msg/detail/perception_info__struct.hpp"
// Member 'localization_info'
#include "sr_msgs/msg/detail/location_info__struct.hpp"
// Member 'trajectory'
#include "sr_msgs/msg/detail/vehicle_trajectory__struct.hpp"
// Member 'traffic_light'
#include "sr_msgs/msg/detail/traffic_light__struct.hpp"
// Member 'road_markers'
#include "sr_msgs/msg/detail/road_markers__struct.hpp"
// Member 'road_attributes'
#include "sr_msgs/msg/detail/road_attribute__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__AutoDriveInfo __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__AutoDriveInfo __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct AutoDriveInfo_
{
  using Type = AutoDriveInfo_<ContainerAllocator>;

  explicit AutoDriveInfo_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : status_enum(_init),
    perception_info(_init),
    localization_info(_init),
    trajectory(_init),
    traffic_light(_init),
    road_markers(_init),
    road_attributes(_init)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->param = 0;
    }
  }

  explicit AutoDriveInfo_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : status_enum(_alloc, _init),
    perception_info(_alloc, _init),
    localization_info(_alloc, _init),
    trajectory(_alloc, _init),
    traffic_light(_alloc, _init),
    road_markers(_alloc, _init),
    road_attributes(_alloc, _init)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->param = 0;
    }
  }

  // field types and members
  using _status_enum_type =
    sr_msgs::msg::AutoDriveStatus_<ContainerAllocator>;
  _status_enum_type status_enum;
  using _param_type =
    int16_t;
  _param_type param;
  using _perception_info_type =
    sr_msgs::msg::PerceptionInfo_<ContainerAllocator>;
  _perception_info_type perception_info;
  using _localization_info_type =
    sr_msgs::msg::LocationInfo_<ContainerAllocator>;
  _localization_info_type localization_info;
  using _trajectory_type =
    sr_msgs::msg::VehicleTrajectory_<ContainerAllocator>;
  _trajectory_type trajectory;
  using _traffic_light_type =
    sr_msgs::msg::TrafficLight_<ContainerAllocator>;
  _traffic_light_type traffic_light;
  using _road_markers_type =
    sr_msgs::msg::RoadMarkers_<ContainerAllocator>;
  _road_markers_type road_markers;
  using _road_attributes_type =
    sr_msgs::msg::RoadAttribute_<ContainerAllocator>;
  _road_attributes_type road_attributes;

  // setters for named parameter idiom
  Type & set__status_enum(
    const sr_msgs::msg::AutoDriveStatus_<ContainerAllocator> & _arg)
  {
    this->status_enum = _arg;
    return *this;
  }
  Type & set__param(
    const int16_t & _arg)
  {
    this->param = _arg;
    return *this;
  }
  Type & set__perception_info(
    const sr_msgs::msg::PerceptionInfo_<ContainerAllocator> & _arg)
  {
    this->perception_info = _arg;
    return *this;
  }
  Type & set__localization_info(
    const sr_msgs::msg::LocationInfo_<ContainerAllocator> & _arg)
  {
    this->localization_info = _arg;
    return *this;
  }
  Type & set__trajectory(
    const sr_msgs::msg::VehicleTrajectory_<ContainerAllocator> & _arg)
  {
    this->trajectory = _arg;
    return *this;
  }
  Type & set__traffic_light(
    const sr_msgs::msg::TrafficLight_<ContainerAllocator> & _arg)
  {
    this->traffic_light = _arg;
    return *this;
  }
  Type & set__road_markers(
    const sr_msgs::msg::RoadMarkers_<ContainerAllocator> & _arg)
  {
    this->road_markers = _arg;
    return *this;
  }
  Type & set__road_attributes(
    const sr_msgs::msg::RoadAttribute_<ContainerAllocator> & _arg)
  {
    this->road_attributes = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sr_msgs::msg::AutoDriveInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::AutoDriveInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::AutoDriveInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::AutoDriveInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::AutoDriveInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::AutoDriveInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::AutoDriveInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::AutoDriveInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::AutoDriveInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::AutoDriveInfo_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__AutoDriveInfo
    std::shared_ptr<sr_msgs::msg::AutoDriveInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__AutoDriveInfo
    std::shared_ptr<sr_msgs::msg::AutoDriveInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AutoDriveInfo_ & other) const
  {
    if (this->status_enum != other.status_enum) {
      return false;
    }
    if (this->param != other.param) {
      return false;
    }
    if (this->perception_info != other.perception_info) {
      return false;
    }
    if (this->localization_info != other.localization_info) {
      return false;
    }
    if (this->trajectory != other.trajectory) {
      return false;
    }
    if (this->traffic_light != other.traffic_light) {
      return false;
    }
    if (this->road_markers != other.road_markers) {
      return false;
    }
    if (this->road_attributes != other.road_attributes) {
      return false;
    }
    return true;
  }
  bool operator!=(const AutoDriveInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AutoDriveInfo_

// alias to use template instance with default allocator
using AutoDriveInfo =
  sr_msgs::msg::AutoDriveInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__STRUCT_HPP_
