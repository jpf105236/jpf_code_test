// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sr_msgs:msg/AutoDriveInfo.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__TRAITS_HPP_
#define SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__TRAITS_HPP_

#include "sr_msgs/msg/detail/auto_drive_info__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'status_enum'
#include "sr_msgs/msg/detail/auto_drive_status__traits.hpp"
// Member 'perception_info'
#include "sr_msgs/msg/detail/perception_info__traits.hpp"
// Member 'localization_info'
#include "sr_msgs/msg/detail/location_info__traits.hpp"
// Member 'trajectory'
#include "sr_msgs/msg/detail/vehicle_trajectory__traits.hpp"
// Member 'traffic_light'
#include "sr_msgs/msg/detail/traffic_light__traits.hpp"
// Member 'road_markers'
#include "sr_msgs/msg/detail/road_markers__traits.hpp"
// Member 'road_attributes'
#include "sr_msgs/msg/detail/road_attribute__traits.hpp"

namespace nexidl_generator_traits
{

inline void to_yaml(
  const sr_msgs::msg::AutoDriveInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: status_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status_enum:\n";
    to_yaml(msg.status_enum, out, indentation + 2);
  }

  // member: param
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "param: ";
    value_to_yaml(msg.param, out);
    out << "\n";
  }

  // member: perception_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "perception_info:\n";
    to_yaml(msg.perception_info, out, indentation + 2);
  }

  // member: localization_info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "localization_info:\n";
    to_yaml(msg.localization_info, out, indentation + 2);
  }

  // member: trajectory
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "trajectory:\n";
    to_yaml(msg.trajectory, out, indentation + 2);
  }

  // member: traffic_light
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "traffic_light:\n";
    to_yaml(msg.traffic_light, out, indentation + 2);
  }

  // member: road_markers
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "road_markers:\n";
    to_yaml(msg.road_markers, out, indentation + 2);
  }

  // member: road_attributes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "road_attributes:\n";
    to_yaml(msg.road_attributes, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const sr_msgs::msg::AutoDriveInfo & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<sr_msgs::msg::AutoDriveInfo>()
{
  return "sr_msgs::msg::AutoDriveInfo";
}

template<>
inline const char * name<sr_msgs::msg::AutoDriveInfo>()
{
  return "sr_msgs/msg/AutoDriveInfo";
}

template<>
struct has_fixed_size<sr_msgs::msg::AutoDriveInfo>
  : std::integral_constant<bool, has_fixed_size<sr_msgs::msg::AutoDriveStatus>::value && has_fixed_size<sr_msgs::msg::LocationInfo>::value && has_fixed_size<sr_msgs::msg::PerceptionInfo>::value && has_fixed_size<sr_msgs::msg::RoadAttribute>::value && has_fixed_size<sr_msgs::msg::RoadMarkers>::value && has_fixed_size<sr_msgs::msg::TrafficLight>::value && has_fixed_size<sr_msgs::msg::VehicleTrajectory>::value> {};

template<>
struct has_bounded_size<sr_msgs::msg::AutoDriveInfo>
  : std::integral_constant<bool, has_bounded_size<sr_msgs::msg::AutoDriveStatus>::value && has_bounded_size<sr_msgs::msg::LocationInfo>::value && has_bounded_size<sr_msgs::msg::PerceptionInfo>::value && has_bounded_size<sr_msgs::msg::RoadAttribute>::value && has_bounded_size<sr_msgs::msg::RoadMarkers>::value && has_bounded_size<sr_msgs::msg::TrafficLight>::value && has_bounded_size<sr_msgs::msg::VehicleTrajectory>::value> {};

template<>
struct is_message<sr_msgs::msg::AutoDriveInfo>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // SR_MSGS__MSG__DETAIL__AUTO_DRIVE_INFO__TRAITS_HPP_
