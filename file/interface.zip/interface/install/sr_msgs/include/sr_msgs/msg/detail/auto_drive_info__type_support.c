// generated from nexidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from sr_msgs:msg/AutoDriveInfo.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "sr_msgs/msg/detail/auto_drive_info__nexidl_typesupport_introspection_c.h"
#include "sr_msgs/msg/nexidl_typesupport_introspection_c__visibility_control.h"
#include "nexidl_typesupport_introspection_c/field_types.h"
#include "nexidl_typesupport_introspection_c/identifier.h"
#include "nexidl_typesupport_introspection_c/message_introspection.h"
#include "sr_msgs/msg/detail/auto_drive_info__functions.h"
#include "sr_msgs/msg/detail/auto_drive_info__struct.h"


// Include directives for member types
// Member `status_enum`
#include "sr_msgs/msg/auto_drive_status.h"
// Member `status_enum`
#include "sr_msgs/msg/detail/auto_drive_status__nexidl_typesupport_introspection_c.h"
// Member `perception_info`
#include "sr_msgs/msg/perception_info.h"
// Member `perception_info`
#include "sr_msgs/msg/detail/perception_info__nexidl_typesupport_introspection_c.h"
// Member `localization_info`
#include "sr_msgs/msg/location_info.h"
// Member `localization_info`
#include "sr_msgs/msg/detail/location_info__nexidl_typesupport_introspection_c.h"
// Member `trajectory`
#include "sr_msgs/msg/vehicle_trajectory.h"
// Member `trajectory`
#include "sr_msgs/msg/detail/vehicle_trajectory__nexidl_typesupport_introspection_c.h"
// Member `traffic_light`
#include "sr_msgs/msg/traffic_light.h"
// Member `traffic_light`
#include "sr_msgs/msg/detail/traffic_light__nexidl_typesupport_introspection_c.h"
// Member `road_markers`
#include "sr_msgs/msg/road_markers.h"
// Member `road_markers`
#include "sr_msgs/msg/detail/road_markers__nexidl_typesupport_introspection_c.h"
// Member `road_attributes`
#include "sr_msgs/msg/road_attribute.h"
// Member `road_attributes`
#include "sr_msgs/msg/detail/road_attribute__nexidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_init_function(
  void * message_memory, enum nexidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/nex/nex/issues/397
  (void) _init;
  sr_msgs__msg__AutoDriveInfo__init(message_memory);
}

void AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_fini_function(void * message_memory)
{
  sr_msgs__msg__AutoDriveInfo__fini(message_memory);
}

static nexidl_typesupport_introspection_c__MessageMember AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_member_array[8] = {
  {
    "status_enum",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__AutoDriveInfo, status_enum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "param",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__AutoDriveInfo, param),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "perception_info",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__AutoDriveInfo, perception_info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "localization_info",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__AutoDriveInfo, localization_info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "trajectory",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__AutoDriveInfo, trajectory),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "traffic_light",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__AutoDriveInfo, traffic_light),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "road_markers",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__AutoDriveInfo, road_markers),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "road_attributes",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__AutoDriveInfo, road_attributes),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const nexidl_typesupport_introspection_c__MessageMembers AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_members = {
  "sr_msgs__msg",  // message namespace
  "AutoDriveInfo",  // message name
  8,  // number of fields
  sizeof(sr_msgs__msg__AutoDriveInfo),
  AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_member_array,  // message members
  AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_init_function,  // function to initialize message memory (memory has to be allocated)
  AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static nexidl_message_type_support_t AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_type_support_handle = {
  0,
  &AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_members,
  get_message_typesupport_handle_function,
};

NEXIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_sr_msgs
const nexidl_message_type_support_t *
NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, AutoDriveInfo)() {
  AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_member_array[0].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, AutoDriveStatus)();
  AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_member_array[2].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, PerceptionInfo)();
  AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_member_array[3].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, LocationInfo)();
  AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_member_array[4].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, VehicleTrajectory)();
  AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_member_array[5].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, TrafficLight)();
  AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_member_array[6].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, RoadMarkers)();
  AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_member_array[7].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, RoadAttribute)();
  if (!AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_type_support_handle.typesupport_identifier) {
    AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_type_support_handle.typesupport_identifier =
      nexidl_typesupport_introspection_c__identifier;
  }
  return &AutoDriveInfo__nexidl_typesupport_introspection_c__AutoDriveInfo_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
