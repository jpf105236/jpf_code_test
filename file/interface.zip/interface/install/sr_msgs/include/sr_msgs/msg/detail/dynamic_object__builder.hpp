// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sr_msgs:msg/DynamicObject.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__BUILDER_HPP_
#define SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__BUILDER_HPP_

#include "sr_msgs/msg/detail/dynamic_object__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sr_msgs
{

namespace msg
{

namespace builder
{

class Init_DynamicObject_obstacle_rel_dir_z_rad
{
public:
  explicit Init_DynamicObject_obstacle_rel_dir_z_rad(::sr_msgs::msg::DynamicObject & msg)
  : msg_(msg)
  {}
  ::sr_msgs::msg::DynamicObject obstacle_rel_dir_z_rad(::sr_msgs::msg::DynamicObject::_obstacle_rel_dir_z_rad_type arg)
  {
    msg_.obstacle_rel_dir_z_rad = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sr_msgs::msg::DynamicObject msg_;
};

class Init_DynamicObject_obstacle_rel_dir_y_rad
{
public:
  explicit Init_DynamicObject_obstacle_rel_dir_y_rad(::sr_msgs::msg::DynamicObject & msg)
  : msg_(msg)
  {}
  Init_DynamicObject_obstacle_rel_dir_z_rad obstacle_rel_dir_y_rad(::sr_msgs::msg::DynamicObject::_obstacle_rel_dir_y_rad_type arg)
  {
    msg_.obstacle_rel_dir_y_rad = std::move(arg);
    return Init_DynamicObject_obstacle_rel_dir_z_rad(msg_);
  }

private:
  ::sr_msgs::msg::DynamicObject msg_;
};

class Init_DynamicObject_obstacle_rel_dir_x_rad
{
public:
  explicit Init_DynamicObject_obstacle_rel_dir_x_rad(::sr_msgs::msg::DynamicObject & msg)
  : msg_(msg)
  {}
  Init_DynamicObject_obstacle_rel_dir_y_rad obstacle_rel_dir_x_rad(::sr_msgs::msg::DynamicObject::_obstacle_rel_dir_x_rad_type arg)
  {
    msg_.obstacle_rel_dir_x_rad = std::move(arg);
    return Init_DynamicObject_obstacle_rel_dir_y_rad(msg_);
  }

private:
  ::sr_msgs::msg::DynamicObject msg_;
};

class Init_DynamicObject_obstacle_z_height_m
{
public:
  explicit Init_DynamicObject_obstacle_z_height_m(::sr_msgs::msg::DynamicObject & msg)
  : msg_(msg)
  {}
  Init_DynamicObject_obstacle_rel_dir_x_rad obstacle_z_height_m(::sr_msgs::msg::DynamicObject::_obstacle_z_height_m_type arg)
  {
    msg_.obstacle_z_height_m = std::move(arg);
    return Init_DynamicObject_obstacle_rel_dir_x_rad(msg_);
  }

private:
  ::sr_msgs::msg::DynamicObject msg_;
};

class Init_DynamicObject_obstacle_y_width_m
{
public:
  explicit Init_DynamicObject_obstacle_y_width_m(::sr_msgs::msg::DynamicObject & msg)
  : msg_(msg)
  {}
  Init_DynamicObject_obstacle_z_height_m obstacle_y_width_m(::sr_msgs::msg::DynamicObject::_obstacle_y_width_m_type arg)
  {
    msg_.obstacle_y_width_m = std::move(arg);
    return Init_DynamicObject_obstacle_z_height_m(msg_);
  }

private:
  ::sr_msgs::msg::DynamicObject msg_;
};

class Init_DynamicObject_obstacle_x_length_m
{
public:
  explicit Init_DynamicObject_obstacle_x_length_m(::sr_msgs::msg::DynamicObject & msg)
  : msg_(msg)
  {}
  Init_DynamicObject_obstacle_y_width_m obstacle_x_length_m(::sr_msgs::msg::DynamicObject::_obstacle_x_length_m_type arg)
  {
    msg_.obstacle_x_length_m = std::move(arg);
    return Init_DynamicObject_obstacle_y_width_m(msg_);
  }

private:
  ::sr_msgs::msg::DynamicObject msg_;
};

class Init_DynamicObject_pose
{
public:
  explicit Init_DynamicObject_pose(::sr_msgs::msg::DynamicObject & msg)
  : msg_(msg)
  {}
  Init_DynamicObject_obstacle_x_length_m pose(::sr_msgs::msg::DynamicObject::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return Init_DynamicObject_obstacle_x_length_m(msg_);
  }

private:
  ::sr_msgs::msg::DynamicObject msg_;
};

class Init_DynamicObject_type_enum
{
public:
  Init_DynamicObject_type_enum()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DynamicObject_pose type_enum(::sr_msgs::msg::DynamicObject::_type_enum_type arg)
  {
    msg_.type_enum = std::move(arg);
    return Init_DynamicObject_pose(msg_);
  }

private:
  ::sr_msgs::msg::DynamicObject msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sr_msgs::msg::DynamicObject>()
{
  return sr_msgs::msg::builder::Init_DynamicObject_type_enum();
}

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__BUILDER_HPP_
