// generated from nexidl_generator_c/resource/idl__functions.c.em
// with input from sr_msgs:msg/DynamicObject.idl
// generated code does not contain a copyright notice
#include "sr_msgs/msg/detail/dynamic_object__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `type_enum`
#include "sr_msgs/msg/detail/dynamic_object_type__functions.h"
// Member `pose`
#include "sr_msgs/msg/detail/object_pose__functions.h"

bool
sr_msgs__msg__DynamicObject__init(sr_msgs__msg__DynamicObject * msg)
{
  if (!msg) {
    return false;
  }
  // type_enum
  if (!sr_msgs__msg__DynamicObjectType__init(&msg->type_enum)) {
    sr_msgs__msg__DynamicObject__fini(msg);
    return false;
  }
  // pose
  if (!sr_msgs__msg__ObjectPose__init(&msg->pose)) {
    sr_msgs__msg__DynamicObject__fini(msg);
    return false;
  }
  // obstacle_x_length_m
  // obstacle_y_width_m
  // obstacle_z_height_m
  // obstacle_rel_dir_x_rad
  // obstacle_rel_dir_y_rad
  // obstacle_rel_dir_z_rad
  return true;
}

void
sr_msgs__msg__DynamicObject__fini(sr_msgs__msg__DynamicObject * msg)
{
  if (!msg) {
    return;
  }
  // type_enum
  sr_msgs__msg__DynamicObjectType__fini(&msg->type_enum);
  // pose
  sr_msgs__msg__ObjectPose__fini(&msg->pose);
  // obstacle_x_length_m
  // obstacle_y_width_m
  // obstacle_z_height_m
  // obstacle_rel_dir_x_rad
  // obstacle_rel_dir_y_rad
  // obstacle_rel_dir_z_rad
}

bool
sr_msgs__msg__DynamicObject__are_equal(const sr_msgs__msg__DynamicObject * lhs, const sr_msgs__msg__DynamicObject * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // type_enum
  if (!sr_msgs__msg__DynamicObjectType__are_equal(
      &(lhs->type_enum), &(rhs->type_enum)))
  {
    return false;
  }
  // pose
  if (!sr_msgs__msg__ObjectPose__are_equal(
      &(lhs->pose), &(rhs->pose)))
  {
    return false;
  }
  // obstacle_x_length_m
  if (lhs->obstacle_x_length_m != rhs->obstacle_x_length_m) {
    return false;
  }
  // obstacle_y_width_m
  if (lhs->obstacle_y_width_m != rhs->obstacle_y_width_m) {
    return false;
  }
  // obstacle_z_height_m
  if (lhs->obstacle_z_height_m != rhs->obstacle_z_height_m) {
    return false;
  }
  // obstacle_rel_dir_x_rad
  if (lhs->obstacle_rel_dir_x_rad != rhs->obstacle_rel_dir_x_rad) {
    return false;
  }
  // obstacle_rel_dir_y_rad
  if (lhs->obstacle_rel_dir_y_rad != rhs->obstacle_rel_dir_y_rad) {
    return false;
  }
  // obstacle_rel_dir_z_rad
  if (lhs->obstacle_rel_dir_z_rad != rhs->obstacle_rel_dir_z_rad) {
    return false;
  }
  return true;
}

bool
sr_msgs__msg__DynamicObject__copy(
  const sr_msgs__msg__DynamicObject * input,
  sr_msgs__msg__DynamicObject * output)
{
  if (!input || !output) {
    return false;
  }
  // type_enum
  if (!sr_msgs__msg__DynamicObjectType__copy(
      &(input->type_enum), &(output->type_enum)))
  {
    return false;
  }
  // pose
  if (!sr_msgs__msg__ObjectPose__copy(
      &(input->pose), &(output->pose)))
  {
    return false;
  }
  // obstacle_x_length_m
  output->obstacle_x_length_m = input->obstacle_x_length_m;
  // obstacle_y_width_m
  output->obstacle_y_width_m = input->obstacle_y_width_m;
  // obstacle_z_height_m
  output->obstacle_z_height_m = input->obstacle_z_height_m;
  // obstacle_rel_dir_x_rad
  output->obstacle_rel_dir_x_rad = input->obstacle_rel_dir_x_rad;
  // obstacle_rel_dir_y_rad
  output->obstacle_rel_dir_y_rad = input->obstacle_rel_dir_y_rad;
  // obstacle_rel_dir_z_rad
  output->obstacle_rel_dir_z_rad = input->obstacle_rel_dir_z_rad;
  return true;
}

sr_msgs__msg__DynamicObject *
sr_msgs__msg__DynamicObject__create()
{
  sr_msgs__msg__DynamicObject * msg = (sr_msgs__msg__DynamicObject *)malloc(sizeof(sr_msgs__msg__DynamicObject));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sr_msgs__msg__DynamicObject));
  bool success = sr_msgs__msg__DynamicObject__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
sr_msgs__msg__DynamicObject__destroy(sr_msgs__msg__DynamicObject * msg)
{
  if (msg) {
    sr_msgs__msg__DynamicObject__fini(msg);
  }
  free(msg);
}


bool
sr_msgs__msg__DynamicObject__Sequence__init(sr_msgs__msg__DynamicObject__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  sr_msgs__msg__DynamicObject * data = NULL;
  if (size) {
    data = (sr_msgs__msg__DynamicObject *)calloc(size, sizeof(sr_msgs__msg__DynamicObject));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sr_msgs__msg__DynamicObject__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sr_msgs__msg__DynamicObject__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sr_msgs__msg__DynamicObject__Sequence__fini(sr_msgs__msg__DynamicObject__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sr_msgs__msg__DynamicObject__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sr_msgs__msg__DynamicObject__Sequence *
sr_msgs__msg__DynamicObject__Sequence__create(size_t size)
{
  sr_msgs__msg__DynamicObject__Sequence * array = (sr_msgs__msg__DynamicObject__Sequence *)malloc(sizeof(sr_msgs__msg__DynamicObject__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = sr_msgs__msg__DynamicObject__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
sr_msgs__msg__DynamicObject__Sequence__destroy(sr_msgs__msg__DynamicObject__Sequence * array)
{
  if (array) {
    sr_msgs__msg__DynamicObject__Sequence__fini(array);
  }
  free(array);
}

bool
sr_msgs__msg__DynamicObject__Sequence__are_equal(const sr_msgs__msg__DynamicObject__Sequence * lhs, const sr_msgs__msg__DynamicObject__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sr_msgs__msg__DynamicObject__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__DynamicObject__Sequence__copy(
  const sr_msgs__msg__DynamicObject__Sequence * input,
  sr_msgs__msg__DynamicObject__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sr_msgs__msg__DynamicObject);
    sr_msgs__msg__DynamicObject * data =
      (sr_msgs__msg__DynamicObject *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sr_msgs__msg__DynamicObject__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sr_msgs__msg__DynamicObject__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sr_msgs__msg__DynamicObject__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
