// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/DynamicObject.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'type_enum'
#include "sr_msgs/msg/detail/dynamic_object_type__struct.h"
// Member 'pose'
#include "sr_msgs/msg/detail/object_pose__struct.h"

// Struct defined in msg/DynamicObject in the package sr_msgs.
typedef struct sr_msgs__msg__DynamicObject
{
  sr_msgs__msg__DynamicObjectType type_enum;
  sr_msgs__msg__ObjectPose pose;
  float obstacle_x_length_m;
  float obstacle_y_width_m;
  float obstacle_z_height_m;
  float obstacle_rel_dir_x_rad;
  float obstacle_rel_dir_y_rad;
  float obstacle_rel_dir_z_rad;
} sr_msgs__msg__DynamicObject;

// Struct for a sequence of sr_msgs__msg__DynamicObject.
typedef struct sr_msgs__msg__DynamicObject__Sequence
{
  sr_msgs__msg__DynamicObject * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__DynamicObject__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__STRUCT_H_
