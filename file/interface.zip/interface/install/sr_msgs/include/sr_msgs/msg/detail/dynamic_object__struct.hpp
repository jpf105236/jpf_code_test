// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/DynamicObject.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'type_enum'
#include "sr_msgs/msg/detail/dynamic_object_type__struct.hpp"
// Member 'pose'
#include "sr_msgs/msg/detail/object_pose__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__DynamicObject __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__DynamicObject __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DynamicObject_
{
  using Type = DynamicObject_<ContainerAllocator>;

  explicit DynamicObject_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : type_enum(_init),
    pose(_init)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->obstacle_x_length_m = 0.0f;
      this->obstacle_y_width_m = 0.0f;
      this->obstacle_z_height_m = 0.0f;
      this->obstacle_rel_dir_x_rad = 0.0f;
      this->obstacle_rel_dir_y_rad = 0.0f;
      this->obstacle_rel_dir_z_rad = 0.0f;
    }
  }

  explicit DynamicObject_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : type_enum(_alloc, _init),
    pose(_alloc, _init)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->obstacle_x_length_m = 0.0f;
      this->obstacle_y_width_m = 0.0f;
      this->obstacle_z_height_m = 0.0f;
      this->obstacle_rel_dir_x_rad = 0.0f;
      this->obstacle_rel_dir_y_rad = 0.0f;
      this->obstacle_rel_dir_z_rad = 0.0f;
    }
  }

  // field types and members
  using _type_enum_type =
    sr_msgs::msg::DynamicObjectType_<ContainerAllocator>;
  _type_enum_type type_enum;
  using _pose_type =
    sr_msgs::msg::ObjectPose_<ContainerAllocator>;
  _pose_type pose;
  using _obstacle_x_length_m_type =
    float;
  _obstacle_x_length_m_type obstacle_x_length_m;
  using _obstacle_y_width_m_type =
    float;
  _obstacle_y_width_m_type obstacle_y_width_m;
  using _obstacle_z_height_m_type =
    float;
  _obstacle_z_height_m_type obstacle_z_height_m;
  using _obstacle_rel_dir_x_rad_type =
    float;
  _obstacle_rel_dir_x_rad_type obstacle_rel_dir_x_rad;
  using _obstacle_rel_dir_y_rad_type =
    float;
  _obstacle_rel_dir_y_rad_type obstacle_rel_dir_y_rad;
  using _obstacle_rel_dir_z_rad_type =
    float;
  _obstacle_rel_dir_z_rad_type obstacle_rel_dir_z_rad;

  // setters for named parameter idiom
  Type & set__type_enum(
    const sr_msgs::msg::DynamicObjectType_<ContainerAllocator> & _arg)
  {
    this->type_enum = _arg;
    return *this;
  }
  Type & set__pose(
    const sr_msgs::msg::ObjectPose_<ContainerAllocator> & _arg)
  {
    this->pose = _arg;
    return *this;
  }
  Type & set__obstacle_x_length_m(
    const float & _arg)
  {
    this->obstacle_x_length_m = _arg;
    return *this;
  }
  Type & set__obstacle_y_width_m(
    const float & _arg)
  {
    this->obstacle_y_width_m = _arg;
    return *this;
  }
  Type & set__obstacle_z_height_m(
    const float & _arg)
  {
    this->obstacle_z_height_m = _arg;
    return *this;
  }
  Type & set__obstacle_rel_dir_x_rad(
    const float & _arg)
  {
    this->obstacle_rel_dir_x_rad = _arg;
    return *this;
  }
  Type & set__obstacle_rel_dir_y_rad(
    const float & _arg)
  {
    this->obstacle_rel_dir_y_rad = _arg;
    return *this;
  }
  Type & set__obstacle_rel_dir_z_rad(
    const float & _arg)
  {
    this->obstacle_rel_dir_z_rad = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sr_msgs::msg::DynamicObject_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::DynamicObject_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::DynamicObject_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::DynamicObject_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::DynamicObject_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::DynamicObject_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::DynamicObject_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::DynamicObject_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::DynamicObject_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::DynamicObject_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__DynamicObject
    std::shared_ptr<sr_msgs::msg::DynamicObject_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__DynamicObject
    std::shared_ptr<sr_msgs::msg::DynamicObject_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DynamicObject_ & other) const
  {
    if (this->type_enum != other.type_enum) {
      return false;
    }
    if (this->pose != other.pose) {
      return false;
    }
    if (this->obstacle_x_length_m != other.obstacle_x_length_m) {
      return false;
    }
    if (this->obstacle_y_width_m != other.obstacle_y_width_m) {
      return false;
    }
    if (this->obstacle_z_height_m != other.obstacle_z_height_m) {
      return false;
    }
    if (this->obstacle_rel_dir_x_rad != other.obstacle_rel_dir_x_rad) {
      return false;
    }
    if (this->obstacle_rel_dir_y_rad != other.obstacle_rel_dir_y_rad) {
      return false;
    }
    if (this->obstacle_rel_dir_z_rad != other.obstacle_rel_dir_z_rad) {
      return false;
    }
    return true;
  }
  bool operator!=(const DynamicObject_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DynamicObject_

// alias to use template instance with default allocator
using DynamicObject =
  sr_msgs::msg::DynamicObject_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__STRUCT_HPP_
