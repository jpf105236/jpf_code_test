// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sr_msgs:msg/DynamicObject.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__TRAITS_HPP_
#define SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__TRAITS_HPP_

#include "sr_msgs/msg/detail/dynamic_object__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'type_enum'
#include "sr_msgs/msg/detail/dynamic_object_type__traits.hpp"
// Member 'pose'
#include "sr_msgs/msg/detail/object_pose__traits.hpp"

namespace nexidl_generator_traits
{

inline void to_yaml(
  const sr_msgs::msg::DynamicObject & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: type_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "type_enum:\n";
    to_yaml(msg.type_enum, out, indentation + 2);
  }

  // member: pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pose:\n";
    to_yaml(msg.pose, out, indentation + 2);
  }

  // member: obstacle_x_length_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_x_length_m: ";
    value_to_yaml(msg.obstacle_x_length_m, out);
    out << "\n";
  }

  // member: obstacle_y_width_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_y_width_m: ";
    value_to_yaml(msg.obstacle_y_width_m, out);
    out << "\n";
  }

  // member: obstacle_z_height_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_z_height_m: ";
    value_to_yaml(msg.obstacle_z_height_m, out);
    out << "\n";
  }

  // member: obstacle_rel_dir_x_rad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_rel_dir_x_rad: ";
    value_to_yaml(msg.obstacle_rel_dir_x_rad, out);
    out << "\n";
  }

  // member: obstacle_rel_dir_y_rad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_rel_dir_y_rad: ";
    value_to_yaml(msg.obstacle_rel_dir_y_rad, out);
    out << "\n";
  }

  // member: obstacle_rel_dir_z_rad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "obstacle_rel_dir_z_rad: ";
    value_to_yaml(msg.obstacle_rel_dir_z_rad, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const sr_msgs::msg::DynamicObject & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<sr_msgs::msg::DynamicObject>()
{
  return "sr_msgs::msg::DynamicObject";
}

template<>
inline const char * name<sr_msgs::msg::DynamicObject>()
{
  return "sr_msgs/msg/DynamicObject";
}

template<>
struct has_fixed_size<sr_msgs::msg::DynamicObject>
  : std::integral_constant<bool, has_fixed_size<sr_msgs::msg::DynamicObjectType>::value && has_fixed_size<sr_msgs::msg::ObjectPose>::value> {};

template<>
struct has_bounded_size<sr_msgs::msg::DynamicObject>
  : std::integral_constant<bool, has_bounded_size<sr_msgs::msg::DynamicObjectType>::value && has_bounded_size<sr_msgs::msg::ObjectPose>::value> {};

template<>
struct is_message<sr_msgs::msg::DynamicObject>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT__TRAITS_HPP_
