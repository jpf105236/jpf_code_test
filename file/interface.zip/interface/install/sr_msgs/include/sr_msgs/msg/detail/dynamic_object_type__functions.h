// generated from nexidl_generator_c/resource/idl__functions.h.em
// with input from sr_msgs:msg/DynamicObjectType.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT_TYPE__FUNCTIONS_H_
#define SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT_TYPE__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "nexidl_runtime_c/visibility_control.h"
#include "sr_msgs/msg/nexidl_generator_c__visibility_control.h"

#include "sr_msgs/msg/detail/dynamic_object_type__struct.h"

/// Initialize msg/DynamicObjectType message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * sr_msgs__msg__DynamicObjectType
 * )) before or use
 * sr_msgs__msg__DynamicObjectType__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
bool
sr_msgs__msg__DynamicObjectType__init(sr_msgs__msg__DynamicObjectType * msg);

/// Finalize msg/DynamicObjectType message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
void
sr_msgs__msg__DynamicObjectType__fini(sr_msgs__msg__DynamicObjectType * msg);

/// Create msg/DynamicObjectType message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * sr_msgs__msg__DynamicObjectType__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
sr_msgs__msg__DynamicObjectType *
sr_msgs__msg__DynamicObjectType__create();

/// Destroy msg/DynamicObjectType message.
/**
 * It calls
 * sr_msgs__msg__DynamicObjectType__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
void
sr_msgs__msg__DynamicObjectType__destroy(sr_msgs__msg__DynamicObjectType * msg);

/// Check for msg/DynamicObjectType message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
bool
sr_msgs__msg__DynamicObjectType__are_equal(const sr_msgs__msg__DynamicObjectType * lhs, const sr_msgs__msg__DynamicObjectType * rhs);

/// Copy a msg/DynamicObjectType message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
bool
sr_msgs__msg__DynamicObjectType__copy(
  const sr_msgs__msg__DynamicObjectType * input,
  sr_msgs__msg__DynamicObjectType * output);

/// Initialize array of msg/DynamicObjectType messages.
/**
 * It allocates the memory for the number of elements and calls
 * sr_msgs__msg__DynamicObjectType__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
bool
sr_msgs__msg__DynamicObjectType__Sequence__init(sr_msgs__msg__DynamicObjectType__Sequence * array, size_t size);

/// Finalize array of msg/DynamicObjectType messages.
/**
 * It calls
 * sr_msgs__msg__DynamicObjectType__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
void
sr_msgs__msg__DynamicObjectType__Sequence__fini(sr_msgs__msg__DynamicObjectType__Sequence * array);

/// Create array of msg/DynamicObjectType messages.
/**
 * It allocates the memory for the array and calls
 * sr_msgs__msg__DynamicObjectType__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
sr_msgs__msg__DynamicObjectType__Sequence *
sr_msgs__msg__DynamicObjectType__Sequence__create(size_t size);

/// Destroy array of msg/DynamicObjectType messages.
/**
 * It calls
 * sr_msgs__msg__DynamicObjectType__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
void
sr_msgs__msg__DynamicObjectType__Sequence__destroy(sr_msgs__msg__DynamicObjectType__Sequence * array);

/// Check for msg/DynamicObjectType message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
bool
sr_msgs__msg__DynamicObjectType__Sequence__are_equal(const sr_msgs__msg__DynamicObjectType__Sequence * lhs, const sr_msgs__msg__DynamicObjectType__Sequence * rhs);

/// Copy an array of msg/DynamicObjectType messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
bool
sr_msgs__msg__DynamicObjectType__Sequence__copy(
  const sr_msgs__msg__DynamicObjectType__Sequence * input,
  sr_msgs__msg__DynamicObjectType__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT_TYPE__FUNCTIONS_H_
