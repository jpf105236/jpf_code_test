// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/DynamicObjectType.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT_TYPE__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT_TYPE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'TYPE_UNKNOWN'.
enum
{
  sr_msgs__msg__DynamicObjectType__TYPE_UNKNOWN = 0
};

/// Constant 'TYPE_PED'.
enum
{
  sr_msgs__msg__DynamicObjectType__TYPE_PED = 1
};

/// Constant 'TYPE_CAR'.
enum
{
  sr_msgs__msg__DynamicObjectType__TYPE_CAR = 2
};

/// Constant 'TYPE_VAN'.
enum
{
  sr_msgs__msg__DynamicObjectType__TYPE_VAN = 3
};

/// Constant 'TYPE_TRUCK'.
enum
{
  sr_msgs__msg__DynamicObjectType__TYPE_TRUCK = 4
};

/// Constant 'TYPE_BUS'.
enum
{
  sr_msgs__msg__DynamicObjectType__TYPE_BUS = 5
};

/// Constant 'TYPE_ABNORMAL_VEHICLE'.
enum
{
  sr_msgs__msg__DynamicObjectType__TYPE_ABNORMAL_VEHICLE = 6
};

/// Constant 'TYPE_MOTORCYCLIST'.
enum
{
  sr_msgs__msg__DynamicObjectType__TYPE_MOTORCYCLIST = 7
};

/// Constant 'TYPE_CYCLIST'.
enum
{
  sr_msgs__msg__DynamicObjectType__TYPE_CYCLIST = 8
};

/// Constant 'TYPE_CONSTRUCTION_VEHICLE'.
enum
{
  sr_msgs__msg__DynamicObjectType__TYPE_CONSTRUCTION_VEHICLE = 9
};

/// Constant 'TYPE_TRAILER'.
enum
{
  sr_msgs__msg__DynamicObjectType__TYPE_TRAILER = 10
};

// Struct defined in msg/DynamicObjectType in the package sr_msgs.
typedef struct sr_msgs__msg__DynamicObjectType
{
  uint8_t value;
} sr_msgs__msg__DynamicObjectType;

// Struct for a sequence of sr_msgs__msg__DynamicObjectType.
typedef struct sr_msgs__msg__DynamicObjectType__Sequence
{
  sr_msgs__msg__DynamicObjectType * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__DynamicObjectType__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__DYNAMIC_OBJECT_TYPE__STRUCT_H_
