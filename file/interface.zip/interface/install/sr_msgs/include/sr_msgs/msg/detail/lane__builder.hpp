// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sr_msgs:msg/Lane.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE__BUILDER_HPP_
#define SR_MSGS__MSG__DETAIL__LANE__BUILDER_HPP_

#include "sr_msgs/msg/detail/lane__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sr_msgs
{

namespace msg
{

namespace builder
{

class Init_Lane_lane_points_world_list
{
public:
  explicit Init_Lane_lane_points_world_list(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  ::sr_msgs::msg::Lane lane_points_world_list(::sr_msgs::msg::Lane::_lane_points_world_list_type arg)
  {
    msg_.lane_points_world_list = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_lane_points_world_size
{
public:
  explicit Init_Lane_lane_points_world_size(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  Init_Lane_lane_points_world_list lane_points_world_size(::sr_msgs::msg::Lane::_lane_points_world_size_type arg)
  {
    msg_.lane_points_world_size = std::move(arg);
    return Init_Lane_lane_points_world_list(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_curvature_derivative_parameter_c3
{
public:
  explicit Init_Lane_curvature_derivative_parameter_c3(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  Init_Lane_lane_points_world_size curvature_derivative_parameter_c3(::sr_msgs::msg::Lane::_curvature_derivative_parameter_c3_type arg)
  {
    msg_.curvature_derivative_parameter_c3 = std::move(arg);
    return Init_Lane_lane_points_world_size(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_curvature_parameter_c2
{
public:
  explicit Init_Lane_curvature_parameter_c2(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  Init_Lane_curvature_derivative_parameter_c3 curvature_parameter_c2(::sr_msgs::msg::Lane::_curvature_parameter_c2_type arg)
  {
    msg_.curvature_parameter_c2 = std::move(arg);
    return Init_Lane_curvature_derivative_parameter_c3(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_heading_angle_parameter_c1
{
public:
  explicit Init_Lane_heading_angle_parameter_c1(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  Init_Lane_curvature_parameter_c2 heading_angle_parameter_c1(::sr_msgs::msg::Lane::_heading_angle_parameter_c1_type arg)
  {
    msg_.heading_angle_parameter_c1 = std::move(arg);
    return Init_Lane_curvature_parameter_c2(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_position_parameter_c0
{
public:
  explicit Init_Lane_position_parameter_c0(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  Init_Lane_heading_angle_parameter_c1 position_parameter_c0(::sr_msgs::msg::Lane::_position_parameter_c0_type arg)
  {
    msg_.position_parameter_c0 = std::move(arg);
    return Init_Lane_heading_angle_parameter_c1(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_lane_id_enum
{
public:
  explicit Init_Lane_lane_id_enum(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  Init_Lane_position_parameter_c0 lane_id_enum(::sr_msgs::msg::Lane::_lane_id_enum_type arg)
  {
    msg_.lane_id_enum = std::move(arg);
    return Init_Lane_position_parameter_c0(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_is_view_range_availability
{
public:
  explicit Init_Lane_is_view_range_availability(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  Init_Lane_lane_id_enum is_view_range_availability(::sr_msgs::msg::Lane::_is_view_range_availability_type arg)
  {
    msg_.is_view_range_availability = std::move(arg);
    return Init_Lane_lane_id_enum(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_view_range_m
{
public:
  explicit Init_Lane_view_range_m(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  Init_Lane_is_view_range_availability view_range_m(::sr_msgs::msg::Lane::_view_range_m_type arg)
  {
    msg_.view_range_m = std::move(arg);
    return Init_Lane_is_view_range_availability(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_marking_width_m
{
public:
  explicit Init_Lane_marking_width_m(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  Init_Lane_view_range_m marking_width_m(::sr_msgs::msg::Lane::_marking_width_m_type arg)
  {
    msg_.marking_width_m = std::move(arg);
    return Init_Lane_view_range_m(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_quality_enum
{
public:
  explicit Init_Lane_quality_enum(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  Init_Lane_marking_width_m quality_enum(::sr_msgs::msg::Lane::_quality_enum_type arg)
  {
    msg_.quality_enum = std::move(arg);
    return Init_Lane_marking_width_m(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_lane_color_enum
{
public:
  explicit Init_Lane_lane_color_enum(::sr_msgs::msg::Lane & msg)
  : msg_(msg)
  {}
  Init_Lane_quality_enum lane_color_enum(::sr_msgs::msg::Lane::_lane_color_enum_type arg)
  {
    msg_.lane_color_enum = std::move(arg);
    return Init_Lane_quality_enum(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

class Init_Lane_lane_type_enum
{
public:
  Init_Lane_lane_type_enum()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Lane_lane_color_enum lane_type_enum(::sr_msgs::msg::Lane::_lane_type_enum_type arg)
  {
    msg_.lane_type_enum = std::move(arg);
    return Init_Lane_lane_color_enum(msg_);
  }

private:
  ::sr_msgs::msg::Lane msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sr_msgs::msg::Lane>()
{
  return sr_msgs::msg::builder::Init_Lane_lane_type_enum();
}

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__LANE__BUILDER_HPP_
