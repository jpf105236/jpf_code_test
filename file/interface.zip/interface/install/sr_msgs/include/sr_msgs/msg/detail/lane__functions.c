// generated from nexidl_generator_c/resource/idl__functions.c.em
// with input from sr_msgs:msg/Lane.idl
// generated code does not contain a copyright notice
#include "sr_msgs/msg/detail/lane__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `lane_type_enum`
#include "sr_msgs/msg/detail/lane_type__functions.h"
// Member `lane_color_enum`
#include "sr_msgs/msg/detail/lane_color__functions.h"
// Member `quality_enum`
#include "sr_msgs/msg/detail/lane_confidence__functions.h"
// Member `lane_id_enum`
#include "sr_msgs/msg/detail/lane_id__functions.h"
// Member `lane_points_world_list`
#include "sr_msgs/msg/detail/world_point_xy__functions.h"

bool
sr_msgs__msg__Lane__init(sr_msgs__msg__Lane * msg)
{
  if (!msg) {
    return false;
  }
  // lane_type_enum
  if (!sr_msgs__msg__LaneType__init(&msg->lane_type_enum)) {
    sr_msgs__msg__Lane__fini(msg);
    return false;
  }
  // lane_color_enum
  if (!sr_msgs__msg__LaneColor__init(&msg->lane_color_enum)) {
    sr_msgs__msg__Lane__fini(msg);
    return false;
  }
  // quality_enum
  if (!sr_msgs__msg__LaneConfidence__init(&msg->quality_enum)) {
    sr_msgs__msg__Lane__fini(msg);
    return false;
  }
  // marking_width_m
  // view_range_m
  // is_view_range_availability
  // lane_id_enum
  if (!sr_msgs__msg__LaneId__init(&msg->lane_id_enum)) {
    sr_msgs__msg__Lane__fini(msg);
    return false;
  }
  // position_parameter_c0
  // heading_angle_parameter_c1
  // curvature_parameter_c2
  // curvature_derivative_parameter_c3
  // lane_points_world_size
  // lane_points_world_list
  for (size_t i = 0; i < 100; ++i) {
    if (!sr_msgs__msg__WorldPointXY__init(&msg->lane_points_world_list[i])) {
      sr_msgs__msg__Lane__fini(msg);
      return false;
    }
  }
  return true;
}

void
sr_msgs__msg__Lane__fini(sr_msgs__msg__Lane * msg)
{
  if (!msg) {
    return;
  }
  // lane_type_enum
  sr_msgs__msg__LaneType__fini(&msg->lane_type_enum);
  // lane_color_enum
  sr_msgs__msg__LaneColor__fini(&msg->lane_color_enum);
  // quality_enum
  sr_msgs__msg__LaneConfidence__fini(&msg->quality_enum);
  // marking_width_m
  // view_range_m
  // is_view_range_availability
  // lane_id_enum
  sr_msgs__msg__LaneId__fini(&msg->lane_id_enum);
  // position_parameter_c0
  // heading_angle_parameter_c1
  // curvature_parameter_c2
  // curvature_derivative_parameter_c3
  // lane_points_world_size
  // lane_points_world_list
  for (size_t i = 0; i < 100; ++i) {
    sr_msgs__msg__WorldPointXY__fini(&msg->lane_points_world_list[i]);
  }
}

bool
sr_msgs__msg__Lane__are_equal(const sr_msgs__msg__Lane * lhs, const sr_msgs__msg__Lane * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // lane_type_enum
  if (!sr_msgs__msg__LaneType__are_equal(
      &(lhs->lane_type_enum), &(rhs->lane_type_enum)))
  {
    return false;
  }
  // lane_color_enum
  if (!sr_msgs__msg__LaneColor__are_equal(
      &(lhs->lane_color_enum), &(rhs->lane_color_enum)))
  {
    return false;
  }
  // quality_enum
  if (!sr_msgs__msg__LaneConfidence__are_equal(
      &(lhs->quality_enum), &(rhs->quality_enum)))
  {
    return false;
  }
  // marking_width_m
  if (lhs->marking_width_m != rhs->marking_width_m) {
    return false;
  }
  // view_range_m
  if (lhs->view_range_m != rhs->view_range_m) {
    return false;
  }
  // is_view_range_availability
  if (lhs->is_view_range_availability != rhs->is_view_range_availability) {
    return false;
  }
  // lane_id_enum
  if (!sr_msgs__msg__LaneId__are_equal(
      &(lhs->lane_id_enum), &(rhs->lane_id_enum)))
  {
    return false;
  }
  // position_parameter_c0
  if (lhs->position_parameter_c0 != rhs->position_parameter_c0) {
    return false;
  }
  // heading_angle_parameter_c1
  if (lhs->heading_angle_parameter_c1 != rhs->heading_angle_parameter_c1) {
    return false;
  }
  // curvature_parameter_c2
  if (lhs->curvature_parameter_c2 != rhs->curvature_parameter_c2) {
    return false;
  }
  // curvature_derivative_parameter_c3
  if (lhs->curvature_derivative_parameter_c3 != rhs->curvature_derivative_parameter_c3) {
    return false;
  }
  // lane_points_world_size
  if (lhs->lane_points_world_size != rhs->lane_points_world_size) {
    return false;
  }
  // lane_points_world_list
  for (size_t i = 0; i < 100; ++i) {
    if (!sr_msgs__msg__WorldPointXY__are_equal(
        &(lhs->lane_points_world_list[i]), &(rhs->lane_points_world_list[i])))
    {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__Lane__copy(
  const sr_msgs__msg__Lane * input,
  sr_msgs__msg__Lane * output)
{
  if (!input || !output) {
    return false;
  }
  // lane_type_enum
  if (!sr_msgs__msg__LaneType__copy(
      &(input->lane_type_enum), &(output->lane_type_enum)))
  {
    return false;
  }
  // lane_color_enum
  if (!sr_msgs__msg__LaneColor__copy(
      &(input->lane_color_enum), &(output->lane_color_enum)))
  {
    return false;
  }
  // quality_enum
  if (!sr_msgs__msg__LaneConfidence__copy(
      &(input->quality_enum), &(output->quality_enum)))
  {
    return false;
  }
  // marking_width_m
  output->marking_width_m = input->marking_width_m;
  // view_range_m
  output->view_range_m = input->view_range_m;
  // is_view_range_availability
  output->is_view_range_availability = input->is_view_range_availability;
  // lane_id_enum
  if (!sr_msgs__msg__LaneId__copy(
      &(input->lane_id_enum), &(output->lane_id_enum)))
  {
    return false;
  }
  // position_parameter_c0
  output->position_parameter_c0 = input->position_parameter_c0;
  // heading_angle_parameter_c1
  output->heading_angle_parameter_c1 = input->heading_angle_parameter_c1;
  // curvature_parameter_c2
  output->curvature_parameter_c2 = input->curvature_parameter_c2;
  // curvature_derivative_parameter_c3
  output->curvature_derivative_parameter_c3 = input->curvature_derivative_parameter_c3;
  // lane_points_world_size
  output->lane_points_world_size = input->lane_points_world_size;
  // lane_points_world_list
  for (size_t i = 0; i < 100; ++i) {
    if (!sr_msgs__msg__WorldPointXY__copy(
        &(input->lane_points_world_list[i]), &(output->lane_points_world_list[i])))
    {
      return false;
    }
  }
  return true;
}

sr_msgs__msg__Lane *
sr_msgs__msg__Lane__create()
{
  sr_msgs__msg__Lane * msg = (sr_msgs__msg__Lane *)malloc(sizeof(sr_msgs__msg__Lane));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sr_msgs__msg__Lane));
  bool success = sr_msgs__msg__Lane__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
sr_msgs__msg__Lane__destroy(sr_msgs__msg__Lane * msg)
{
  if (msg) {
    sr_msgs__msg__Lane__fini(msg);
  }
  free(msg);
}


bool
sr_msgs__msg__Lane__Sequence__init(sr_msgs__msg__Lane__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  sr_msgs__msg__Lane * data = NULL;
  if (size) {
    data = (sr_msgs__msg__Lane *)calloc(size, sizeof(sr_msgs__msg__Lane));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sr_msgs__msg__Lane__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sr_msgs__msg__Lane__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sr_msgs__msg__Lane__Sequence__fini(sr_msgs__msg__Lane__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sr_msgs__msg__Lane__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sr_msgs__msg__Lane__Sequence *
sr_msgs__msg__Lane__Sequence__create(size_t size)
{
  sr_msgs__msg__Lane__Sequence * array = (sr_msgs__msg__Lane__Sequence *)malloc(sizeof(sr_msgs__msg__Lane__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = sr_msgs__msg__Lane__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
sr_msgs__msg__Lane__Sequence__destroy(sr_msgs__msg__Lane__Sequence * array)
{
  if (array) {
    sr_msgs__msg__Lane__Sequence__fini(array);
  }
  free(array);
}

bool
sr_msgs__msg__Lane__Sequence__are_equal(const sr_msgs__msg__Lane__Sequence * lhs, const sr_msgs__msg__Lane__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sr_msgs__msg__Lane__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__Lane__Sequence__copy(
  const sr_msgs__msg__Lane__Sequence * input,
  sr_msgs__msg__Lane__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sr_msgs__msg__Lane);
    sr_msgs__msg__Lane * data =
      (sr_msgs__msg__Lane *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sr_msgs__msg__Lane__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sr_msgs__msg__Lane__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sr_msgs__msg__Lane__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
