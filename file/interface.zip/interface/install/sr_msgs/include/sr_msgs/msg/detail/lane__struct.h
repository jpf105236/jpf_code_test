// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/Lane.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__LANE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'lane_type_enum'
#include "sr_msgs/msg/detail/lane_type__struct.h"
// Member 'lane_color_enum'
#include "sr_msgs/msg/detail/lane_color__struct.h"
// Member 'quality_enum'
#include "sr_msgs/msg/detail/lane_confidence__struct.h"
// Member 'lane_id_enum'
#include "sr_msgs/msg/detail/lane_id__struct.h"
// Member 'lane_points_world_list'
#include "sr_msgs/msg/detail/world_point_xy__struct.h"

// Struct defined in msg/Lane in the package sr_msgs.
typedef struct sr_msgs__msg__Lane
{
  sr_msgs__msg__LaneType lane_type_enum;
  sr_msgs__msg__LaneColor lane_color_enum;
  sr_msgs__msg__LaneConfidence quality_enum;
  float marking_width_m;
  float view_range_m;
  bool is_view_range_availability;
  sr_msgs__msg__LaneId lane_id_enum;
  float position_parameter_c0;
  float heading_angle_parameter_c1;
  float curvature_parameter_c2;
  float curvature_derivative_parameter_c3;
  int16_t lane_points_world_size;
  sr_msgs__msg__WorldPointXY lane_points_world_list[100];
} sr_msgs__msg__Lane;

// Struct for a sequence of sr_msgs__msg__Lane.
typedef struct sr_msgs__msg__Lane__Sequence
{
  sr_msgs__msg__Lane * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__Lane__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__LANE__STRUCT_H_
