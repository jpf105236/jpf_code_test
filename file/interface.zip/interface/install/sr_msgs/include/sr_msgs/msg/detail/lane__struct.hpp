// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/Lane.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__LANE__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'lane_type_enum'
#include "sr_msgs/msg/detail/lane_type__struct.hpp"
// Member 'lane_color_enum'
#include "sr_msgs/msg/detail/lane_color__struct.hpp"
// Member 'quality_enum'
#include "sr_msgs/msg/detail/lane_confidence__struct.hpp"
// Member 'lane_id_enum'
#include "sr_msgs/msg/detail/lane_id__struct.hpp"
// Member 'lane_points_world_list'
#include "sr_msgs/msg/detail/world_point_xy__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__Lane __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__Lane __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Lane_
{
  using Type = Lane_<ContainerAllocator>;

  explicit Lane_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : lane_type_enum(_init),
    lane_color_enum(_init),
    quality_enum(_init),
    lane_id_enum(_init)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->marking_width_m = 0.0f;
      this->view_range_m = 0.0f;
      this->is_view_range_availability = false;
      this->position_parameter_c0 = 0.0f;
      this->heading_angle_parameter_c1 = 0.0f;
      this->curvature_parameter_c2 = 0.0f;
      this->curvature_derivative_parameter_c3 = 0.0f;
      this->lane_points_world_size = 0;
      this->lane_points_world_list.fill(sr_msgs::msg::WorldPointXY_<ContainerAllocator>{_init});
    }
  }

  explicit Lane_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : lane_type_enum(_alloc, _init),
    lane_color_enum(_alloc, _init),
    quality_enum(_alloc, _init),
    lane_id_enum(_alloc, _init),
    lane_points_world_list(_alloc)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->marking_width_m = 0.0f;
      this->view_range_m = 0.0f;
      this->is_view_range_availability = false;
      this->position_parameter_c0 = 0.0f;
      this->heading_angle_parameter_c1 = 0.0f;
      this->curvature_parameter_c2 = 0.0f;
      this->curvature_derivative_parameter_c3 = 0.0f;
      this->lane_points_world_size = 0;
      this->lane_points_world_list.fill(sr_msgs::msg::WorldPointXY_<ContainerAllocator>{_alloc, _init});
    }
  }

  // field types and members
  using _lane_type_enum_type =
    sr_msgs::msg::LaneType_<ContainerAllocator>;
  _lane_type_enum_type lane_type_enum;
  using _lane_color_enum_type =
    sr_msgs::msg::LaneColor_<ContainerAllocator>;
  _lane_color_enum_type lane_color_enum;
  using _quality_enum_type =
    sr_msgs::msg::LaneConfidence_<ContainerAllocator>;
  _quality_enum_type quality_enum;
  using _marking_width_m_type =
    float;
  _marking_width_m_type marking_width_m;
  using _view_range_m_type =
    float;
  _view_range_m_type view_range_m;
  using _is_view_range_availability_type =
    bool;
  _is_view_range_availability_type is_view_range_availability;
  using _lane_id_enum_type =
    sr_msgs::msg::LaneId_<ContainerAllocator>;
  _lane_id_enum_type lane_id_enum;
  using _position_parameter_c0_type =
    float;
  _position_parameter_c0_type position_parameter_c0;
  using _heading_angle_parameter_c1_type =
    float;
  _heading_angle_parameter_c1_type heading_angle_parameter_c1;
  using _curvature_parameter_c2_type =
    float;
  _curvature_parameter_c2_type curvature_parameter_c2;
  using _curvature_derivative_parameter_c3_type =
    float;
  _curvature_derivative_parameter_c3_type curvature_derivative_parameter_c3;
  using _lane_points_world_size_type =
    int16_t;
  _lane_points_world_size_type lane_points_world_size;
  using _lane_points_world_list_type =
    std::array<sr_msgs::msg::WorldPointXY_<ContainerAllocator>, 100>;
  _lane_points_world_list_type lane_points_world_list;

  // setters for named parameter idiom
  Type & set__lane_type_enum(
    const sr_msgs::msg::LaneType_<ContainerAllocator> & _arg)
  {
    this->lane_type_enum = _arg;
    return *this;
  }
  Type & set__lane_color_enum(
    const sr_msgs::msg::LaneColor_<ContainerAllocator> & _arg)
  {
    this->lane_color_enum = _arg;
    return *this;
  }
  Type & set__quality_enum(
    const sr_msgs::msg::LaneConfidence_<ContainerAllocator> & _arg)
  {
    this->quality_enum = _arg;
    return *this;
  }
  Type & set__marking_width_m(
    const float & _arg)
  {
    this->marking_width_m = _arg;
    return *this;
  }
  Type & set__view_range_m(
    const float & _arg)
  {
    this->view_range_m = _arg;
    return *this;
  }
  Type & set__is_view_range_availability(
    const bool & _arg)
  {
    this->is_view_range_availability = _arg;
    return *this;
  }
  Type & set__lane_id_enum(
    const sr_msgs::msg::LaneId_<ContainerAllocator> & _arg)
  {
    this->lane_id_enum = _arg;
    return *this;
  }
  Type & set__position_parameter_c0(
    const float & _arg)
  {
    this->position_parameter_c0 = _arg;
    return *this;
  }
  Type & set__heading_angle_parameter_c1(
    const float & _arg)
  {
    this->heading_angle_parameter_c1 = _arg;
    return *this;
  }
  Type & set__curvature_parameter_c2(
    const float & _arg)
  {
    this->curvature_parameter_c2 = _arg;
    return *this;
  }
  Type & set__curvature_derivative_parameter_c3(
    const float & _arg)
  {
    this->curvature_derivative_parameter_c3 = _arg;
    return *this;
  }
  Type & set__lane_points_world_size(
    const int16_t & _arg)
  {
    this->lane_points_world_size = _arg;
    return *this;
  }
  Type & set__lane_points_world_list(
    const std::array<sr_msgs::msg::WorldPointXY_<ContainerAllocator>, 100> & _arg)
  {
    this->lane_points_world_list = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sr_msgs::msg::Lane_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::Lane_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::Lane_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::Lane_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::Lane_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::Lane_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::Lane_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::Lane_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::Lane_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::Lane_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__Lane
    std::shared_ptr<sr_msgs::msg::Lane_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__Lane
    std::shared_ptr<sr_msgs::msg::Lane_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Lane_ & other) const
  {
    if (this->lane_type_enum != other.lane_type_enum) {
      return false;
    }
    if (this->lane_color_enum != other.lane_color_enum) {
      return false;
    }
    if (this->quality_enum != other.quality_enum) {
      return false;
    }
    if (this->marking_width_m != other.marking_width_m) {
      return false;
    }
    if (this->view_range_m != other.view_range_m) {
      return false;
    }
    if (this->is_view_range_availability != other.is_view_range_availability) {
      return false;
    }
    if (this->lane_id_enum != other.lane_id_enum) {
      return false;
    }
    if (this->position_parameter_c0 != other.position_parameter_c0) {
      return false;
    }
    if (this->heading_angle_parameter_c1 != other.heading_angle_parameter_c1) {
      return false;
    }
    if (this->curvature_parameter_c2 != other.curvature_parameter_c2) {
      return false;
    }
    if (this->curvature_derivative_parameter_c3 != other.curvature_derivative_parameter_c3) {
      return false;
    }
    if (this->lane_points_world_size != other.lane_points_world_size) {
      return false;
    }
    if (this->lane_points_world_list != other.lane_points_world_list) {
      return false;
    }
    return true;
  }
  bool operator!=(const Lane_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Lane_

// alias to use template instance with default allocator
using Lane =
  sr_msgs::msg::Lane_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__LANE__STRUCT_HPP_
