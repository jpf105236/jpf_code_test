// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sr_msgs:msg/Lane.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE__TRAITS_HPP_
#define SR_MSGS__MSG__DETAIL__LANE__TRAITS_HPP_

#include "sr_msgs/msg/detail/lane__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'lane_type_enum'
#include "sr_msgs/msg/detail/lane_type__traits.hpp"
// Member 'lane_color_enum'
#include "sr_msgs/msg/detail/lane_color__traits.hpp"
// Member 'quality_enum'
#include "sr_msgs/msg/detail/lane_confidence__traits.hpp"
// Member 'lane_id_enum'
#include "sr_msgs/msg/detail/lane_id__traits.hpp"
// Member 'lane_points_world_list'
#include "sr_msgs/msg/detail/world_point_xy__traits.hpp"

namespace nexidl_generator_traits
{

inline void to_yaml(
  const sr_msgs::msg::Lane & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: lane_type_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lane_type_enum:\n";
    to_yaml(msg.lane_type_enum, out, indentation + 2);
  }

  // member: lane_color_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lane_color_enum:\n";
    to_yaml(msg.lane_color_enum, out, indentation + 2);
  }

  // member: quality_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "quality_enum:\n";
    to_yaml(msg.quality_enum, out, indentation + 2);
  }

  // member: marking_width_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "marking_width_m: ";
    value_to_yaml(msg.marking_width_m, out);
    out << "\n";
  }

  // member: view_range_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "view_range_m: ";
    value_to_yaml(msg.view_range_m, out);
    out << "\n";
  }

  // member: is_view_range_availability
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_view_range_availability: ";
    value_to_yaml(msg.is_view_range_availability, out);
    out << "\n";
  }

  // member: lane_id_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lane_id_enum:\n";
    to_yaml(msg.lane_id_enum, out, indentation + 2);
  }

  // member: position_parameter_c0
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_parameter_c0: ";
    value_to_yaml(msg.position_parameter_c0, out);
    out << "\n";
  }

  // member: heading_angle_parameter_c1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "heading_angle_parameter_c1: ";
    value_to_yaml(msg.heading_angle_parameter_c1, out);
    out << "\n";
  }

  // member: curvature_parameter_c2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "curvature_parameter_c2: ";
    value_to_yaml(msg.curvature_parameter_c2, out);
    out << "\n";
  }

  // member: curvature_derivative_parameter_c3
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "curvature_derivative_parameter_c3: ";
    value_to_yaml(msg.curvature_derivative_parameter_c3, out);
    out << "\n";
  }

  // member: lane_points_world_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lane_points_world_size: ";
    value_to_yaml(msg.lane_points_world_size, out);
    out << "\n";
  }

  // member: lane_points_world_list
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.lane_points_world_list.size() == 0) {
      out << "lane_points_world_list: []\n";
    } else {
      out << "lane_points_world_list:\n";
      for (auto item : msg.lane_points_world_list) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const sr_msgs::msg::Lane & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<sr_msgs::msg::Lane>()
{
  return "sr_msgs::msg::Lane";
}

template<>
inline const char * name<sr_msgs::msg::Lane>()
{
  return "sr_msgs/msg/Lane";
}

template<>
struct has_fixed_size<sr_msgs::msg::Lane>
  : std::integral_constant<bool, has_fixed_size<sr_msgs::msg::LaneColor>::value && has_fixed_size<sr_msgs::msg::LaneConfidence>::value && has_fixed_size<sr_msgs::msg::LaneId>::value && has_fixed_size<sr_msgs::msg::LaneType>::value && has_fixed_size<sr_msgs::msg::WorldPointXY>::value> {};

template<>
struct has_bounded_size<sr_msgs::msg::Lane>
  : std::integral_constant<bool, has_bounded_size<sr_msgs::msg::LaneColor>::value && has_bounded_size<sr_msgs::msg::LaneConfidence>::value && has_bounded_size<sr_msgs::msg::LaneId>::value && has_bounded_size<sr_msgs::msg::LaneType>::value && has_bounded_size<sr_msgs::msg::WorldPointXY>::value> {};

template<>
struct is_message<sr_msgs::msg::Lane>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // SR_MSGS__MSG__DETAIL__LANE__TRAITS_HPP_
