// generated from nexidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from sr_msgs:msg/Lane.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "sr_msgs/msg/detail/lane__nexidl_typesupport_introspection_c.h"
#include "sr_msgs/msg/nexidl_typesupport_introspection_c__visibility_control.h"
#include "nexidl_typesupport_introspection_c/field_types.h"
#include "nexidl_typesupport_introspection_c/identifier.h"
#include "nexidl_typesupport_introspection_c/message_introspection.h"
#include "sr_msgs/msg/detail/lane__functions.h"
#include "sr_msgs/msg/detail/lane__struct.h"


// Include directives for member types
// Member `lane_type_enum`
#include "sr_msgs/msg/lane_type.h"
// Member `lane_type_enum`
#include "sr_msgs/msg/detail/lane_type__nexidl_typesupport_introspection_c.h"
// Member `lane_color_enum`
#include "sr_msgs/msg/lane_color.h"
// Member `lane_color_enum`
#include "sr_msgs/msg/detail/lane_color__nexidl_typesupport_introspection_c.h"
// Member `quality_enum`
#include "sr_msgs/msg/lane_confidence.h"
// Member `quality_enum`
#include "sr_msgs/msg/detail/lane_confidence__nexidl_typesupport_introspection_c.h"
// Member `lane_id_enum`
#include "sr_msgs/msg/lane_id.h"
// Member `lane_id_enum`
#include "sr_msgs/msg/detail/lane_id__nexidl_typesupport_introspection_c.h"
// Member `lane_points_world_list`
#include "sr_msgs/msg/world_point_xy.h"
// Member `lane_points_world_list`
#include "sr_msgs/msg/detail/world_point_xy__nexidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void Lane__nexidl_typesupport_introspection_c__Lane_init_function(
  void * message_memory, enum nexidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/nex/nex/issues/397
  (void) _init;
  sr_msgs__msg__Lane__init(message_memory);
}

void Lane__nexidl_typesupport_introspection_c__Lane_fini_function(void * message_memory)
{
  sr_msgs__msg__Lane__fini(message_memory);
}

size_t Lane__nexidl_typesupport_introspection_c__size_function__WorldPointXY__lane_points_world_list(
  const void * untyped_member)
{
  (void)untyped_member;
  return 100;
}

const void * Lane__nexidl_typesupport_introspection_c__get_const_function__WorldPointXY__lane_points_world_list(
  const void * untyped_member, size_t index)
{
  const sr_msgs__msg__WorldPointXY * member =
    (const sr_msgs__msg__WorldPointXY *)(untyped_member);
  return &member[index];
}

void * Lane__nexidl_typesupport_introspection_c__get_function__WorldPointXY__lane_points_world_list(
  void * untyped_member, size_t index)
{
  sr_msgs__msg__WorldPointXY * member =
    (sr_msgs__msg__WorldPointXY *)(untyped_member);
  return &member[index];
}

static nexidl_typesupport_introspection_c__MessageMember Lane__nexidl_typesupport_introspection_c__Lane_message_member_array[13] = {
  {
    "lane_type_enum",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, lane_type_enum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "lane_color_enum",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, lane_color_enum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "quality_enum",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, quality_enum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "marking_width_m",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, marking_width_m),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "view_range_m",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, view_range_m),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "is_view_range_availability",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, is_view_range_availability),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "lane_id_enum",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, lane_id_enum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "position_parameter_c0",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, position_parameter_c0),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "heading_angle_parameter_c1",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, heading_angle_parameter_c1),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "curvature_parameter_c2",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, curvature_parameter_c2),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "curvature_derivative_parameter_c3",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, curvature_derivative_parameter_c3),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "lane_points_world_size",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, lane_points_world_size),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "lane_points_world_list",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    100,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__Lane, lane_points_world_list),  // bytes offset in struct
    NULL,  // default value
    Lane__nexidl_typesupport_introspection_c__size_function__WorldPointXY__lane_points_world_list,  // size() function pointer
    Lane__nexidl_typesupport_introspection_c__get_const_function__WorldPointXY__lane_points_world_list,  // get_const(index) function pointer
    Lane__nexidl_typesupport_introspection_c__get_function__WorldPointXY__lane_points_world_list,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const nexidl_typesupport_introspection_c__MessageMembers Lane__nexidl_typesupport_introspection_c__Lane_message_members = {
  "sr_msgs__msg",  // message namespace
  "Lane",  // message name
  13,  // number of fields
  sizeof(sr_msgs__msg__Lane),
  Lane__nexidl_typesupport_introspection_c__Lane_message_member_array,  // message members
  Lane__nexidl_typesupport_introspection_c__Lane_init_function,  // function to initialize message memory (memory has to be allocated)
  Lane__nexidl_typesupport_introspection_c__Lane_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static nexidl_message_type_support_t Lane__nexidl_typesupport_introspection_c__Lane_message_type_support_handle = {
  0,
  &Lane__nexidl_typesupport_introspection_c__Lane_message_members,
  get_message_typesupport_handle_function,
};

NEXIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_sr_msgs
const nexidl_message_type_support_t *
NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, Lane)() {
  Lane__nexidl_typesupport_introspection_c__Lane_message_member_array[0].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, LaneType)();
  Lane__nexidl_typesupport_introspection_c__Lane_message_member_array[1].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, LaneColor)();
  Lane__nexidl_typesupport_introspection_c__Lane_message_member_array[2].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, LaneConfidence)();
  Lane__nexidl_typesupport_introspection_c__Lane_message_member_array[6].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, LaneId)();
  Lane__nexidl_typesupport_introspection_c__Lane_message_member_array[12].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, WorldPointXY)();
  if (!Lane__nexidl_typesupport_introspection_c__Lane_message_type_support_handle.typesupport_identifier) {
    Lane__nexidl_typesupport_introspection_c__Lane_message_type_support_handle.typesupport_identifier =
      nexidl_typesupport_introspection_c__identifier;
  }
  return &Lane__nexidl_typesupport_introspection_c__Lane_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
