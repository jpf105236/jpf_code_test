// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/LaneColor.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE_COLOR__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__LANE_COLOR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'LANE_COLOR_WHITE'.
enum
{
  sr_msgs__msg__LaneColor__LANE_COLOR_WHITE = 0
};

/// Constant 'LANE_COLOR_YELLOW'.
enum
{
  sr_msgs__msg__LaneColor__LANE_COLOR_YELLOW = 1
};

/// Constant 'LANE_COLOR_RED'.
enum
{
  sr_msgs__msg__LaneColor__LANE_COLOR_RED = 2
};

// Struct defined in msg/LaneColor in the package sr_msgs.
typedef struct sr_msgs__msg__LaneColor
{
  uint8_t value;
} sr_msgs__msg__LaneColor;

// Struct for a sequence of sr_msgs__msg__LaneColor.
typedef struct sr_msgs__msg__LaneColor__Sequence
{
  sr_msgs__msg__LaneColor * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__LaneColor__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__LANE_COLOR__STRUCT_H_
