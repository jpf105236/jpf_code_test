// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sr_msgs:msg/LaneColor.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE_COLOR__TRAITS_HPP_
#define SR_MSGS__MSG__DETAIL__LANE_COLOR__TRAITS_HPP_

#include "sr_msgs/msg/detail/lane_color__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace nexidl_generator_traits
{

inline void to_yaml(
  const sr_msgs::msg::LaneColor & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: value
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "value: ";
    value_to_yaml(msg.value, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const sr_msgs::msg::LaneColor & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<sr_msgs::msg::LaneColor>()
{
  return "sr_msgs::msg::LaneColor";
}

template<>
inline const char * name<sr_msgs::msg::LaneColor>()
{
  return "sr_msgs/msg/LaneColor";
}

template<>
struct has_fixed_size<sr_msgs::msg::LaneColor>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<sr_msgs::msg::LaneColor>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<sr_msgs::msg::LaneColor>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // SR_MSGS__MSG__DETAIL__LANE_COLOR__TRAITS_HPP_
