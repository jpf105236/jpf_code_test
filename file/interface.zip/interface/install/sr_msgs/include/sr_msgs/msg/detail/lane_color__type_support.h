// generated from nexidl_generator_c/resource/idl__type_support.h.em
// with input from sr_msgs:msg/LaneColor.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE_COLOR__TYPE_SUPPORT_H_
#define SR_MSGS__MSG__DETAIL__LANE_COLOR__TYPE_SUPPORT_H_

#include "nexidl_typesupport_interface/macros.h"

#include "sr_msgs/msg/nexidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "nexidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
const nexidl_message_type_support_t *
NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  nexidl_typesupport_c,
  sr_msgs,
  msg,
  LaneColor
)();

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__LANE_COLOR__TYPE_SUPPORT_H_
