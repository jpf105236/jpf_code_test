// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/LaneConfidence.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE_CONFIDENCE__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__LANE_CONFIDENCE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'LANE_CONFIDENCE_NONE'.
enum
{
  sr_msgs__msg__LaneConfidence__LANE_CONFIDENCE_NONE = 0
};

/// Constant 'LANE_CONFIDENCE_LOW'.
enum
{
  sr_msgs__msg__LaneConfidence__LANE_CONFIDENCE_LOW = 1
};

/// Constant 'LANE_CONFIDENCE_MED'.
enum
{
  sr_msgs__msg__LaneConfidence__LANE_CONFIDENCE_MED = 2
};

/// Constant 'LANE_CONFIDENCE_HIGH'.
enum
{
  sr_msgs__msg__LaneConfidence__LANE_CONFIDENCE_HIGH = 3
};

// Struct defined in msg/LaneConfidence in the package sr_msgs.
typedef struct sr_msgs__msg__LaneConfidence
{
  uint8_t value;
} sr_msgs__msg__LaneConfidence;

// Struct for a sequence of sr_msgs__msg__LaneConfidence.
typedef struct sr_msgs__msg__LaneConfidence__Sequence
{
  sr_msgs__msg__LaneConfidence * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__LaneConfidence__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__LANE_CONFIDENCE__STRUCT_H_
