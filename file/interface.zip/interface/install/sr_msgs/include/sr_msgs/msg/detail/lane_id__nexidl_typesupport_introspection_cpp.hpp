// generated from nexidl_typesupport_introspection_cpp/resource/idl__nexidl_typesupport_introspection_cpp.h.em
// with input from sr_msgs:msg/LaneId.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE_ID__NEXIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
#define SR_MSGS__MSG__DETAIL__LANE_ID__NEXIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_


#include "nexidl_runtime_c/message_type_support_struct.h"
#include "nexidl_typesupport_interface/macros.h"
#include "nexidl_typesupport_introspection_cpp/visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

// TODO(dirk-thomas) these visibility macros should be message package specific
NEXIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const nexidl_message_type_support_t *
  NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_cpp, sr_msgs, msg, LaneId)();

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__LANE_ID__NEXIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
