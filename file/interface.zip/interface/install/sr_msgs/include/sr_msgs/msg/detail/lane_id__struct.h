// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/LaneId.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE_ID__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__LANE_ID__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'LANE_ID_EGO_LEFT'.
enum
{
  sr_msgs__msg__LaneId__LANE_ID_EGO_LEFT = 0
};

/// Constant 'LANE_ID_EGO_RIGHT'.
enum
{
  sr_msgs__msg__LaneId__LANE_ID_EGO_RIGHT = 1
};

/// Constant 'LANE_ID_NEXT_LEFT'.
enum
{
  sr_msgs__msg__LaneId__LANE_ID_NEXT_LEFT = 2
};

/// Constant 'LANE_ID_NEXT_RIGHT'.
enum
{
  sr_msgs__msg__LaneId__LANE_ID_NEXT_RIGHT = 3
};

// Struct defined in msg/LaneId in the package sr_msgs.
typedef struct sr_msgs__msg__LaneId
{
  uint8_t value;
} sr_msgs__msg__LaneId;

// Struct for a sequence of sr_msgs__msg__LaneId.
typedef struct sr_msgs__msg__LaneId__Sequence
{
  sr_msgs__msg__LaneId * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__LaneId__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__LANE_ID__STRUCT_H_
