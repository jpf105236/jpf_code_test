// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/LaneType.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE_TYPE__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__LANE_TYPE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'LANE_DASHED_SINGLE'.
enum
{
  sr_msgs__msg__LaneType__LANE_DASHED_SINGLE = 0
};

/// Constant 'LANE_SOLID_SINGLE'.
enum
{
  sr_msgs__msg__LaneType__LANE_SOLID_SINGLE = 1
};

/// Constant 'LANE_DASHED_DOUBLE'.
enum
{
  sr_msgs__msg__LaneType__LANE_DASHED_DOUBLE = 2
};

/// Constant 'LANE_SOLID_DOUBLE'.
enum
{
  sr_msgs__msg__LaneType__LANE_SOLID_DOUBLE = 3
};

/// Constant 'LANE_ZIGZAG_SINGLE'.
enum
{
  sr_msgs__msg__LaneType__LANE_ZIGZAG_SINGLE = 4
};

/// Constant 'LANE_ZIGZAG_DOUBLE'.
enum
{
  sr_msgs__msg__LaneType__LANE_ZIGZAG_DOUBLE = 5
};

/// Constant 'LANE_ROAD_CURB'.
enum
{
  sr_msgs__msg__LaneType__LANE_ROAD_CURB = 6
};

// Struct defined in msg/LaneType in the package sr_msgs.
typedef struct sr_msgs__msg__LaneType
{
  uint8_t value;
} sr_msgs__msg__LaneType;

// Struct for a sequence of sr_msgs__msg__LaneType.
typedef struct sr_msgs__msg__LaneType__Sequence
{
  sr_msgs__msg__LaneType * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__LaneType__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__LANE_TYPE__STRUCT_H_
