// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/LaneType.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LANE_TYPE__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__LANE_TYPE__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__LaneType __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__LaneType __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LaneType_
{
  using Type = LaneType_<ContainerAllocator>;

  explicit LaneType_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->value = 0;
    }
  }

  explicit LaneType_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->value = 0;
    }
  }

  // field types and members
  using _value_type =
    uint8_t;
  _value_type value;

  // setters for named parameter idiom
  Type & set__value(
    const uint8_t & _arg)
  {
    this->value = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t LANE_DASHED_SINGLE =
    0u;
  static constexpr uint8_t LANE_SOLID_SINGLE =
    1u;
  static constexpr uint8_t LANE_DASHED_DOUBLE =
    2u;
  static constexpr uint8_t LANE_SOLID_DOUBLE =
    3u;
  static constexpr uint8_t LANE_ZIGZAG_SINGLE =
    4u;
  static constexpr uint8_t LANE_ZIGZAG_DOUBLE =
    5u;
  static constexpr uint8_t LANE_ROAD_CURB =
    6u;

  // pointer types
  using RawPtr =
    sr_msgs::msg::LaneType_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::LaneType_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::LaneType_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::LaneType_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::LaneType_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::LaneType_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::LaneType_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::LaneType_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::LaneType_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::LaneType_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__LaneType
    std::shared_ptr<sr_msgs::msg::LaneType_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__LaneType
    std::shared_ptr<sr_msgs::msg::LaneType_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LaneType_ & other) const
  {
    if (this->value != other.value) {
      return false;
    }
    return true;
  }
  bool operator!=(const LaneType_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LaneType_

// alias to use template instance with default allocator
using LaneType =
  sr_msgs::msg::LaneType_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
constexpr uint8_t LaneType_<ContainerAllocator>::LANE_DASHED_SINGLE;
template<typename ContainerAllocator>
constexpr uint8_t LaneType_<ContainerAllocator>::LANE_SOLID_SINGLE;
template<typename ContainerAllocator>
constexpr uint8_t LaneType_<ContainerAllocator>::LANE_DASHED_DOUBLE;
template<typename ContainerAllocator>
constexpr uint8_t LaneType_<ContainerAllocator>::LANE_SOLID_DOUBLE;
template<typename ContainerAllocator>
constexpr uint8_t LaneType_<ContainerAllocator>::LANE_ZIGZAG_SINGLE;
template<typename ContainerAllocator>
constexpr uint8_t LaneType_<ContainerAllocator>::LANE_ZIGZAG_DOUBLE;
template<typename ContainerAllocator>
constexpr uint8_t LaneType_<ContainerAllocator>::LANE_ROAD_CURB;

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__LANE_TYPE__STRUCT_HPP_
