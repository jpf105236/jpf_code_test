// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/LocationInfo.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LOCATION_INFO__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__LOCATION_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'ego_pose'
#include "sr_msgs/msg/detail/object_pose__struct.h"
// Member 'location_enum'
#include "sr_msgs/msg/detail/location_info_location__struct.h"

// Struct defined in msg/LocationInfo in the package sr_msgs.
typedef struct sr_msgs__msg__LocationInfo
{
  sr_msgs__msg__ObjectPose ego_pose;
  sr_msgs__msg__LocationInfoLocation location_enum;
} sr_msgs__msg__LocationInfo;

// Struct for a sequence of sr_msgs__msg__LocationInfo.
typedef struct sr_msgs__msg__LocationInfo__Sequence
{
  sr_msgs__msg__LocationInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__LocationInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__LOCATION_INFO__STRUCT_H_
