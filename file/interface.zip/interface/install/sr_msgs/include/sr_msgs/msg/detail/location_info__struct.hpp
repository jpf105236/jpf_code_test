// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/LocationInfo.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LOCATION_INFO__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__LOCATION_INFO__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'ego_pose'
#include "sr_msgs/msg/detail/object_pose__struct.hpp"
// Member 'location_enum'
#include "sr_msgs/msg/detail/location_info_location__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__LocationInfo __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__LocationInfo __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LocationInfo_
{
  using Type = LocationInfo_<ContainerAllocator>;

  explicit LocationInfo_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : ego_pose(_init),
    location_enum(_init)
  {
    (void)_init;
  }

  explicit LocationInfo_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : ego_pose(_alloc, _init),
    location_enum(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _ego_pose_type =
    sr_msgs::msg::ObjectPose_<ContainerAllocator>;
  _ego_pose_type ego_pose;
  using _location_enum_type =
    sr_msgs::msg::LocationInfoLocation_<ContainerAllocator>;
  _location_enum_type location_enum;

  // setters for named parameter idiom
  Type & set__ego_pose(
    const sr_msgs::msg::ObjectPose_<ContainerAllocator> & _arg)
  {
    this->ego_pose = _arg;
    return *this;
  }
  Type & set__location_enum(
    const sr_msgs::msg::LocationInfoLocation_<ContainerAllocator> & _arg)
  {
    this->location_enum = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sr_msgs::msg::LocationInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::LocationInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::LocationInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::LocationInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::LocationInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::LocationInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::LocationInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::LocationInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::LocationInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::LocationInfo_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__LocationInfo
    std::shared_ptr<sr_msgs::msg::LocationInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__LocationInfo
    std::shared_ptr<sr_msgs::msg::LocationInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LocationInfo_ & other) const
  {
    if (this->ego_pose != other.ego_pose) {
      return false;
    }
    if (this->location_enum != other.location_enum) {
      return false;
    }
    return true;
  }
  bool operator!=(const LocationInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LocationInfo_

// alias to use template instance with default allocator
using LocationInfo =
  sr_msgs::msg::LocationInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__LOCATION_INFO__STRUCT_HPP_
