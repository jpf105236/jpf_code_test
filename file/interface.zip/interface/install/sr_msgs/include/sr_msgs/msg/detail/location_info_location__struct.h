// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/LocationInfoLocation.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LOCATION_INFO_LOCATION__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__LOCATION_INFO_LOCATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'LOCATION_DEFAULT'.
enum
{
  sr_msgs__msg__LocationInfoLocation__LOCATION_DEFAULT = 0
};

/// Constant 'LOCATION_JUNCTION_WO_SIGNAL'.
enum
{
  sr_msgs__msg__LocationInfoLocation__LOCATION_JUNCTION_WO_SIGNAL = 1
};

/// Constant 'LOCATION_JUNCTION_W_SIGNAL'.
enum
{
  sr_msgs__msg__LocationInfoLocation__LOCATION_JUNCTION_W_SIGNAL = 2
};

/// Constant 'LOCATION_ROUNDABOUT'.
enum
{
  sr_msgs__msg__LocationInfoLocation__LOCATION_ROUNDABOUT = 3
};

/// Constant 'LOCATION_BRIDGE'.
enum
{
  sr_msgs__msg__LocationInfoLocation__LOCATION_BRIDGE = 4
};

/// Constant 'LOCATION_RAMP'.
enum
{
  sr_msgs__msg__LocationInfoLocation__LOCATION_RAMP = 5
};

/// Constant 'LOCATION_UPHILL'.
enum
{
  sr_msgs__msg__LocationInfoLocation__LOCATION_UPHILL = 6
};

/// Constant 'LOCATION_DOWNHILL'.
enum
{
  sr_msgs__msg__LocationInfoLocation__LOCATION_DOWNHILL = 7
};

/// Constant 'LOCATION_TUNNEL'.
enum
{
  sr_msgs__msg__LocationInfoLocation__LOCATION_TUNNEL = 8
};

/// Constant 'LOCATION_BEND'.
enum
{
  sr_msgs__msg__LocationInfoLocation__LOCATION_BEND = 9
};

/// Constant 'LOCATION_CONSTRUCTION_ZONE'.
enum
{
  sr_msgs__msg__LocationInfoLocation__LOCATION_CONSTRUCTION_ZONE = 10
};

// Struct defined in msg/LocationInfoLocation in the package sr_msgs.
typedef struct sr_msgs__msg__LocationInfoLocation
{
  uint8_t value;
} sr_msgs__msg__LocationInfoLocation;

// Struct for a sequence of sr_msgs__msg__LocationInfoLocation.
typedef struct sr_msgs__msg__LocationInfoLocation__Sequence
{
  sr_msgs__msg__LocationInfoLocation * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__LocationInfoLocation__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__LOCATION_INFO_LOCATION__STRUCT_H_
