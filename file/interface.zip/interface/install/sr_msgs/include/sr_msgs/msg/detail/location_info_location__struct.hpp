// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/LocationInfoLocation.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__LOCATION_INFO_LOCATION__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__LOCATION_INFO_LOCATION__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__LocationInfoLocation __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__LocationInfoLocation __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LocationInfoLocation_
{
  using Type = LocationInfoLocation_<ContainerAllocator>;

  explicit LocationInfoLocation_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->value = 0;
    }
  }

  explicit LocationInfoLocation_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->value = 0;
    }
  }

  // field types and members
  using _value_type =
    uint8_t;
  _value_type value;

  // setters for named parameter idiom
  Type & set__value(
    const uint8_t & _arg)
  {
    this->value = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t LOCATION_DEFAULT =
    0u;
  static constexpr uint8_t LOCATION_JUNCTION_WO_SIGNAL =
    1u;
  static constexpr uint8_t LOCATION_JUNCTION_W_SIGNAL =
    2u;
  static constexpr uint8_t LOCATION_ROUNDABOUT =
    3u;
  static constexpr uint8_t LOCATION_BRIDGE =
    4u;
  static constexpr uint8_t LOCATION_RAMP =
    5u;
  static constexpr uint8_t LOCATION_UPHILL =
    6u;
  static constexpr uint8_t LOCATION_DOWNHILL =
    7u;
  static constexpr uint8_t LOCATION_TUNNEL =
    8u;
  static constexpr uint8_t LOCATION_BEND =
    9u;
  static constexpr uint8_t LOCATION_CONSTRUCTION_ZONE =
    10u;

  // pointer types
  using RawPtr =
    sr_msgs::msg::LocationInfoLocation_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::LocationInfoLocation_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::LocationInfoLocation_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::LocationInfoLocation_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::LocationInfoLocation_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::LocationInfoLocation_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::LocationInfoLocation_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::LocationInfoLocation_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::LocationInfoLocation_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::LocationInfoLocation_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__LocationInfoLocation
    std::shared_ptr<sr_msgs::msg::LocationInfoLocation_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__LocationInfoLocation
    std::shared_ptr<sr_msgs::msg::LocationInfoLocation_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LocationInfoLocation_ & other) const
  {
    if (this->value != other.value) {
      return false;
    }
    return true;
  }
  bool operator!=(const LocationInfoLocation_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LocationInfoLocation_

// alias to use template instance with default allocator
using LocationInfoLocation =
  sr_msgs::msg::LocationInfoLocation_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
constexpr uint8_t LocationInfoLocation_<ContainerAllocator>::LOCATION_DEFAULT;
template<typename ContainerAllocator>
constexpr uint8_t LocationInfoLocation_<ContainerAllocator>::LOCATION_JUNCTION_WO_SIGNAL;
template<typename ContainerAllocator>
constexpr uint8_t LocationInfoLocation_<ContainerAllocator>::LOCATION_JUNCTION_W_SIGNAL;
template<typename ContainerAllocator>
constexpr uint8_t LocationInfoLocation_<ContainerAllocator>::LOCATION_ROUNDABOUT;
template<typename ContainerAllocator>
constexpr uint8_t LocationInfoLocation_<ContainerAllocator>::LOCATION_BRIDGE;
template<typename ContainerAllocator>
constexpr uint8_t LocationInfoLocation_<ContainerAllocator>::LOCATION_RAMP;
template<typename ContainerAllocator>
constexpr uint8_t LocationInfoLocation_<ContainerAllocator>::LOCATION_UPHILL;
template<typename ContainerAllocator>
constexpr uint8_t LocationInfoLocation_<ContainerAllocator>::LOCATION_DOWNHILL;
template<typename ContainerAllocator>
constexpr uint8_t LocationInfoLocation_<ContainerAllocator>::LOCATION_TUNNEL;
template<typename ContainerAllocator>
constexpr uint8_t LocationInfoLocation_<ContainerAllocator>::LOCATION_BEND;
template<typename ContainerAllocator>
constexpr uint8_t LocationInfoLocation_<ContainerAllocator>::LOCATION_CONSTRUCTION_ZONE;

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__LOCATION_INFO_LOCATION__STRUCT_HPP_
