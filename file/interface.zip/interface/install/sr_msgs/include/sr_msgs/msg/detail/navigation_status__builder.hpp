// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sr_msgs:msg/NavigationStatus.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__NAVIGATION_STATUS__BUILDER_HPP_
#define SR_MSGS__MSG__DETAIL__NAVIGATION_STATUS__BUILDER_HPP_

#include "sr_msgs/msg/detail/navigation_status__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sr_msgs
{

namespace msg
{

namespace builder
{

class Init_NavigationStatus_value
{
public:
  Init_NavigationStatus_value()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::sr_msgs::msg::NavigationStatus value(::sr_msgs::msg::NavigationStatus::_value_type arg)
  {
    msg_.value = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sr_msgs::msg::NavigationStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sr_msgs::msg::NavigationStatus>()
{
  return sr_msgs::msg::builder::Init_NavigationStatus_value();
}

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__NAVIGATION_STATUS__BUILDER_HPP_
