// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/NavigationStatus.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__NAVIGATION_STATUS__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__NAVIGATION_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'NAVIGATION_LANE_CHANGE'.
enum
{
  sr_msgs__msg__NavigationStatus__NAVIGATION_LANE_CHANGE = 0
};

/// Constant 'NAVIGATION_OBSTACLE_AVOIDANCE'.
enum
{
  sr_msgs__msg__NavigationStatus__NAVIGATION_OBSTACLE_AVOIDANCE = 1
};

/// Constant 'NAVIGATION_LANE_KEEPING'.
enum
{
  sr_msgs__msg__NavigationStatus__NAVIGATION_LANE_KEEPING = 2
};

// Struct defined in msg/NavigationStatus in the package sr_msgs.
typedef struct sr_msgs__msg__NavigationStatus
{
  uint8_t value;
} sr_msgs__msg__NavigationStatus;

// Struct for a sequence of sr_msgs__msg__NavigationStatus.
typedef struct sr_msgs__msg__NavigationStatus__Sequence
{
  sr_msgs__msg__NavigationStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__NavigationStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__NAVIGATION_STATUS__STRUCT_H_
