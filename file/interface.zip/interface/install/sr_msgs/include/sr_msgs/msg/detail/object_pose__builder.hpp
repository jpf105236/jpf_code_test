// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sr_msgs:msg/ObjectPose.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__OBJECT_POSE__BUILDER_HPP_
#define SR_MSGS__MSG__DETAIL__OBJECT_POSE__BUILDER_HPP_

#include "sr_msgs/msg/detail/object_pose__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sr_msgs
{

namespace msg
{

namespace builder
{

class Init_ObjectPose_pos_z_m
{
public:
  explicit Init_ObjectPose_pos_z_m(::sr_msgs::msg::ObjectPose & msg)
  : msg_(msg)
  {}
  ::sr_msgs::msg::ObjectPose pos_z_m(::sr_msgs::msg::ObjectPose::_pos_z_m_type arg)
  {
    msg_.pos_z_m = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sr_msgs::msg::ObjectPose msg_;
};

class Init_ObjectPose_pos_y_m
{
public:
  explicit Init_ObjectPose_pos_y_m(::sr_msgs::msg::ObjectPose & msg)
  : msg_(msg)
  {}
  Init_ObjectPose_pos_z_m pos_y_m(::sr_msgs::msg::ObjectPose::_pos_y_m_type arg)
  {
    msg_.pos_y_m = std::move(arg);
    return Init_ObjectPose_pos_z_m(msg_);
  }

private:
  ::sr_msgs::msg::ObjectPose msg_;
};

class Init_ObjectPose_pos_x_m
{
public:
  Init_ObjectPose_pos_x_m()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ObjectPose_pos_y_m pos_x_m(::sr_msgs::msg::ObjectPose::_pos_x_m_type arg)
  {
    msg_.pos_x_m = std::move(arg);
    return Init_ObjectPose_pos_y_m(msg_);
  }

private:
  ::sr_msgs::msg::ObjectPose msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sr_msgs::msg::ObjectPose>()
{
  return sr_msgs::msg::builder::Init_ObjectPose_pos_x_m();
}

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__OBJECT_POSE__BUILDER_HPP_
