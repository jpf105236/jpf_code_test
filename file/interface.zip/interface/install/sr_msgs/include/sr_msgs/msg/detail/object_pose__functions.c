// generated from nexidl_generator_c/resource/idl__functions.c.em
// with input from sr_msgs:msg/ObjectPose.idl
// generated code does not contain a copyright notice
#include "sr_msgs/msg/detail/object_pose__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
sr_msgs__msg__ObjectPose__init(sr_msgs__msg__ObjectPose * msg)
{
  if (!msg) {
    return false;
  }
  // pos_x_m
  // pos_y_m
  // pos_z_m
  return true;
}

void
sr_msgs__msg__ObjectPose__fini(sr_msgs__msg__ObjectPose * msg)
{
  if (!msg) {
    return;
  }
  // pos_x_m
  // pos_y_m
  // pos_z_m
}

bool
sr_msgs__msg__ObjectPose__are_equal(const sr_msgs__msg__ObjectPose * lhs, const sr_msgs__msg__ObjectPose * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // pos_x_m
  if (lhs->pos_x_m != rhs->pos_x_m) {
    return false;
  }
  // pos_y_m
  if (lhs->pos_y_m != rhs->pos_y_m) {
    return false;
  }
  // pos_z_m
  if (lhs->pos_z_m != rhs->pos_z_m) {
    return false;
  }
  return true;
}

bool
sr_msgs__msg__ObjectPose__copy(
  const sr_msgs__msg__ObjectPose * input,
  sr_msgs__msg__ObjectPose * output)
{
  if (!input || !output) {
    return false;
  }
  // pos_x_m
  output->pos_x_m = input->pos_x_m;
  // pos_y_m
  output->pos_y_m = input->pos_y_m;
  // pos_z_m
  output->pos_z_m = input->pos_z_m;
  return true;
}

sr_msgs__msg__ObjectPose *
sr_msgs__msg__ObjectPose__create()
{
  sr_msgs__msg__ObjectPose * msg = (sr_msgs__msg__ObjectPose *)malloc(sizeof(sr_msgs__msg__ObjectPose));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sr_msgs__msg__ObjectPose));
  bool success = sr_msgs__msg__ObjectPose__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
sr_msgs__msg__ObjectPose__destroy(sr_msgs__msg__ObjectPose * msg)
{
  if (msg) {
    sr_msgs__msg__ObjectPose__fini(msg);
  }
  free(msg);
}


bool
sr_msgs__msg__ObjectPose__Sequence__init(sr_msgs__msg__ObjectPose__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  sr_msgs__msg__ObjectPose * data = NULL;
  if (size) {
    data = (sr_msgs__msg__ObjectPose *)calloc(size, sizeof(sr_msgs__msg__ObjectPose));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sr_msgs__msg__ObjectPose__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sr_msgs__msg__ObjectPose__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sr_msgs__msg__ObjectPose__Sequence__fini(sr_msgs__msg__ObjectPose__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sr_msgs__msg__ObjectPose__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sr_msgs__msg__ObjectPose__Sequence *
sr_msgs__msg__ObjectPose__Sequence__create(size_t size)
{
  sr_msgs__msg__ObjectPose__Sequence * array = (sr_msgs__msg__ObjectPose__Sequence *)malloc(sizeof(sr_msgs__msg__ObjectPose__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = sr_msgs__msg__ObjectPose__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
sr_msgs__msg__ObjectPose__Sequence__destroy(sr_msgs__msg__ObjectPose__Sequence * array)
{
  if (array) {
    sr_msgs__msg__ObjectPose__Sequence__fini(array);
  }
  free(array);
}

bool
sr_msgs__msg__ObjectPose__Sequence__are_equal(const sr_msgs__msg__ObjectPose__Sequence * lhs, const sr_msgs__msg__ObjectPose__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sr_msgs__msg__ObjectPose__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__ObjectPose__Sequence__copy(
  const sr_msgs__msg__ObjectPose__Sequence * input,
  sr_msgs__msg__ObjectPose__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sr_msgs__msg__ObjectPose);
    sr_msgs__msg__ObjectPose * data =
      (sr_msgs__msg__ObjectPose *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sr_msgs__msg__ObjectPose__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sr_msgs__msg__ObjectPose__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sr_msgs__msg__ObjectPose__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
