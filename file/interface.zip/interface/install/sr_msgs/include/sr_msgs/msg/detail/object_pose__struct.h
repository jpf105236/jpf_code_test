// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/ObjectPose.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__OBJECT_POSE__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__OBJECT_POSE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/ObjectPose in the package sr_msgs.
typedef struct sr_msgs__msg__ObjectPose
{
  float pos_x_m;
  float pos_y_m;
  float pos_z_m;
} sr_msgs__msg__ObjectPose;

// Struct for a sequence of sr_msgs__msg__ObjectPose.
typedef struct sr_msgs__msg__ObjectPose__Sequence
{
  sr_msgs__msg__ObjectPose * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__ObjectPose__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__OBJECT_POSE__STRUCT_H_
