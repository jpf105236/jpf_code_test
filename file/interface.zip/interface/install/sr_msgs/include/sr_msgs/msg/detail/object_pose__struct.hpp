// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/ObjectPose.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__OBJECT_POSE__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__OBJECT_POSE__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__ObjectPose __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__ObjectPose __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ObjectPose_
{
  using Type = ObjectPose_<ContainerAllocator>;

  explicit ObjectPose_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pos_x_m = 0.0f;
      this->pos_y_m = 0.0f;
      this->pos_z_m = 0.0f;
    }
  }

  explicit ObjectPose_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pos_x_m = 0.0f;
      this->pos_y_m = 0.0f;
      this->pos_z_m = 0.0f;
    }
  }

  // field types and members
  using _pos_x_m_type =
    float;
  _pos_x_m_type pos_x_m;
  using _pos_y_m_type =
    float;
  _pos_y_m_type pos_y_m;
  using _pos_z_m_type =
    float;
  _pos_z_m_type pos_z_m;

  // setters for named parameter idiom
  Type & set__pos_x_m(
    const float & _arg)
  {
    this->pos_x_m = _arg;
    return *this;
  }
  Type & set__pos_y_m(
    const float & _arg)
  {
    this->pos_y_m = _arg;
    return *this;
  }
  Type & set__pos_z_m(
    const float & _arg)
  {
    this->pos_z_m = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sr_msgs::msg::ObjectPose_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::ObjectPose_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::ObjectPose_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::ObjectPose_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::ObjectPose_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::ObjectPose_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::ObjectPose_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::ObjectPose_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::ObjectPose_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::ObjectPose_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__ObjectPose
    std::shared_ptr<sr_msgs::msg::ObjectPose_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__ObjectPose
    std::shared_ptr<sr_msgs::msg::ObjectPose_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ObjectPose_ & other) const
  {
    if (this->pos_x_m != other.pos_x_m) {
      return false;
    }
    if (this->pos_y_m != other.pos_y_m) {
      return false;
    }
    if (this->pos_z_m != other.pos_z_m) {
      return false;
    }
    return true;
  }
  bool operator!=(const ObjectPose_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ObjectPose_

// alias to use template instance with default allocator
using ObjectPose =
  sr_msgs::msg::ObjectPose_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__OBJECT_POSE__STRUCT_HPP_
