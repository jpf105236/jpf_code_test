// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sr_msgs:msg/ObjectPose.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__OBJECT_POSE__TRAITS_HPP_
#define SR_MSGS__MSG__DETAIL__OBJECT_POSE__TRAITS_HPP_

#include "sr_msgs/msg/detail/object_pose__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace nexidl_generator_traits
{

inline void to_yaml(
  const sr_msgs::msg::ObjectPose & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: pos_x_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pos_x_m: ";
    value_to_yaml(msg.pos_x_m, out);
    out << "\n";
  }

  // member: pos_y_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pos_y_m: ";
    value_to_yaml(msg.pos_y_m, out);
    out << "\n";
  }

  // member: pos_z_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pos_z_m: ";
    value_to_yaml(msg.pos_z_m, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const sr_msgs::msg::ObjectPose & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<sr_msgs::msg::ObjectPose>()
{
  return "sr_msgs::msg::ObjectPose";
}

template<>
inline const char * name<sr_msgs::msg::ObjectPose>()
{
  return "sr_msgs/msg/ObjectPose";
}

template<>
struct has_fixed_size<sr_msgs::msg::ObjectPose>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<sr_msgs::msg::ObjectPose>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<sr_msgs::msg::ObjectPose>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // SR_MSGS__MSG__DETAIL__OBJECT_POSE__TRAITS_HPP_
