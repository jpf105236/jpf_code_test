// generated from nexidl_generator_c/resource/idl__functions.c.em
// with input from sr_msgs:msg/PerceptionInfo.idl
// generated code does not contain a copyright notice
#include "sr_msgs/msg/detail/perception_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `dynamic_objects_list`
#include "sr_msgs/msg/detail/dynamic_object__functions.h"

bool
sr_msgs__msg__PerceptionInfo__init(sr_msgs__msg__PerceptionInfo * msg)
{
  if (!msg) {
    return false;
  }
  // dynamic_objects_size
  // dynamic_objects_list
  for (size_t i = 0; i < 50; ++i) {
    if (!sr_msgs__msg__DynamicObject__init(&msg->dynamic_objects_list[i])) {
      sr_msgs__msg__PerceptionInfo__fini(msg);
      return false;
    }
  }
  return true;
}

void
sr_msgs__msg__PerceptionInfo__fini(sr_msgs__msg__PerceptionInfo * msg)
{
  if (!msg) {
    return;
  }
  // dynamic_objects_size
  // dynamic_objects_list
  for (size_t i = 0; i < 50; ++i) {
    sr_msgs__msg__DynamicObject__fini(&msg->dynamic_objects_list[i]);
  }
}

bool
sr_msgs__msg__PerceptionInfo__are_equal(const sr_msgs__msg__PerceptionInfo * lhs, const sr_msgs__msg__PerceptionInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // dynamic_objects_size
  if (lhs->dynamic_objects_size != rhs->dynamic_objects_size) {
    return false;
  }
  // dynamic_objects_list
  for (size_t i = 0; i < 50; ++i) {
    if (!sr_msgs__msg__DynamicObject__are_equal(
        &(lhs->dynamic_objects_list[i]), &(rhs->dynamic_objects_list[i])))
    {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__PerceptionInfo__copy(
  const sr_msgs__msg__PerceptionInfo * input,
  sr_msgs__msg__PerceptionInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // dynamic_objects_size
  output->dynamic_objects_size = input->dynamic_objects_size;
  // dynamic_objects_list
  for (size_t i = 0; i < 50; ++i) {
    if (!sr_msgs__msg__DynamicObject__copy(
        &(input->dynamic_objects_list[i]), &(output->dynamic_objects_list[i])))
    {
      return false;
    }
  }
  return true;
}

sr_msgs__msg__PerceptionInfo *
sr_msgs__msg__PerceptionInfo__create()
{
  sr_msgs__msg__PerceptionInfo * msg = (sr_msgs__msg__PerceptionInfo *)malloc(sizeof(sr_msgs__msg__PerceptionInfo));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sr_msgs__msg__PerceptionInfo));
  bool success = sr_msgs__msg__PerceptionInfo__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
sr_msgs__msg__PerceptionInfo__destroy(sr_msgs__msg__PerceptionInfo * msg)
{
  if (msg) {
    sr_msgs__msg__PerceptionInfo__fini(msg);
  }
  free(msg);
}


bool
sr_msgs__msg__PerceptionInfo__Sequence__init(sr_msgs__msg__PerceptionInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  sr_msgs__msg__PerceptionInfo * data = NULL;
  if (size) {
    data = (sr_msgs__msg__PerceptionInfo *)calloc(size, sizeof(sr_msgs__msg__PerceptionInfo));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sr_msgs__msg__PerceptionInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sr_msgs__msg__PerceptionInfo__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sr_msgs__msg__PerceptionInfo__Sequence__fini(sr_msgs__msg__PerceptionInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sr_msgs__msg__PerceptionInfo__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sr_msgs__msg__PerceptionInfo__Sequence *
sr_msgs__msg__PerceptionInfo__Sequence__create(size_t size)
{
  sr_msgs__msg__PerceptionInfo__Sequence * array = (sr_msgs__msg__PerceptionInfo__Sequence *)malloc(sizeof(sr_msgs__msg__PerceptionInfo__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = sr_msgs__msg__PerceptionInfo__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
sr_msgs__msg__PerceptionInfo__Sequence__destroy(sr_msgs__msg__PerceptionInfo__Sequence * array)
{
  if (array) {
    sr_msgs__msg__PerceptionInfo__Sequence__fini(array);
  }
  free(array);
}

bool
sr_msgs__msg__PerceptionInfo__Sequence__are_equal(const sr_msgs__msg__PerceptionInfo__Sequence * lhs, const sr_msgs__msg__PerceptionInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sr_msgs__msg__PerceptionInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__PerceptionInfo__Sequence__copy(
  const sr_msgs__msg__PerceptionInfo__Sequence * input,
  sr_msgs__msg__PerceptionInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sr_msgs__msg__PerceptionInfo);
    sr_msgs__msg__PerceptionInfo * data =
      (sr_msgs__msg__PerceptionInfo *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sr_msgs__msg__PerceptionInfo__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sr_msgs__msg__PerceptionInfo__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sr_msgs__msg__PerceptionInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
