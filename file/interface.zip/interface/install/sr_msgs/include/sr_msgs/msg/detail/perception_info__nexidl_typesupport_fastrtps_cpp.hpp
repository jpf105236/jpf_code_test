// generated from nexidl_typesupport_fastrtps_cpp/resource/idl__nexidl_typesupport_fastrtps_cpp.hpp.em
// with input from sr_msgs:msg/PerceptionInfo.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__PERCEPTION_INFO__NEXIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
#define SR_MSGS__MSG__DETAIL__PERCEPTION_INFO__NEXIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_

#include "nexidl_runtime_c/message_type_support_struct.h"
#include "nexidl_typesupport_interface/macros.h"
#include "sr_msgs/msg/nexidl_typesupport_fastrtps_cpp__visibility_control.h"
#include "sr_msgs/msg/detail/perception_info__struct.hpp"

#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-parameter"
# ifdef __clang__
#  pragma clang diagnostic ignored "-Wdeprecated-register"
#  pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
# endif
#endif
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif

#include "fastcdr/Cdr.h"

namespace sr_msgs
{

namespace msg
{

namespace typesupport_fastrtps_cpp
{

bool
NEXIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_sr_msgs
cdr_serialize(
  const sr_msgs::msg::PerceptionInfo & nex_message,
  eprosima::fastcdr::Cdr & cdr);

bool
NEXIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_sr_msgs
cdr_deserialize(
  eprosima::fastcdr::Cdr & cdr,
  sr_msgs::msg::PerceptionInfo & nex_message);

size_t
NEXIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_sr_msgs
get_serialized_size(
  const sr_msgs::msg::PerceptionInfo & nex_message,
  size_t current_alignment);

size_t
NEXIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_sr_msgs
max_serialized_size_PerceptionInfo(
  bool & full_bounded,
  size_t current_alignment);

}  // namespace typesupport_fastrtps_cpp

}  // namespace msg

}  // namespace sr_msgs

#ifdef __cplusplus
extern "C"
{
#endif

NEXIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_sr_msgs
const nexidl_message_type_support_t *
  NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_fastrtps_cpp, sr_msgs, msg, PerceptionInfo)();

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__PERCEPTION_INFO__NEXIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
