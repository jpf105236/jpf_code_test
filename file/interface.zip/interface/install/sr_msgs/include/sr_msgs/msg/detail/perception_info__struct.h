// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/PerceptionInfo.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__PERCEPTION_INFO__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__PERCEPTION_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'dynamic_objects_list'
#include "sr_msgs/msg/detail/dynamic_object__struct.h"

// Struct defined in msg/PerceptionInfo in the package sr_msgs.
typedef struct sr_msgs__msg__PerceptionInfo
{
  int16_t dynamic_objects_size;
  sr_msgs__msg__DynamicObject dynamic_objects_list[50];
} sr_msgs__msg__PerceptionInfo;

// Struct for a sequence of sr_msgs__msg__PerceptionInfo.
typedef struct sr_msgs__msg__PerceptionInfo__Sequence
{
  sr_msgs__msg__PerceptionInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__PerceptionInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__PERCEPTION_INFO__STRUCT_H_
