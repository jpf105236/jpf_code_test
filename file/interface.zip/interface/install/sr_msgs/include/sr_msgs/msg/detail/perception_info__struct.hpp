// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/PerceptionInfo.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__PERCEPTION_INFO__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__PERCEPTION_INFO__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'dynamic_objects_list'
#include "sr_msgs/msg/detail/dynamic_object__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__PerceptionInfo __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__PerceptionInfo __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct PerceptionInfo_
{
  using Type = PerceptionInfo_<ContainerAllocator>;

  explicit PerceptionInfo_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->dynamic_objects_size = 0;
      this->dynamic_objects_list.fill(sr_msgs::msg::DynamicObject_<ContainerAllocator>{_init});
    }
  }

  explicit PerceptionInfo_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : dynamic_objects_list(_alloc)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->dynamic_objects_size = 0;
      this->dynamic_objects_list.fill(sr_msgs::msg::DynamicObject_<ContainerAllocator>{_alloc, _init});
    }
  }

  // field types and members
  using _dynamic_objects_size_type =
    int16_t;
  _dynamic_objects_size_type dynamic_objects_size;
  using _dynamic_objects_list_type =
    std::array<sr_msgs::msg::DynamicObject_<ContainerAllocator>, 50>;
  _dynamic_objects_list_type dynamic_objects_list;

  // setters for named parameter idiom
  Type & set__dynamic_objects_size(
    const int16_t & _arg)
  {
    this->dynamic_objects_size = _arg;
    return *this;
  }
  Type & set__dynamic_objects_list(
    const std::array<sr_msgs::msg::DynamicObject_<ContainerAllocator>, 50> & _arg)
  {
    this->dynamic_objects_list = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sr_msgs::msg::PerceptionInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::PerceptionInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::PerceptionInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::PerceptionInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::PerceptionInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::PerceptionInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::PerceptionInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::PerceptionInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::PerceptionInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::PerceptionInfo_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__PerceptionInfo
    std::shared_ptr<sr_msgs::msg::PerceptionInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__PerceptionInfo
    std::shared_ptr<sr_msgs::msg::PerceptionInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PerceptionInfo_ & other) const
  {
    if (this->dynamic_objects_size != other.dynamic_objects_size) {
      return false;
    }
    if (this->dynamic_objects_list != other.dynamic_objects_list) {
      return false;
    }
    return true;
  }
  bool operator!=(const PerceptionInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PerceptionInfo_

// alias to use template instance with default allocator
using PerceptionInfo =
  sr_msgs::msg::PerceptionInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__PERCEPTION_INFO__STRUCT_HPP_
