// generated from nexidl_generator_c/resource/idl__functions.c.em
// with input from sr_msgs:msg/RoadAttr.idl
// generated code does not contain a copyright notice
#include "sr_msgs/msg/detail/road_attr__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
sr_msgs__msg__RoadAttr__init(sr_msgs__msg__RoadAttr * msg)
{
  if (!msg) {
    return false;
  }
  // value
  return true;
}

void
sr_msgs__msg__RoadAttr__fini(sr_msgs__msg__RoadAttr * msg)
{
  if (!msg) {
    return;
  }
  // value
}

bool
sr_msgs__msg__RoadAttr__are_equal(const sr_msgs__msg__RoadAttr * lhs, const sr_msgs__msg__RoadAttr * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // value
  if (lhs->value != rhs->value) {
    return false;
  }
  return true;
}

bool
sr_msgs__msg__RoadAttr__copy(
  const sr_msgs__msg__RoadAttr * input,
  sr_msgs__msg__RoadAttr * output)
{
  if (!input || !output) {
    return false;
  }
  // value
  output->value = input->value;
  return true;
}

sr_msgs__msg__RoadAttr *
sr_msgs__msg__RoadAttr__create()
{
  sr_msgs__msg__RoadAttr * msg = (sr_msgs__msg__RoadAttr *)malloc(sizeof(sr_msgs__msg__RoadAttr));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sr_msgs__msg__RoadAttr));
  bool success = sr_msgs__msg__RoadAttr__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
sr_msgs__msg__RoadAttr__destroy(sr_msgs__msg__RoadAttr * msg)
{
  if (msg) {
    sr_msgs__msg__RoadAttr__fini(msg);
  }
  free(msg);
}


bool
sr_msgs__msg__RoadAttr__Sequence__init(sr_msgs__msg__RoadAttr__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  sr_msgs__msg__RoadAttr * data = NULL;
  if (size) {
    data = (sr_msgs__msg__RoadAttr *)calloc(size, sizeof(sr_msgs__msg__RoadAttr));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sr_msgs__msg__RoadAttr__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sr_msgs__msg__RoadAttr__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sr_msgs__msg__RoadAttr__Sequence__fini(sr_msgs__msg__RoadAttr__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sr_msgs__msg__RoadAttr__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sr_msgs__msg__RoadAttr__Sequence *
sr_msgs__msg__RoadAttr__Sequence__create(size_t size)
{
  sr_msgs__msg__RoadAttr__Sequence * array = (sr_msgs__msg__RoadAttr__Sequence *)malloc(sizeof(sr_msgs__msg__RoadAttr__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = sr_msgs__msg__RoadAttr__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
sr_msgs__msg__RoadAttr__Sequence__destroy(sr_msgs__msg__RoadAttr__Sequence * array)
{
  if (array) {
    sr_msgs__msg__RoadAttr__Sequence__fini(array);
  }
  free(array);
}

bool
sr_msgs__msg__RoadAttr__Sequence__are_equal(const sr_msgs__msg__RoadAttr__Sequence * lhs, const sr_msgs__msg__RoadAttr__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sr_msgs__msg__RoadAttr__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__RoadAttr__Sequence__copy(
  const sr_msgs__msg__RoadAttr__Sequence * input,
  sr_msgs__msg__RoadAttr__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sr_msgs__msg__RoadAttr);
    sr_msgs__msg__RoadAttr * data =
      (sr_msgs__msg__RoadAttr *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sr_msgs__msg__RoadAttr__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sr_msgs__msg__RoadAttr__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sr_msgs__msg__RoadAttr__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
