// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/RoadAttr.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__ROAD_ATTR__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__ROAD_ATTR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'ROAD_ATTR_TUNNEL'.
enum
{
  sr_msgs__msg__RoadAttr__ROAD_ATTR_TUNNEL = 1
};

/// Constant 'ROAD_ATTR_U_TURN'.
enum
{
  sr_msgs__msg__RoadAttr__ROAD_ATTR_U_TURN = 2
};

/// Constant 'ROAD_ATTR_ROADABOUT'.
enum
{
  sr_msgs__msg__RoadAttr__ROAD_ATTR_ROADABOUT = 3
};

/// Constant 'ROAD_ATTR_END'.
enum
{
  sr_msgs__msg__RoadAttr__ROAD_ATTR_END = 4
};

// Struct defined in msg/RoadAttr in the package sr_msgs.
typedef struct sr_msgs__msg__RoadAttr
{
  uint8_t value;
} sr_msgs__msg__RoadAttr;

// Struct for a sequence of sr_msgs__msg__RoadAttr.
typedef struct sr_msgs__msg__RoadAttr__Sequence
{
  sr_msgs__msg__RoadAttr * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__RoadAttr__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__ROAD_ATTR__STRUCT_H_
