// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sr_msgs:msg/RoadAttribute.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__BUILDER_HPP_
#define SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__BUILDER_HPP_

#include "sr_msgs/msg/detail/road_attribute__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sr_msgs
{

namespace msg
{

namespace builder
{

class Init_RoadAttribute_road_attr_list
{
public:
  explicit Init_RoadAttribute_road_attr_list(::sr_msgs::msg::RoadAttribute & msg)
  : msg_(msg)
  {}
  ::sr_msgs::msg::RoadAttribute road_attr_list(::sr_msgs::msg::RoadAttribute::_road_attr_list_type arg)
  {
    msg_.road_attr_list = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sr_msgs::msg::RoadAttribute msg_;
};

class Init_RoadAttribute_attribute_size
{
public:
  Init_RoadAttribute_attribute_size()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RoadAttribute_road_attr_list attribute_size(::sr_msgs::msg::RoadAttribute::_attribute_size_type arg)
  {
    msg_.attribute_size = std::move(arg);
    return Init_RoadAttribute_road_attr_list(msg_);
  }

private:
  ::sr_msgs::msg::RoadAttribute msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sr_msgs::msg::RoadAttribute>()
{
  return sr_msgs::msg::builder::Init_RoadAttribute_attribute_size();
}

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__BUILDER_HPP_
