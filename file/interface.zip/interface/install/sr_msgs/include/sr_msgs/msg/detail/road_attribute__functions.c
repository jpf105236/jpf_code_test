// generated from nexidl_generator_c/resource/idl__functions.c.em
// with input from sr_msgs:msg/RoadAttribute.idl
// generated code does not contain a copyright notice
#include "sr_msgs/msg/detail/road_attribute__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `road_attr_list`
#include "sr_msgs/msg/detail/road_attr__functions.h"

bool
sr_msgs__msg__RoadAttribute__init(sr_msgs__msg__RoadAttribute * msg)
{
  if (!msg) {
    return false;
  }
  // attribute_size
  // road_attr_list
  for (size_t i = 0; i < 5; ++i) {
    if (!sr_msgs__msg__RoadAttr__init(&msg->road_attr_list[i])) {
      sr_msgs__msg__RoadAttribute__fini(msg);
      return false;
    }
  }
  return true;
}

void
sr_msgs__msg__RoadAttribute__fini(sr_msgs__msg__RoadAttribute * msg)
{
  if (!msg) {
    return;
  }
  // attribute_size
  // road_attr_list
  for (size_t i = 0; i < 5; ++i) {
    sr_msgs__msg__RoadAttr__fini(&msg->road_attr_list[i]);
  }
}

bool
sr_msgs__msg__RoadAttribute__are_equal(const sr_msgs__msg__RoadAttribute * lhs, const sr_msgs__msg__RoadAttribute * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // attribute_size
  if (lhs->attribute_size != rhs->attribute_size) {
    return false;
  }
  // road_attr_list
  for (size_t i = 0; i < 5; ++i) {
    if (!sr_msgs__msg__RoadAttr__are_equal(
        &(lhs->road_attr_list[i]), &(rhs->road_attr_list[i])))
    {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__RoadAttribute__copy(
  const sr_msgs__msg__RoadAttribute * input,
  sr_msgs__msg__RoadAttribute * output)
{
  if (!input || !output) {
    return false;
  }
  // attribute_size
  output->attribute_size = input->attribute_size;
  // road_attr_list
  for (size_t i = 0; i < 5; ++i) {
    if (!sr_msgs__msg__RoadAttr__copy(
        &(input->road_attr_list[i]), &(output->road_attr_list[i])))
    {
      return false;
    }
  }
  return true;
}

sr_msgs__msg__RoadAttribute *
sr_msgs__msg__RoadAttribute__create()
{
  sr_msgs__msg__RoadAttribute * msg = (sr_msgs__msg__RoadAttribute *)malloc(sizeof(sr_msgs__msg__RoadAttribute));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sr_msgs__msg__RoadAttribute));
  bool success = sr_msgs__msg__RoadAttribute__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
sr_msgs__msg__RoadAttribute__destroy(sr_msgs__msg__RoadAttribute * msg)
{
  if (msg) {
    sr_msgs__msg__RoadAttribute__fini(msg);
  }
  free(msg);
}


bool
sr_msgs__msg__RoadAttribute__Sequence__init(sr_msgs__msg__RoadAttribute__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  sr_msgs__msg__RoadAttribute * data = NULL;
  if (size) {
    data = (sr_msgs__msg__RoadAttribute *)calloc(size, sizeof(sr_msgs__msg__RoadAttribute));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sr_msgs__msg__RoadAttribute__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sr_msgs__msg__RoadAttribute__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sr_msgs__msg__RoadAttribute__Sequence__fini(sr_msgs__msg__RoadAttribute__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sr_msgs__msg__RoadAttribute__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sr_msgs__msg__RoadAttribute__Sequence *
sr_msgs__msg__RoadAttribute__Sequence__create(size_t size)
{
  sr_msgs__msg__RoadAttribute__Sequence * array = (sr_msgs__msg__RoadAttribute__Sequence *)malloc(sizeof(sr_msgs__msg__RoadAttribute__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = sr_msgs__msg__RoadAttribute__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
sr_msgs__msg__RoadAttribute__Sequence__destroy(sr_msgs__msg__RoadAttribute__Sequence * array)
{
  if (array) {
    sr_msgs__msg__RoadAttribute__Sequence__fini(array);
  }
  free(array);
}

bool
sr_msgs__msg__RoadAttribute__Sequence__are_equal(const sr_msgs__msg__RoadAttribute__Sequence * lhs, const sr_msgs__msg__RoadAttribute__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sr_msgs__msg__RoadAttribute__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__RoadAttribute__Sequence__copy(
  const sr_msgs__msg__RoadAttribute__Sequence * input,
  sr_msgs__msg__RoadAttribute__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sr_msgs__msg__RoadAttribute);
    sr_msgs__msg__RoadAttribute * data =
      (sr_msgs__msg__RoadAttribute *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sr_msgs__msg__RoadAttribute__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sr_msgs__msg__RoadAttribute__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sr_msgs__msg__RoadAttribute__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
