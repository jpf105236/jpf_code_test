// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/RoadAttribute.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'road_attr_list'
#include "sr_msgs/msg/detail/road_attr__struct.h"

// Struct defined in msg/RoadAttribute in the package sr_msgs.
typedef struct sr_msgs__msg__RoadAttribute
{
  int16_t attribute_size;
  sr_msgs__msg__RoadAttr road_attr_list[5];
} sr_msgs__msg__RoadAttribute;

// Struct for a sequence of sr_msgs__msg__RoadAttribute.
typedef struct sr_msgs__msg__RoadAttribute__Sequence
{
  sr_msgs__msg__RoadAttribute * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__RoadAttribute__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__STRUCT_H_
