// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/RoadAttribute.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'road_attr_list'
#include "sr_msgs/msg/detail/road_attr__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__RoadAttribute __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__RoadAttribute __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct RoadAttribute_
{
  using Type = RoadAttribute_<ContainerAllocator>;

  explicit RoadAttribute_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->attribute_size = 0;
      this->road_attr_list.fill(sr_msgs::msg::RoadAttr_<ContainerAllocator>{_init});
    }
  }

  explicit RoadAttribute_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : road_attr_list(_alloc)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->attribute_size = 0;
      this->road_attr_list.fill(sr_msgs::msg::RoadAttr_<ContainerAllocator>{_alloc, _init});
    }
  }

  // field types and members
  using _attribute_size_type =
    int16_t;
  _attribute_size_type attribute_size;
  using _road_attr_list_type =
    std::array<sr_msgs::msg::RoadAttr_<ContainerAllocator>, 5>;
  _road_attr_list_type road_attr_list;

  // setters for named parameter idiom
  Type & set__attribute_size(
    const int16_t & _arg)
  {
    this->attribute_size = _arg;
    return *this;
  }
  Type & set__road_attr_list(
    const std::array<sr_msgs::msg::RoadAttr_<ContainerAllocator>, 5> & _arg)
  {
    this->road_attr_list = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sr_msgs::msg::RoadAttribute_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::RoadAttribute_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::RoadAttribute_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::RoadAttribute_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::RoadAttribute_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::RoadAttribute_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::RoadAttribute_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::RoadAttribute_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::RoadAttribute_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::RoadAttribute_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__RoadAttribute
    std::shared_ptr<sr_msgs::msg::RoadAttribute_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__RoadAttribute
    std::shared_ptr<sr_msgs::msg::RoadAttribute_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RoadAttribute_ & other) const
  {
    if (this->attribute_size != other.attribute_size) {
      return false;
    }
    if (this->road_attr_list != other.road_attr_list) {
      return false;
    }
    return true;
  }
  bool operator!=(const RoadAttribute_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RoadAttribute_

// alias to use template instance with default allocator
using RoadAttribute =
  sr_msgs::msg::RoadAttribute_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__STRUCT_HPP_
