// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sr_msgs:msg/RoadAttribute.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__TRAITS_HPP_
#define SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__TRAITS_HPP_

#include "sr_msgs/msg/detail/road_attribute__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'road_attr_list'
#include "sr_msgs/msg/detail/road_attr__traits.hpp"

namespace nexidl_generator_traits
{

inline void to_yaml(
  const sr_msgs::msg::RoadAttribute & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: attribute_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "attribute_size: ";
    value_to_yaml(msg.attribute_size, out);
    out << "\n";
  }

  // member: road_attr_list
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.road_attr_list.size() == 0) {
      out << "road_attr_list: []\n";
    } else {
      out << "road_attr_list:\n";
      for (auto item : msg.road_attr_list) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const sr_msgs::msg::RoadAttribute & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<sr_msgs::msg::RoadAttribute>()
{
  return "sr_msgs::msg::RoadAttribute";
}

template<>
inline const char * name<sr_msgs::msg::RoadAttribute>()
{
  return "sr_msgs/msg/RoadAttribute";
}

template<>
struct has_fixed_size<sr_msgs::msg::RoadAttribute>
  : std::integral_constant<bool, has_fixed_size<sr_msgs::msg::RoadAttr>::value> {};

template<>
struct has_bounded_size<sr_msgs::msg::RoadAttribute>
  : std::integral_constant<bool, has_bounded_size<sr_msgs::msg::RoadAttr>::value> {};

template<>
struct is_message<sr_msgs::msg::RoadAttribute>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // SR_MSGS__MSG__DETAIL__ROAD_ATTRIBUTE__TRAITS_HPP_
