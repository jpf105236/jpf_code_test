// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sr_msgs:msg/RoadMarkers.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__ROAD_MARKERS__BUILDER_HPP_
#define SR_MSGS__MSG__DETAIL__ROAD_MARKERS__BUILDER_HPP_

#include "sr_msgs/msg/detail/road_markers__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sr_msgs
{

namespace msg
{

namespace builder
{

class Init_RoadMarkers_lanes_list
{
public:
  explicit Init_RoadMarkers_lanes_list(::sr_msgs::msg::RoadMarkers & msg)
  : msg_(msg)
  {}
  ::sr_msgs::msg::RoadMarkers lanes_list(::sr_msgs::msg::RoadMarkers::_lanes_list_type arg)
  {
    msg_.lanes_list = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sr_msgs::msg::RoadMarkers msg_;
};

class Init_RoadMarkers_lanes_size
{
public:
  Init_RoadMarkers_lanes_size()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RoadMarkers_lanes_list lanes_size(::sr_msgs::msg::RoadMarkers::_lanes_size_type arg)
  {
    msg_.lanes_size = std::move(arg);
    return Init_RoadMarkers_lanes_list(msg_);
  }

private:
  ::sr_msgs::msg::RoadMarkers msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sr_msgs::msg::RoadMarkers>()
{
  return sr_msgs::msg::builder::Init_RoadMarkers_lanes_size();
}

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__ROAD_MARKERS__BUILDER_HPP_
