// generated from nexidl_generator_c/resource/idl__functions.c.em
// with input from sr_msgs:msg/RoadMarkers.idl
// generated code does not contain a copyright notice
#include "sr_msgs/msg/detail/road_markers__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `lanes_list`
#include "sr_msgs/msg/detail/lane__functions.h"

bool
sr_msgs__msg__RoadMarkers__init(sr_msgs__msg__RoadMarkers * msg)
{
  if (!msg) {
    return false;
  }
  // lanes_size
  // lanes_list
  for (size_t i = 0; i < 15; ++i) {
    if (!sr_msgs__msg__Lane__init(&msg->lanes_list[i])) {
      sr_msgs__msg__RoadMarkers__fini(msg);
      return false;
    }
  }
  return true;
}

void
sr_msgs__msg__RoadMarkers__fini(sr_msgs__msg__RoadMarkers * msg)
{
  if (!msg) {
    return;
  }
  // lanes_size
  // lanes_list
  for (size_t i = 0; i < 15; ++i) {
    sr_msgs__msg__Lane__fini(&msg->lanes_list[i]);
  }
}

bool
sr_msgs__msg__RoadMarkers__are_equal(const sr_msgs__msg__RoadMarkers * lhs, const sr_msgs__msg__RoadMarkers * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // lanes_size
  if (lhs->lanes_size != rhs->lanes_size) {
    return false;
  }
  // lanes_list
  for (size_t i = 0; i < 15; ++i) {
    if (!sr_msgs__msg__Lane__are_equal(
        &(lhs->lanes_list[i]), &(rhs->lanes_list[i])))
    {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__RoadMarkers__copy(
  const sr_msgs__msg__RoadMarkers * input,
  sr_msgs__msg__RoadMarkers * output)
{
  if (!input || !output) {
    return false;
  }
  // lanes_size
  output->lanes_size = input->lanes_size;
  // lanes_list
  for (size_t i = 0; i < 15; ++i) {
    if (!sr_msgs__msg__Lane__copy(
        &(input->lanes_list[i]), &(output->lanes_list[i])))
    {
      return false;
    }
  }
  return true;
}

sr_msgs__msg__RoadMarkers *
sr_msgs__msg__RoadMarkers__create()
{
  sr_msgs__msg__RoadMarkers * msg = (sr_msgs__msg__RoadMarkers *)malloc(sizeof(sr_msgs__msg__RoadMarkers));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sr_msgs__msg__RoadMarkers));
  bool success = sr_msgs__msg__RoadMarkers__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
sr_msgs__msg__RoadMarkers__destroy(sr_msgs__msg__RoadMarkers * msg)
{
  if (msg) {
    sr_msgs__msg__RoadMarkers__fini(msg);
  }
  free(msg);
}


bool
sr_msgs__msg__RoadMarkers__Sequence__init(sr_msgs__msg__RoadMarkers__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  sr_msgs__msg__RoadMarkers * data = NULL;
  if (size) {
    data = (sr_msgs__msg__RoadMarkers *)calloc(size, sizeof(sr_msgs__msg__RoadMarkers));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sr_msgs__msg__RoadMarkers__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sr_msgs__msg__RoadMarkers__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sr_msgs__msg__RoadMarkers__Sequence__fini(sr_msgs__msg__RoadMarkers__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sr_msgs__msg__RoadMarkers__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sr_msgs__msg__RoadMarkers__Sequence *
sr_msgs__msg__RoadMarkers__Sequence__create(size_t size)
{
  sr_msgs__msg__RoadMarkers__Sequence * array = (sr_msgs__msg__RoadMarkers__Sequence *)malloc(sizeof(sr_msgs__msg__RoadMarkers__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = sr_msgs__msg__RoadMarkers__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
sr_msgs__msg__RoadMarkers__Sequence__destroy(sr_msgs__msg__RoadMarkers__Sequence * array)
{
  if (array) {
    sr_msgs__msg__RoadMarkers__Sequence__fini(array);
  }
  free(array);
}

bool
sr_msgs__msg__RoadMarkers__Sequence__are_equal(const sr_msgs__msg__RoadMarkers__Sequence * lhs, const sr_msgs__msg__RoadMarkers__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sr_msgs__msg__RoadMarkers__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sr_msgs__msg__RoadMarkers__Sequence__copy(
  const sr_msgs__msg__RoadMarkers__Sequence * input,
  sr_msgs__msg__RoadMarkers__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sr_msgs__msg__RoadMarkers);
    sr_msgs__msg__RoadMarkers * data =
      (sr_msgs__msg__RoadMarkers *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sr_msgs__msg__RoadMarkers__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sr_msgs__msg__RoadMarkers__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sr_msgs__msg__RoadMarkers__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
