// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/RoadMarkers.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__ROAD_MARKERS__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__ROAD_MARKERS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'lanes_list'
#include "sr_msgs/msg/detail/lane__struct.h"

// Struct defined in msg/RoadMarkers in the package sr_msgs.
typedef struct sr_msgs__msg__RoadMarkers
{
  int16_t lanes_size;
  sr_msgs__msg__Lane lanes_list[15];
} sr_msgs__msg__RoadMarkers;

// Struct for a sequence of sr_msgs__msg__RoadMarkers.
typedef struct sr_msgs__msg__RoadMarkers__Sequence
{
  sr_msgs__msg__RoadMarkers * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__RoadMarkers__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__ROAD_MARKERS__STRUCT_H_
