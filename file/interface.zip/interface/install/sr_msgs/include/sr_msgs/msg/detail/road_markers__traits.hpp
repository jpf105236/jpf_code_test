// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sr_msgs:msg/RoadMarkers.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__ROAD_MARKERS__TRAITS_HPP_
#define SR_MSGS__MSG__DETAIL__ROAD_MARKERS__TRAITS_HPP_

#include "sr_msgs/msg/detail/road_markers__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'lanes_list'
#include "sr_msgs/msg/detail/lane__traits.hpp"

namespace nexidl_generator_traits
{

inline void to_yaml(
  const sr_msgs::msg::RoadMarkers & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: lanes_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lanes_size: ";
    value_to_yaml(msg.lanes_size, out);
    out << "\n";
  }

  // member: lanes_list
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.lanes_list.size() == 0) {
      out << "lanes_list: []\n";
    } else {
      out << "lanes_list:\n";
      for (auto item : msg.lanes_list) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const sr_msgs::msg::RoadMarkers & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<sr_msgs::msg::RoadMarkers>()
{
  return "sr_msgs::msg::RoadMarkers";
}

template<>
inline const char * name<sr_msgs::msg::RoadMarkers>()
{
  return "sr_msgs/msg/RoadMarkers";
}

template<>
struct has_fixed_size<sr_msgs::msg::RoadMarkers>
  : std::integral_constant<bool, has_fixed_size<sr_msgs::msg::Lane>::value> {};

template<>
struct has_bounded_size<sr_msgs::msg::RoadMarkers>
  : std::integral_constant<bool, has_bounded_size<sr_msgs::msg::Lane>::value> {};

template<>
struct is_message<sr_msgs::msg::RoadMarkers>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // SR_MSGS__MSG__DETAIL__ROAD_MARKERS__TRAITS_HPP_
