// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sr_msgs:msg/TrafficLight.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT__BUILDER_HPP_
#define SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT__BUILDER_HPP_

#include "sr_msgs/msg/detail/traffic_light__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sr_msgs
{

namespace msg
{

namespace builder
{

class Init_TrafficLight_counter
{
public:
  explicit Init_TrafficLight_counter(::sr_msgs::msg::TrafficLight & msg)
  : msg_(msg)
  {}
  ::sr_msgs::msg::TrafficLight counter(::sr_msgs::msg::TrafficLight::_counter_type arg)
  {
    msg_.counter = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sr_msgs::msg::TrafficLight msg_;
};

class Init_TrafficLight_state_enum
{
public:
  Init_TrafficLight_state_enum()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TrafficLight_counter state_enum(::sr_msgs::msg::TrafficLight::_state_enum_type arg)
  {
    msg_.state_enum = std::move(arg);
    return Init_TrafficLight_counter(msg_);
  }

private:
  ::sr_msgs::msg::TrafficLight msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sr_msgs::msg::TrafficLight>()
{
  return sr_msgs::msg::builder::Init_TrafficLight_state_enum();
}

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT__BUILDER_HPP_
