// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/TrafficLight.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'state_enum'
#include "sr_msgs/msg/detail/traffic_light_state__struct.h"

// Struct defined in msg/TrafficLight in the package sr_msgs.
typedef struct sr_msgs__msg__TrafficLight
{
  sr_msgs__msg__TrafficLightState state_enum;
  int16_t counter;
} sr_msgs__msg__TrafficLight;

// Struct for a sequence of sr_msgs__msg__TrafficLight.
typedef struct sr_msgs__msg__TrafficLight__Sequence
{
  sr_msgs__msg__TrafficLight * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__TrafficLight__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT__STRUCT_H_
