// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/TrafficLightState.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT_STATE__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'TRAFFIC_LIGHT_TL_NO'.
enum
{
  sr_msgs__msg__TrafficLightState__TRAFFIC_LIGHT_TL_NO = 0
};

/// Constant 'TRAFFIC_LIGHT_TL_R'.
enum
{
  sr_msgs__msg__TrafficLightState__TRAFFIC_LIGHT_TL_R = 1
};

/// Constant 'TRAFFIC_LIGHT_TL_G'.
enum
{
  sr_msgs__msg__TrafficLightState__TRAFFIC_LIGHT_TL_G = 2
};

/// Constant 'TRAFFIC_LIGHT_TL_Y'.
enum
{
  sr_msgs__msg__TrafficLightState__TRAFFIC_LIGHT_TL_Y = 3
};

// Struct defined in msg/TrafficLightState in the package sr_msgs.
typedef struct sr_msgs__msg__TrafficLightState
{
  uint8_t value;
} sr_msgs__msg__TrafficLightState;

// Struct for a sequence of sr_msgs__msg__TrafficLightState.
typedef struct sr_msgs__msg__TrafficLightState__Sequence
{
  sr_msgs__msg__TrafficLightState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__TrafficLightState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT_STATE__STRUCT_H_
