// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/TrafficLightState.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT_STATE__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT_STATE__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__TrafficLightState __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__TrafficLightState __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct TrafficLightState_
{
  using Type = TrafficLightState_<ContainerAllocator>;

  explicit TrafficLightState_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->value = 0;
    }
  }

  explicit TrafficLightState_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->value = 0;
    }
  }

  // field types and members
  using _value_type =
    uint8_t;
  _value_type value;

  // setters for named parameter idiom
  Type & set__value(
    const uint8_t & _arg)
  {
    this->value = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t TRAFFIC_LIGHT_TL_NO =
    0u;
  static constexpr uint8_t TRAFFIC_LIGHT_TL_R =
    1u;
  static constexpr uint8_t TRAFFIC_LIGHT_TL_G =
    2u;
  static constexpr uint8_t TRAFFIC_LIGHT_TL_Y =
    3u;

  // pointer types
  using RawPtr =
    sr_msgs::msg::TrafficLightState_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::TrafficLightState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::TrafficLightState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::TrafficLightState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::TrafficLightState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::TrafficLightState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::TrafficLightState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::TrafficLightState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::TrafficLightState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::TrafficLightState_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__TrafficLightState
    std::shared_ptr<sr_msgs::msg::TrafficLightState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__TrafficLightState
    std::shared_ptr<sr_msgs::msg::TrafficLightState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const TrafficLightState_ & other) const
  {
    if (this->value != other.value) {
      return false;
    }
    return true;
  }
  bool operator!=(const TrafficLightState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct TrafficLightState_

// alias to use template instance with default allocator
using TrafficLightState =
  sr_msgs::msg::TrafficLightState_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
constexpr uint8_t TrafficLightState_<ContainerAllocator>::TRAFFIC_LIGHT_TL_NO;
template<typename ContainerAllocator>
constexpr uint8_t TrafficLightState_<ContainerAllocator>::TRAFFIC_LIGHT_TL_R;
template<typename ContainerAllocator>
constexpr uint8_t TrafficLightState_<ContainerAllocator>::TRAFFIC_LIGHT_TL_G;
template<typename ContainerAllocator>
constexpr uint8_t TrafficLightState_<ContainerAllocator>::TRAFFIC_LIGHT_TL_Y;

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__TRAFFIC_LIGHT_STATE__STRUCT_HPP_
