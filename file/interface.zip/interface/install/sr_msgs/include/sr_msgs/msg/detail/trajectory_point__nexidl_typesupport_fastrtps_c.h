// generated from nexidl_typesupport_fastrtps_c/resource/idl__nexidl_typesupport_fastrtps_c.h.em
// with input from sr_msgs:msg/TrajectoryPoint.idl
// generated code does not contain a copyright notice
#ifndef SR_MSGS__MSG__DETAIL__TRAJECTORY_POINT__NEXIDL_TYPESUPPORT_FASTRTPS_C_H_
#define SR_MSGS__MSG__DETAIL__TRAJECTORY_POINT__NEXIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "nexidl_runtime_c/message_type_support_struct.h"
#include "nexidl_typesupport_interface/macros.h"
#include "sr_msgs/msg/nexidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

NEXIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sr_msgs
size_t get_serialized_size_sr_msgs__msg__TrajectoryPoint(
  const void * untyped_nex_message,
  size_t current_alignment);

NEXIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sr_msgs
size_t max_serialized_size_sr_msgs__msg__TrajectoryPoint(
  bool & full_bounded,
  size_t current_alignment);

NEXIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sr_msgs
const nexidl_message_type_support_t *
NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_fastrtps_c, sr_msgs, msg, TrajectoryPoint)();

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__TRAJECTORY_POINT__NEXIDL_TYPESUPPORT_FASTRTPS_C_H_
