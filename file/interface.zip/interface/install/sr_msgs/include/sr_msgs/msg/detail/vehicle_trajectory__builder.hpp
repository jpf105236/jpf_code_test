// generated from nexidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sr_msgs:msg/VehicleTrajectory.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__VEHICLE_TRAJECTORY__BUILDER_HPP_
#define SR_MSGS__MSG__DETAIL__VEHICLE_TRAJECTORY__BUILDER_HPP_

#include "sr_msgs/msg/detail/vehicle_trajectory__struct.hpp"
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sr_msgs
{

namespace msg
{

namespace builder
{

class Init_VehicleTrajectory_pts_list
{
public:
  explicit Init_VehicleTrajectory_pts_list(::sr_msgs::msg::VehicleTrajectory & msg)
  : msg_(msg)
  {}
  ::sr_msgs::msg::VehicleTrajectory pts_list(::sr_msgs::msg::VehicleTrajectory::_pts_list_type arg)
  {
    msg_.pts_list = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sr_msgs::msg::VehicleTrajectory msg_;
};

class Init_VehicleTrajectory_pts_size
{
public:
  explicit Init_VehicleTrajectory_pts_size(::sr_msgs::msg::VehicleTrajectory & msg)
  : msg_(msg)
  {}
  Init_VehicleTrajectory_pts_list pts_size(::sr_msgs::msg::VehicleTrajectory::_pts_size_type arg)
  {
    msg_.pts_size = std::move(arg);
    return Init_VehicleTrajectory_pts_list(msg_);
  }

private:
  ::sr_msgs::msg::VehicleTrajectory msg_;
};

class Init_VehicleTrajectory_navigation_mode_enum
{
public:
  Init_VehicleTrajectory_navigation_mode_enum()
  : msg_(::nexidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VehicleTrajectory_pts_size navigation_mode_enum(::sr_msgs::msg::VehicleTrajectory::_navigation_mode_enum_type arg)
  {
    msg_.navigation_mode_enum = std::move(arg);
    return Init_VehicleTrajectory_pts_size(msg_);
  }

private:
  ::sr_msgs::msg::VehicleTrajectory msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sr_msgs::msg::VehicleTrajectory>()
{
  return sr_msgs::msg::builder::Init_VehicleTrajectory_navigation_mode_enum();
}

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__VEHICLE_TRAJECTORY__BUILDER_HPP_
