// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/VehicleTrajectory.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__VEHICLE_TRAJECTORY__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__VEHICLE_TRAJECTORY__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'navigation_mode_enum'
#include "sr_msgs/msg/detail/navigation_status__struct.hpp"
// Member 'pts_list'
#include "sr_msgs/msg/detail/trajectory_point__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__VehicleTrajectory __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__VehicleTrajectory __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct VehicleTrajectory_
{
  using Type = VehicleTrajectory_<ContainerAllocator>;

  explicit VehicleTrajectory_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : navigation_mode_enum(_init)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pts_size = 0;
      this->pts_list.fill(sr_msgs::msg::TrajectoryPoint_<ContainerAllocator>{_init});
    }
  }

  explicit VehicleTrajectory_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  : navigation_mode_enum(_alloc, _init),
    pts_list(_alloc)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pts_size = 0;
      this->pts_list.fill(sr_msgs::msg::TrajectoryPoint_<ContainerAllocator>{_alloc, _init});
    }
  }

  // field types and members
  using _navigation_mode_enum_type =
    sr_msgs::msg::NavigationStatus_<ContainerAllocator>;
  _navigation_mode_enum_type navigation_mode_enum;
  using _pts_size_type =
    int16_t;
  _pts_size_type pts_size;
  using _pts_list_type =
    std::array<sr_msgs::msg::TrajectoryPoint_<ContainerAllocator>, 100>;
  _pts_list_type pts_list;

  // setters for named parameter idiom
  Type & set__navigation_mode_enum(
    const sr_msgs::msg::NavigationStatus_<ContainerAllocator> & _arg)
  {
    this->navigation_mode_enum = _arg;
    return *this;
  }
  Type & set__pts_size(
    const int16_t & _arg)
  {
    this->pts_size = _arg;
    return *this;
  }
  Type & set__pts_list(
    const std::array<sr_msgs::msg::TrajectoryPoint_<ContainerAllocator>, 100> & _arg)
  {
    this->pts_list = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sr_msgs::msg::VehicleTrajectory_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::VehicleTrajectory_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::VehicleTrajectory_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::VehicleTrajectory_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::VehicleTrajectory_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::VehicleTrajectory_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::VehicleTrajectory_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::VehicleTrajectory_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::VehicleTrajectory_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::VehicleTrajectory_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__VehicleTrajectory
    std::shared_ptr<sr_msgs::msg::VehicleTrajectory_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__VehicleTrajectory
    std::shared_ptr<sr_msgs::msg::VehicleTrajectory_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VehicleTrajectory_ & other) const
  {
    if (this->navigation_mode_enum != other.navigation_mode_enum) {
      return false;
    }
    if (this->pts_size != other.pts_size) {
      return false;
    }
    if (this->pts_list != other.pts_list) {
      return false;
    }
    return true;
  }
  bool operator!=(const VehicleTrajectory_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VehicleTrajectory_

// alias to use template instance with default allocator
using VehicleTrajectory =
  sr_msgs::msg::VehicleTrajectory_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__VEHICLE_TRAJECTORY__STRUCT_HPP_
