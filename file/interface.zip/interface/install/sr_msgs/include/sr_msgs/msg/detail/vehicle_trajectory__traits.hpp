// generated from nexidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sr_msgs:msg/VehicleTrajectory.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__VEHICLE_TRAJECTORY__TRAITS_HPP_
#define SR_MSGS__MSG__DETAIL__VEHICLE_TRAJECTORY__TRAITS_HPP_

#include "sr_msgs/msg/detail/vehicle_trajectory__struct.hpp"
#include <stdint.h>
#include <nexidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'navigation_mode_enum'
#include "sr_msgs/msg/detail/navigation_status__traits.hpp"
// Member 'pts_list'
#include "sr_msgs/msg/detail/trajectory_point__traits.hpp"

namespace nexidl_generator_traits
{

inline void to_yaml(
  const sr_msgs::msg::VehicleTrajectory & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: navigation_mode_enum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "navigation_mode_enum:\n";
    to_yaml(msg.navigation_mode_enum, out, indentation + 2);
  }

  // member: pts_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pts_size: ";
    value_to_yaml(msg.pts_size, out);
    out << "\n";
  }

  // member: pts_list
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.pts_list.size() == 0) {
      out << "pts_list: []\n";
    } else {
      out << "pts_list:\n";
      for (auto item : msg.pts_list) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const sr_msgs::msg::VehicleTrajectory & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<sr_msgs::msg::VehicleTrajectory>()
{
  return "sr_msgs::msg::VehicleTrajectory";
}

template<>
inline const char * name<sr_msgs::msg::VehicleTrajectory>()
{
  return "sr_msgs/msg/VehicleTrajectory";
}

template<>
struct has_fixed_size<sr_msgs::msg::VehicleTrajectory>
  : std::integral_constant<bool, has_fixed_size<sr_msgs::msg::NavigationStatus>::value && has_fixed_size<sr_msgs::msg::TrajectoryPoint>::value> {};

template<>
struct has_bounded_size<sr_msgs::msg::VehicleTrajectory>
  : std::integral_constant<bool, has_bounded_size<sr_msgs::msg::NavigationStatus>::value && has_bounded_size<sr_msgs::msg::TrajectoryPoint>::value> {};

template<>
struct is_message<sr_msgs::msg::VehicleTrajectory>
  : std::true_type {};

}  // namespace nexidl_generator_traits

#endif  // SR_MSGS__MSG__DETAIL__VEHICLE_TRAJECTORY__TRAITS_HPP_
