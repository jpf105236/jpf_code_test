// generated from nexidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from sr_msgs:msg/VehicleTrajectory.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "sr_msgs/msg/detail/vehicle_trajectory__nexidl_typesupport_introspection_c.h"
#include "sr_msgs/msg/nexidl_typesupport_introspection_c__visibility_control.h"
#include "nexidl_typesupport_introspection_c/field_types.h"
#include "nexidl_typesupport_introspection_c/identifier.h"
#include "nexidl_typesupport_introspection_c/message_introspection.h"
#include "sr_msgs/msg/detail/vehicle_trajectory__functions.h"
#include "sr_msgs/msg/detail/vehicle_trajectory__struct.h"


// Include directives for member types
// Member `navigation_mode_enum`
#include "sr_msgs/msg/navigation_status.h"
// Member `navigation_mode_enum`
#include "sr_msgs/msg/detail/navigation_status__nexidl_typesupport_introspection_c.h"
// Member `pts_list`
#include "sr_msgs/msg/trajectory_point.h"
// Member `pts_list`
#include "sr_msgs/msg/detail/trajectory_point__nexidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_init_function(
  void * message_memory, enum nexidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/nex/nex/issues/397
  (void) _init;
  sr_msgs__msg__VehicleTrajectory__init(message_memory);
}

void VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_fini_function(void * message_memory)
{
  sr_msgs__msg__VehicleTrajectory__fini(message_memory);
}

size_t VehicleTrajectory__nexidl_typesupport_introspection_c__size_function__TrajectoryPoint__pts_list(
  const void * untyped_member)
{
  (void)untyped_member;
  return 100;
}

const void * VehicleTrajectory__nexidl_typesupport_introspection_c__get_const_function__TrajectoryPoint__pts_list(
  const void * untyped_member, size_t index)
{
  const sr_msgs__msg__TrajectoryPoint * member =
    (const sr_msgs__msg__TrajectoryPoint *)(untyped_member);
  return &member[index];
}

void * VehicleTrajectory__nexidl_typesupport_introspection_c__get_function__TrajectoryPoint__pts_list(
  void * untyped_member, size_t index)
{
  sr_msgs__msg__TrajectoryPoint * member =
    (sr_msgs__msg__TrajectoryPoint *)(untyped_member);
  return &member[index];
}

static nexidl_typesupport_introspection_c__MessageMember VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_message_member_array[3] = {
  {
    "navigation_mode_enum",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__VehicleTrajectory, navigation_mode_enum),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "pts_size",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__VehicleTrajectory, pts_size),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "pts_list",  // name
    nexidl_typesupport_introspection_c__NEX_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    100,  // array size
    false,  // is upper bound
    offsetof(sr_msgs__msg__VehicleTrajectory, pts_list),  // bytes offset in struct
    NULL,  // default value
    VehicleTrajectory__nexidl_typesupport_introspection_c__size_function__TrajectoryPoint__pts_list,  // size() function pointer
    VehicleTrajectory__nexidl_typesupport_introspection_c__get_const_function__TrajectoryPoint__pts_list,  // get_const(index) function pointer
    VehicleTrajectory__nexidl_typesupport_introspection_c__get_function__TrajectoryPoint__pts_list,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const nexidl_typesupport_introspection_c__MessageMembers VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_message_members = {
  "sr_msgs__msg",  // message namespace
  "VehicleTrajectory",  // message name
  3,  // number of fields
  sizeof(sr_msgs__msg__VehicleTrajectory),
  VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_message_member_array,  // message members
  VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_init_function,  // function to initialize message memory (memory has to be allocated)
  VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static nexidl_message_type_support_t VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_message_type_support_handle = {
  0,
  &VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_message_members,
  get_message_typesupport_handle_function,
};

NEXIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_sr_msgs
const nexidl_message_type_support_t *
NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, VehicleTrajectory)() {
  VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_message_member_array[0].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, NavigationStatus)();
  VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_message_member_array[2].members_ =
    NEXIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(nexidl_typesupport_introspection_c, sr_msgs, msg, TrajectoryPoint)();
  if (!VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_message_type_support_handle.typesupport_identifier) {
    VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_message_type_support_handle.typesupport_identifier =
      nexidl_typesupport_introspection_c__identifier;
  }
  return &VehicleTrajectory__nexidl_typesupport_introspection_c__VehicleTrajectory_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
