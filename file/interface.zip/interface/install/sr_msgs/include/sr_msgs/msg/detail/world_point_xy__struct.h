// generated from nexidl_generator_c/resource/idl__struct.h.em
// with input from sr_msgs:msg/WorldPointXY.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__WORLD_POINT_XY__STRUCT_H_
#define SR_MSGS__MSG__DETAIL__WORLD_POINT_XY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/WorldPointXY in the package sr_msgs.
typedef struct sr_msgs__msg__WorldPointXY
{
  float x_m;
  float y_m;
} sr_msgs__msg__WorldPointXY;

// Struct for a sequence of sr_msgs__msg__WorldPointXY.
typedef struct sr_msgs__msg__WorldPointXY__Sequence
{
  sr_msgs__msg__WorldPointXY * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sr_msgs__msg__WorldPointXY__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__DETAIL__WORLD_POINT_XY__STRUCT_H_
