// generated from nexidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sr_msgs:msg/WorldPointXY.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__DETAIL__WORLD_POINT_XY__STRUCT_HPP_
#define SR_MSGS__MSG__DETAIL__WORLD_POINT_XY__STRUCT_HPP_

#include <nexidl_runtime_cpp/bounded_vector.hpp>
#include <nexidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__sr_msgs__msg__WorldPointXY __attribute__((deprecated))
#else
# define DEPRECATED__sr_msgs__msg__WorldPointXY __declspec(deprecated)
#endif

namespace sr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct WorldPointXY_
{
  using Type = WorldPointXY_<ContainerAllocator>;

  explicit WorldPointXY_(nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->x_m = 0.0f;
      this->y_m = 0.0f;
    }
  }

  explicit WorldPointXY_(const ContainerAllocator & _alloc, nexidl_runtime_cpp::MessageInitialization _init = nexidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (nexidl_runtime_cpp::MessageInitialization::ALL == _init ||
      nexidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->x_m = 0.0f;
      this->y_m = 0.0f;
    }
  }

  // field types and members
  using _x_m_type =
    float;
  _x_m_type x_m;
  using _y_m_type =
    float;
  _y_m_type y_m;

  // setters for named parameter idiom
  Type & set__x_m(
    const float & _arg)
  {
    this->x_m = _arg;
    return *this;
  }
  Type & set__y_m(
    const float & _arg)
  {
    this->y_m = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sr_msgs::msg::WorldPointXY_<ContainerAllocator> *;
  using ConstRawPtr =
    const sr_msgs::msg::WorldPointXY_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sr_msgs::msg::WorldPointXY_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sr_msgs::msg::WorldPointXY_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::WorldPointXY_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::WorldPointXY_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sr_msgs::msg::WorldPointXY_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sr_msgs::msg::WorldPointXY_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sr_msgs::msg::WorldPointXY_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sr_msgs::msg::WorldPointXY_<ContainerAllocator> const>;

  // pointer types similar to NEX 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sr_msgs__msg__WorldPointXY
    std::shared_ptr<sr_msgs::msg::WorldPointXY_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sr_msgs__msg__WorldPointXY
    std::shared_ptr<sr_msgs::msg::WorldPointXY_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const WorldPointXY_ & other) const
  {
    if (this->x_m != other.x_m) {
      return false;
    }
    if (this->y_m != other.y_m) {
      return false;
    }
    return true;
  }
  bool operator!=(const WorldPointXY_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct WorldPointXY_

// alias to use template instance with default allocator
using WorldPointXY =
  sr_msgs::msg::WorldPointXY_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sr_msgs

#endif  // SR_MSGS__MSG__DETAIL__WORLD_POINT_XY__STRUCT_HPP_
