// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/Lane.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__LANE_H_
#define SR_MSGS__MSG__LANE_H_

#include "sr_msgs/msg/detail/lane__struct.h"
#include "sr_msgs/msg/detail/lane__functions.h"
#include "sr_msgs/msg/detail/lane__type_support.h"

#endif  // SR_MSGS__MSG__LANE_H_
