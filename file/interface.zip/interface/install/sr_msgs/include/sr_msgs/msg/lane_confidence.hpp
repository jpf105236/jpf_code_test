// generated from nexidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__LANE_CONFIDENCE_HPP_
#define SR_MSGS__MSG__LANE_CONFIDENCE_HPP_

#include "sr_msgs/msg/detail/lane_confidence__struct.hpp"
#include "sr_msgs/msg/detail/lane_confidence__builder.hpp"
#include "sr_msgs/msg/detail/lane_confidence__traits.hpp"

#endif  // SR_MSGS__MSG__LANE_CONFIDENCE_HPP_
