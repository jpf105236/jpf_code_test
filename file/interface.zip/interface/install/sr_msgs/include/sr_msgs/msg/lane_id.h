// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/LaneId.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__LANE_ID_H_
#define SR_MSGS__MSG__LANE_ID_H_

#include "sr_msgs/msg/detail/lane_id__struct.h"
#include "sr_msgs/msg/detail/lane_id__functions.h"
#include "sr_msgs/msg/detail/lane_id__type_support.h"

#endif  // SR_MSGS__MSG__LANE_ID_H_
