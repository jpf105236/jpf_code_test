// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/LaneType.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__LANE_TYPE_H_
#define SR_MSGS__MSG__LANE_TYPE_H_

#include "sr_msgs/msg/detail/lane_type__struct.h"
#include "sr_msgs/msg/detail/lane_type__functions.h"
#include "sr_msgs/msg/detail/lane_type__type_support.h"

#endif  // SR_MSGS__MSG__LANE_TYPE_H_
