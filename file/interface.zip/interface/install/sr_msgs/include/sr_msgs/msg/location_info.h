// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/LocationInfo.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__LOCATION_INFO_H_
#define SR_MSGS__MSG__LOCATION_INFO_H_

#include "sr_msgs/msg/detail/location_info__struct.h"
#include "sr_msgs/msg/detail/location_info__functions.h"
#include "sr_msgs/msg/detail/location_info__type_support.h"

#endif  // SR_MSGS__MSG__LOCATION_INFO_H_
