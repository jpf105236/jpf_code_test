// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/LocationInfoLocation.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__LOCATION_INFO_LOCATION_H_
#define SR_MSGS__MSG__LOCATION_INFO_LOCATION_H_

#include "sr_msgs/msg/detail/location_info_location__struct.h"
#include "sr_msgs/msg/detail/location_info_location__functions.h"
#include "sr_msgs/msg/detail/location_info_location__type_support.h"

#endif  // SR_MSGS__MSG__LOCATION_INFO_LOCATION_H_
