// generated from nexidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__LOCATION_INFO_LOCATION_HPP_
#define SR_MSGS__MSG__LOCATION_INFO_LOCATION_HPP_

#include "sr_msgs/msg/detail/location_info_location__struct.hpp"
#include "sr_msgs/msg/detail/location_info_location__builder.hpp"
#include "sr_msgs/msg/detail/location_info_location__traits.hpp"

#endif  // SR_MSGS__MSG__LOCATION_INFO_LOCATION_HPP_
