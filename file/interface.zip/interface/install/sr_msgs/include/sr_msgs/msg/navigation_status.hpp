// generated from nexidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__NAVIGATION_STATUS_HPP_
#define SR_MSGS__MSG__NAVIGATION_STATUS_HPP_

#include "sr_msgs/msg/detail/navigation_status__struct.hpp"
#include "sr_msgs/msg/detail/navigation_status__builder.hpp"
#include "sr_msgs/msg/detail/navigation_status__traits.hpp"

#endif  // SR_MSGS__MSG__NAVIGATION_STATUS_HPP_
