// generated from nexidl_generator_c/resource/nexidl_generator_c__visibility_control.h.in
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__NEXIDL_GENERATOR_C__VISIBILITY_CONTROL_H_
#define SR_MSGS__MSG__NEXIDL_GENERATOR_C__VISIBILITY_CONTROL_H_

#ifdef __cplusplus
extern "C"
{
#endif

// This logic was borrowed (then namespaced) from the examples on the gcc wiki:
//     https://gcc.gnu.org/wiki/Visibility

#if defined _WIN32 || defined __CYGWIN__
  #ifdef __GNUC__
    #define NEXIDL_GENERATOR_C_EXPORT_sr_msgs __attribute__ ((dllexport))
    #define NEXIDL_GENERATOR_C_IMPORT_sr_msgs __attribute__ ((dllimport))
  #else
    #define NEXIDL_GENERATOR_C_EXPORT_sr_msgs __declspec(dllexport)
    #define NEXIDL_GENERATOR_C_IMPORT_sr_msgs __declspec(dllimport)
  #endif
  #ifdef NEXIDL_GENERATOR_C_BUILDING_DLL_sr_msgs
    #define NEXIDL_GENERATOR_C_PUBLIC_sr_msgs NEXIDL_GENERATOR_C_EXPORT_sr_msgs
  #else
    #define NEXIDL_GENERATOR_C_PUBLIC_sr_msgs NEXIDL_GENERATOR_C_IMPORT_sr_msgs
  #endif
#else
  #define NEXIDL_GENERATOR_C_EXPORT_sr_msgs __attribute__ ((visibility("default")))
  #define NEXIDL_GENERATOR_C_IMPORT_sr_msgs
  #if __GNUC__ >= 4
    #define NEXIDL_GENERATOR_C_PUBLIC_sr_msgs __attribute__ ((visibility("default")))
  #else
    #define NEXIDL_GENERATOR_C_PUBLIC_sr_msgs
  #endif
#endif

#ifdef __cplusplus
}
#endif

#endif  // SR_MSGS__MSG__NEXIDL_GENERATOR_C__VISIBILITY_CONTROL_H_
