// generated from nexidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__PERCEPTION_INFO_HPP_
#define SR_MSGS__MSG__PERCEPTION_INFO_HPP_

#include "sr_msgs/msg/detail/perception_info__struct.hpp"
#include "sr_msgs/msg/detail/perception_info__builder.hpp"
#include "sr_msgs/msg/detail/perception_info__traits.hpp"

#endif  // SR_MSGS__MSG__PERCEPTION_INFO_HPP_
