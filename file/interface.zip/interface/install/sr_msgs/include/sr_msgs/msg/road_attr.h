// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/RoadAttr.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__ROAD_ATTR_H_
#define SR_MSGS__MSG__ROAD_ATTR_H_

#include "sr_msgs/msg/detail/road_attr__struct.h"
#include "sr_msgs/msg/detail/road_attr__functions.h"
#include "sr_msgs/msg/detail/road_attr__type_support.h"

#endif  // SR_MSGS__MSG__ROAD_ATTR_H_
