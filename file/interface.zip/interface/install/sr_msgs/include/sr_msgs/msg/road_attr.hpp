// generated from nexidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__ROAD_ATTR_HPP_
#define SR_MSGS__MSG__ROAD_ATTR_HPP_

#include "sr_msgs/msg/detail/road_attr__struct.hpp"
#include "sr_msgs/msg/detail/road_attr__builder.hpp"
#include "sr_msgs/msg/detail/road_attr__traits.hpp"

#endif  // SR_MSGS__MSG__ROAD_ATTR_HPP_
