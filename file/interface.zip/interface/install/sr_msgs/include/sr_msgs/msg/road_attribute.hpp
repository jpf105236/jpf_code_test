// generated from nexidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__ROAD_ATTRIBUTE_HPP_
#define SR_MSGS__MSG__ROAD_ATTRIBUTE_HPP_

#include "sr_msgs/msg/detail/road_attribute__struct.hpp"
#include "sr_msgs/msg/detail/road_attribute__builder.hpp"
#include "sr_msgs/msg/detail/road_attribute__traits.hpp"

#endif  // SR_MSGS__MSG__ROAD_ATTRIBUTE_HPP_
