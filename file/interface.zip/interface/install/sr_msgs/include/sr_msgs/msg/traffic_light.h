// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/TrafficLight.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__TRAFFIC_LIGHT_H_
#define SR_MSGS__MSG__TRAFFIC_LIGHT_H_

#include "sr_msgs/msg/detail/traffic_light__struct.h"
#include "sr_msgs/msg/detail/traffic_light__functions.h"
#include "sr_msgs/msg/detail/traffic_light__type_support.h"

#endif  // SR_MSGS__MSG__TRAFFIC_LIGHT_H_
