// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/TrafficLightState.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__TRAFFIC_LIGHT_STATE_H_
#define SR_MSGS__MSG__TRAFFIC_LIGHT_STATE_H_

#include "sr_msgs/msg/detail/traffic_light_state__struct.h"
#include "sr_msgs/msg/detail/traffic_light_state__functions.h"
#include "sr_msgs/msg/detail/traffic_light_state__type_support.h"

#endif  // SR_MSGS__MSG__TRAFFIC_LIGHT_STATE_H_
