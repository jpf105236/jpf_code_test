// generated from nexidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__TRAFFIC_LIGHT_STATE_HPP_
#define SR_MSGS__MSG__TRAFFIC_LIGHT_STATE_HPP_

#include "sr_msgs/msg/detail/traffic_light_state__struct.hpp"
#include "sr_msgs/msg/detail/traffic_light_state__builder.hpp"
#include "sr_msgs/msg/detail/traffic_light_state__traits.hpp"

#endif  // SR_MSGS__MSG__TRAFFIC_LIGHT_STATE_HPP_
