// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/TrajectoryPoint.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__TRAJECTORY_POINT_H_
#define SR_MSGS__MSG__TRAJECTORY_POINT_H_

#include "sr_msgs/msg/detail/trajectory_point__struct.h"
#include "sr_msgs/msg/detail/trajectory_point__functions.h"
#include "sr_msgs/msg/detail/trajectory_point__type_support.h"

#endif  // SR_MSGS__MSG__TRAJECTORY_POINT_H_
