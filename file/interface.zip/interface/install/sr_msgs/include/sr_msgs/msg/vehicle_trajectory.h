// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/VehicleTrajectory.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__VEHICLE_TRAJECTORY_H_
#define SR_MSGS__MSG__VEHICLE_TRAJECTORY_H_

#include "sr_msgs/msg/detail/vehicle_trajectory__struct.h"
#include "sr_msgs/msg/detail/vehicle_trajectory__functions.h"
#include "sr_msgs/msg/detail/vehicle_trajectory__type_support.h"

#endif  // SR_MSGS__MSG__VEHICLE_TRAJECTORY_H_
