// generated from nexidl_generator_c/resource/idl.h.em
// with input from sr_msgs:msg/WorldPointXY.idl
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__WORLD_POINT_XY_H_
#define SR_MSGS__MSG__WORLD_POINT_XY_H_

#include "sr_msgs/msg/detail/world_point_xy__struct.h"
#include "sr_msgs/msg/detail/world_point_xy__functions.h"
#include "sr_msgs/msg/detail/world_point_xy__type_support.h"

#endif  // SR_MSGS__MSG__WORLD_POINT_XY_H_
