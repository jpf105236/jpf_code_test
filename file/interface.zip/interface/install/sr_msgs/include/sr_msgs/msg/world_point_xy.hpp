// generated from nexidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SR_MSGS__MSG__WORLD_POINT_XY_HPP_
#define SR_MSGS__MSG__WORLD_POINT_XY_HPP_

#include "sr_msgs/msg/detail/world_point_xy__struct.hpp"
#include "sr_msgs/msg/detail/world_point_xy__builder.hpp"
#include "sr_msgs/msg/detail/world_point_xy__traits.hpp"

#endif  // SR_MSGS__MSG__WORLD_POINT_XY_HPP_
